/**
 * Generate Report Message Action
 *
 * Allows the Property Report widget to be triggered by other widgets
 * (Search, Map, Near Me, Feature Info, etc.) through the ExB message
 * action framework.
 *
 * When triggered it passes the geometry (point) to the Property Report
 * widget via MutableStoreManager so the widget can run its query.
 */
import {
    AbstractMessageAction,
    MessageType,
    MutableStoreManager,
    getAppStore,
    appActions
} from 'jimu-core'
import type {
    Message,
    MessageDescription,
    DataRecordsSelectionChangeMessage,
    DataRecordSetChangeMessage
} from 'jimu-core'

// Accept only finite coordinates and a plain { wkid } or { wkt } spatial reference.
// Messages come from other widgets and, through them, from data we do not control.
const finite = (v: any): v is number => typeof v === 'number' && isFinite(v)

const sanitizeSpatialReference = (sr: any): { wkid?: number, wkt?: string } => {
    const raw = sr?.toJSON?.() ?? sr ?? {}
    if (finite(raw.wkid)) return { wkid: raw.wkid }
    if (typeof raw.wkt === 'string' && raw.wkt.length < 4000) return { wkt: raw.wkt }
    return { wkid: 4326 }
}

const pointFromGeometry = (geometry: any): { x: number, y: number, spatialReference: any } | null => {
    if (!geometry) return null
    let x: any, y: any
    if (geometry.type === 'point') {
        x = geometry.x; y = geometry.y
    } else if (geometry.extent) {
        const e = geometry.extent
        const c = e.center
        x = c?.x ?? (finite(e.xmin) && finite(e.xmax) ? (e.xmin + e.xmax) / 2 : undefined)
        y = c?.y ?? (finite(e.ymin) && finite(e.ymax) ? (e.ymin + e.ymax) / 2 : undefined)
    } else if (geometry.centroid) {
        x = geometry.centroid.x; y = geometry.centroid.y
    }
    if (!finite(x) || !finite(y)) return null
    return { x, y, spatialReference: sanitizeSpatialReference(geometry.spatialReference) }
}

const addressFromAttributes = (attrs: any): string | null => {
    if (!attrs || typeof attrs !== 'object') return null
    const v = attrs.Match_addr ?? attrs.address ?? attrs.Address ?? attrs.StAddr ?? attrs.ShortLabel ?? attrs.PlaceName ?? null
    return typeof v === 'string' && v.trim() ? v.trim().slice(0, 300) : null
}

const extractPoint = (message: Message): { point: { x: number, y: number, spatialReference: any } | null, address: string | null } => {
    const anyMsg = message as any
    let point: { x: number, y: number, spatialReference: any } | null = null
    let address: string | null = null
    switch (message.type) {
        case MessageType.DataRecordsSelectionChange:
        case MessageType.DataRecordSetChange: {
            const records = anyMsg.records ?? anyMsg.dataRecordSet?.records
            if (Array.isArray(records) && records.length > 0) {
                const record = records[0]
                const feature = record?.feature ?? record?.data
                point = pointFromGeometry(feature?.geometry ?? record?.geometry)
                address = addressFromAttributes(feature?.attributes ?? record?.getData?.())
            }
            break
        }
        default: {
            const loc = anyMsg.location ?? anyMsg.point
            if (loc) {
                const x = loc.x ?? loc.longitude, y = loc.y ?? loc.latitude
                if (finite(x) && finite(y)) point = { x, y, spatialReference: sanitizeSpatialReference(loc.spatialReference) }
            }
        }
    }
    return { point, address }
}

export default class GenerateReportAction extends AbstractMessageAction {
    filterMessageDescription(messageDescription: MessageDescription): boolean {
        // ExtentChange is deliberately not listed. Accepting it meant every map
        // pan or zoom triggered a full property report at the view centre.
        return [
            MessageType.DataRecordsSelectionChange,
            MessageType.DataRecordSetChange,
            'LOCATION_CHANGE' as any
        ].includes(messageDescription.messageType)
    }

    filterMessage(message: Message): boolean {
        // Only accept messages we can turn into a usable point. Returning true for
        // everything meant the action ran, warned, and still reported success.
        return extractPoint(message).point !== null
    }

    getSettingComponentUri(_messageType: MessageType, _messageWidgetId?: string): string {
        return 'actions/generate-report-action-setting'
    }

    onExecute(message: Message, actionConfig?: any): Promise<boolean> {
        const autoOpenSection: string | null = actionConfig?.autoOpenSection ?? null
        const { point, address } = extractPoint(message)

        if (point) {
            MutableStoreManager.getInstance().updateStateValue(this.widgetId, 'actionPoint', {
                point,
                address,
                autoOpenSection,
                timestamp: Date.now()
            })

            getAppStore().dispatch(
                appActions.widgetStatePropChange(this.widgetId, 'actionTriggered', true)
            )

            return Promise.resolve(true)
        }

        console.warn('GenerateReportAction: No valid point geometry found in message', message.type)
        return Promise.resolve(false)
    }
} 
