/**
 * Shared configuration defaults for the Property Report widget. Owns the single
 * source of fallback values used by both the runtime (when a config key is
 * missing) and the setting panel (when rendering controls and importing XML),
 * plus the list of valid top-level Config keys so importers can reject unknown
 * or dangerous keys. Values follow the documented defaults in config.ts and the
 * shipped config.json; when those disagree the config.ts comment wins.
 */
import type {
    Config, ChartConfig, TableDisplayConfig, PdfHeaderConfig, PdfFooterConfig,
    PdfStyleConfig, PdfAccessibilityConfig, PdfLogoConfig, PropertyPreviewConfig,
    HighlightLayerConfig, NearbyDisplayConfig
} from './config'

// Theme primary used across widget, PDF header/table styling and charts.
export const DEFAULT_PRIMARY_COLOR = '#1A6B7C'

const pdfLogo: Required<Pick<PdfLogoConfig, 'sizeMode' | 'maxWidth' | 'maxHeight' | 'position' | 'verticalAlign' | 'shape' | 'padding'>> = {
    sizeMode: 'auto',
    maxWidth: 50,
    maxHeight: 25,
    position: 'left',
    verticalAlign: 'middle',
    shape: 'default',
    padding: 0
}

const pdfHeader: PdfHeaderConfig = {
    organizationName: '',
    showTitle: true,
    titleFontSize: 16,
    titleMode: 'default',
    reportTitle: 'Property Report',
    subtitleText: '',
    headerTextColor: '#1A1A1A',
    headerColor: '#FFFFFF',
    headerHeight: 25,          // 35 when a logo is present
    logoWidth: 40,
    includeMap: true,
    mapHeight: 60,
    mapScaleMode: 'fixed',
    mapScale: 2500,
    mapFitPadding: 1.2,
    showGeneratedDate: true,
    titlePosition: 'center',
    datePosition: 'right',
    headerLayout: 'inline',
    logo: pdfLogo
}

const pdfFooter: PdfFooterConfig = {
    enabled: true,
    showPageNumbers: true,
    pageNumberFormat: 'detailed',
    pageNumberPosition: 'right',
    disclaimerText: 'DISCLAIMER: This product is for informational purposes and may not have been prepared for or be suitable for legal, engineering, or surveying purposes.',
    disclaimerFontSize: 7,
    contactText: '',
    contactPosition: 'left',
    footerHeight: 15,
    footerColor: '#FFFFFF',
    footerTextColor: '#4A4A4A',
    showTopBorder: true
}

const pdfStyle: PdfStyleConfig = {
    primaryColor: DEFAULT_PRIMARY_COLOR,
    sectionHeaderColor: '#1A6B7C',
    sectionHeaderTextColor: '#FFFFFF',
    alternateRowColor: '#F5F5F5',
    borderColor: '#CCCCCC',
    linkColor: '#0066CC',
    fontFamily: 'helvetica',
    dataLayout: 'auto',
    twoColumnGap: 10,
    showSectionBorders: true,
    compactMode: false,

    tableHeaderBgColor: '#1A6B7C',
    tableHeaderTextColor: '#FFFFFF',
    layerTitleBgColor: '#69812D',
    layerTitleTextColor: '#FFFFFF',
    tableHeaderFontSize: 8,
    tableHeaderHeight: 8,
    tableDataFontSize: 8,
    tableDataTextColor: '#333333',
    tableRowHeight: 7,
    tableShowBorders: true,
    tableBorderColor: '#CCCCCC',
    tableStripedRows: true,
    tableMaxColumns: 6,
    tableMaxRows: 15,
    tableCellPadding: 2,

    showAccessibilityText: true,
    showTableSummaries: true,
    showRelatedTableSummaries: true,
    showFullUrlsInPdf: false,

    enablePdfBookmarks: true,
    enableHierarchicalBookmarks: true,
    showSectionNumbers: false,
    showGeneratedTimestamp: false,
    accessibilityContact: '',
    highContrastMode: false,
    largeTextMode: false,

    enableTableOfContents: false,
    tocTitle: 'Table of Contents',
    tocIncludeLayers: true,
    tocIncludeRelatedTables: false,
    tocPageBreakAfter: true,

    relatedTableHeaderColor: '#DCDCDC',
    relatedTableIndent: 5,
    relatedTableMaxRows: 10,
    includeRelatedTableCharts: true
}

const pdfAccessibility: PdfAccessibilityConfig = {
    documentLanguage: 'en-US',
    documentAuthor: 'GIS Division',
    documentCreator: 'Property Report Widget',
    includeMapAltText: true,
    includeLogoAltText: true,
    mapAltTextTemplate: 'Map showing the location of {address}',
    logoAltTextTemplate: 'Organization logo',
    chartAltTextTemplate: 'Chart showing {chartType} visualization of {dataDescription}',
    includeTableSummaries: true,
    tableSummaryTemplate: 'Data table: {layerTitle} - {recordCount} records, {columnCount} columns',
    includeRelatedTableSummaries: true,
    relatedTableSummaryTemplate: 'Related data: {tableName} - {recordCount} records, {columnCount} columns',
    minimumFontSize: 9,
    includeReadingOrderMarkers: true,
    tocTitle: 'Table of Contents'
}

const defaultChartConfig: ChartConfig = {
    chartType: 'bar',
    chartMode: 'category',
    aggregation: 'count',
    showLegend: true,
    legendPosition: 'bottom',
    showValues: false,
    showGrid: true,
    animate: true,
    stacked: false,
    curveType: 'natural',
    height: 200,
    maxCategories: 10,
    sortBy: 'value',
    sortOrder: 'desc',
    chartDescriptionPosition: 'after'
}

const defaultTableConfig: TableDisplayConfig = {
    enableSorting: true,
    enableFiltering: false,
    enablePagination: true,
    pageSize: 10,
    pageSizeOptions: [5, 10, 25, 50],
    stickyHeader: true,
    stripedRows: true,
    highlightOnHover: true,
    compactMode: false,
    showRowNumbers: false,
    resizableColumns: false
}

const propertyPreview: PropertyPreviewConfig = {
    enabled: false,
    showMapPreview: true,
    mapPreviewHeight: 150,
    mapPreviewZoomLevel: 18,
    showBasemap: true,
    highlightColor: '#00FFFF',
    imageHeight: 200,
    showAttributes: true,
    attributeLayout: 'horizontal',
    showZoomButton: true,
    showCopyButton: true
}

const highlightLayer: HighlightLayerConfig = {
    enabled: false,
    highlightColor: '#00FFFF',
    fillOpacity: 0.2
}

const nearby: NearbyDisplayConfig = {
    enabled: false,
    maxFeatures: 5,
    searchRadius: 5,
    searchRadiusUnit: 'miles',
    distanceUnit: 'miles',
    distancePrecision: 2,
    showDistanceBadge: true,
    sortOrder: 'asc',
    includeInPdf: true
}

export const DEFAULTS = {
    // Top-level scalars
    pdfTitle: 'Property Report',
    resultsPanelTitle: 'Property Report',
    pdfIncludeTables: true,
    pdfIncludeCharts: true,
    pdfIncludeRelatedTables: true,
    pdfIncludeRelatedTableCharts: true,
    combinedMaxSuggestions: 10,
    showSourceLabels: true,
    coordinateSystem: 'wgs84' as NonNullable<Config['coordinateSystem']>,
    coordinateFormat: 'decimal' as NonNullable<Config['coordinateFormat']>,
    coordinatePrecision: 6,
    showCoordinates: true,
    permalinkParam: 'propertysearch',
    permalinkAutoOpen: true,
    enableComparison: true,
    enablePermalink: true,
    enableCsvExport: true,
    enableRecentSearches: true,
    enableClientSideQuery: false,
    enableUseCurrentLocation: true,

    // Per-source and per-layer scalars
    searchSourceMaxSuggestions: 6,
    layerRowHighlightColor: '#FF6600',
    layerShowAllOnMapColor: '#FF6600',
    layerRowHighlightFillOpacity: 0.2,
    layerRowZoomScale: 2500,
    relatedTableMaxRecords: 50,

    // Nested config groups
    pdfHeader,
    pdfFooter,
    pdfStyle,
    pdfAccessibility,
    defaultChartConfig,
    defaultTableConfig,
    propertyPreview,
    highlightLayer,
    nearby
}

// Every valid top-level key of Config. Importers must reject anything else.
export const CONFIG_KEYS: Array<keyof Config> = [
    'mapWidgetId',
    'searchSources',
    'sections',
    'headerInfo',
    'highlightLayer',
    'propertyPreview',
    'pdfTitle',
    'pdfIncludeTables',
    'pdfIncludeCharts',
    'pdfIncludeRelatedTables',
    'pdfIncludeRelatedTableCharts',
    'resultsPanelTitle',
    'pdfHeader',
    'pdfFooter',
    'pdfStyle',
    'pdfAccessibility',
    'defaultChartConfig',
    'defaultTableConfig',
    'combinedMaxSuggestions',
    'showSourceLabels',
    'coordinateSystem',
    'coordinateFormat',
    'coordinatePrecision',
    'showCoordinates',
    'customCoordinateWkid',
    'customCoordinateLabel',
    'reportSummaryTemplate',
    'permalinkParam',
    'permalinkAutoOpen',
    'enableComparison',
    'enablePermalink',
    'enableCsvExport',
    'enableRecentSearches',
    'enableClientSideQuery',
    'enableUseCurrentLocation'
]
