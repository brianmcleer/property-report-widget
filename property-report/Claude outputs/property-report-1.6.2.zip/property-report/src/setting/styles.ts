// Emotion styles for the Property Report setting panel. This module owns the
// single CSS block that used to live inside getStyles() in setting.tsx. It is a
// module constant (not a function) because the block takes no arguments. Class
// names must not change: the setting JSX and the extracted components depend on
// them. The trailing rules support the ColorField component's inline error text.
import { css } from 'jimu-core'

export const settingStyles = css`
  .setting-container {
    display: flex;
    flex-direction: column;
    gap: 0;
  }

  /* Collapsible Settings Panel Styles */
  .collapsible-panel {
    margin-bottom: 4px;
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-1);
    overflow: hidden;
    background: var(--sys-color-surface-paper);
  }

  .collapsible-panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 12px;
    cursor: pointer;
    user-select: none;
    background: var(--sys-color-primary-main);
    color: white;
    transition: background-color 0.15s ease;

    &:hover {
      background: var(--sys-color-primary-dark);
    }
  }

  .collapsible-panel-header-left {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }

  .collapsible-panel-title {
    font-size: 13px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .collapsible-panel-toggle {
    transition: transform 0.2s ease;
    flex-shrink: 0;
    width: 16px;
    height: 16px;
    display: flex;
    align-items: center;
    justify-content: center;

    &.collapsed {
      transform: rotate(-90deg);
    }
  }

  .collapsible-panel-content {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease-out;
    
    &.expanded {
      max-height: 15000px;
      transition: max-height 0.5s ease-in;
    }
  }

  .collapsible-panel-inner {
    padding: 12px;
  }

  /* Collapsable list item styling */
  .list-item-card {
    margin-bottom: 8px;
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-1);
    overflow: hidden;
    background: var(--sys-color-surface-paper);
    box-shadow: var(--sys-shadow-1);
    
    &:hover {
      border-color: var(--sys-color-primary-main);
    }
  }

  .list-item-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 12px;
    cursor: pointer;
    user-select: none;
    background: var(--sys-color-surface-background);
    transition: background-color 0.15s ease;

    &:hover {
      background: rgba(255, 255, 255, 0.05);
    }
  }

  .list-item-header-left {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }

  .expand-icon {
    color: var(--sys-color-text-regular);
    transition: transform 0.2s ease;
    flex-shrink: 0;
    width: 16px;
    height: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .list-item-title {
    font-size: 13px;
    font-weight: 500;
    color: var(--sys-color-text-dark);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    flex: 1;
  }

  .item-badge {
    font-size: 10px;
    padding: 2px 8px;
    border-radius: var(--sys-shape-pill);
    background: rgba(255, 255, 255, 0.15);
    color: var(--sys-color-text-regular);
    flex-shrink: 0;
    font-weight: 500;
    border: 1px solid rgba(255, 255, 255, 0.2);
  }

  .item-badge-secondary {
    background: rgba(255, 255, 255, 0.1);
    color: var(--sys-color-text-light);
  }

  .item-badge-success {
    background: rgba(255, 255, 255, 0.15);
    color: var(--sys-color-text-regular);
  }

  .list-item-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-left: 8px;
  }

  .delete-btn {
    color: var(--sys-color-text-light);
    background: transparent;
    border: none;
    padding: 4px;
    border-radius: var(--sys-shape-0);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.15s ease;
    opacity: 0.7;

    &:hover {
      color: #f87171;
      background: rgba(248, 113, 113, 0.15);
      opacity: 1;
    }
  }

  .reorder-btn {
    color: var(--sys-color-text-light);
    background: transparent;
    border: none;
    padding: 4px;
    border-radius: var(--sys-shape-0);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.15s ease;
    opacity: 0.7;

    &:hover:not(:disabled) {
      color: var(--sys-color-primary-main);
      background: rgba(var(--sys-color-primary-main-rgb), 0.15);
      opacity: 1;
    }

    &:disabled {
      opacity: 0.3;
      cursor: not-allowed;
    }
  }

  .reorder-buttons {
    display: flex;
    flex-direction: column;
    gap: 2px;
    margin-right: 4px;
  }

  .drag-handle {
    color: var(--sys-color-text-light);
    cursor: grab;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0.5;
    transition: opacity 0.15s ease;

    &:hover {
      opacity: 1;
    }

    &:active {
      cursor: grabbing;
    }
  }

  .selected-field-order {
    border: 1px solid var(--sys-color-divider-secondary, #e0e0e0);
    border-radius: 4px;
    padding: 6px;
    margin-bottom: 8px;
    background: var(--sys-color-surface-paper, #fafafa);
  }
  .selected-field-order-label {
    font-size: 11px;
    font-weight: 600;
    color: var(--sys-color-text-light);
    margin: 0 2px 6px;
  }
  .field-order-item {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 6px;
    border-radius: 3px;
    background: var(--sys-color-surface-background, #fff);
    border: 1px solid var(--sys-color-divider-secondary, #e0e0e0);
    cursor: grab;
    user-select: none;
  }
  .field-order-item + .field-order-item {
    margin-top: 3px;
  }
  .field-order-item:active {
    cursor: grabbing;
  }
  .field-order-item.dragging {
    opacity: 0.4;
  }
  .field-order-item.drag-over {
    border-color: var(--sys-color-primary-main, #1976d2);
    box-shadow: inset 0 2px 0 var(--sys-color-primary-main, #1976d2);
  }
  .field-order-num {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    background-color: var(--sys-color-primary-main, #1976d2);
    color: #fff;
    font-size: 10px;
    font-weight: 600;
    flex-shrink: 0;
  }
  .field-order-name {
    font-size: 12px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .list-item-content {
    padding: 12px;
    background: var(--sys-color-surface-paper);
    border-top: 1px solid var(--sys-color-divider-secondary);
  }

  /* Nested list items (layers within sections) */
  .nested-list-item {
    margin-bottom: 6px;
    border: 1px solid var(--sys-color-divider-tertiary);
    border-radius: var(--sys-shape-0);
    overflow: hidden;
    background: var(--sys-color-surface-background);
  }

  .nested-item-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 10px;
    cursor: pointer;
    background: var(--sys-color-surface-background);

    &:hover {
      background: rgba(255, 255, 255, 0.05);
    }
  }

  .nested-item-content {
    padding: 10px;
    background: var(--sys-color-surface-paper);
    border-top: 1px solid var(--sys-color-divider-tertiary);
  }

  /* Add buttons */
  .add-button {
    width: 100%;
    margin-top: 12px;
    justify-content: center;
    gap: 6px;
    border: 1px solid var(--sys-color-primary-main);
    background: transparent;
    color: var(--sys-color-primary-main);

    &:hover {
      background: var(--sys-color-primary-main);
      color: white;
    }
  }

  .add-button-primary {
    border-color: var(--sys-color-primary-main);
    color: var(--sys-color-primary-main);

    &:hover {
      background: var(--sys-color-primary-main);
      color: white;
    }
  }

  .add-button-secondary {
    border-color: var(--sys-color-secondary-main);
    color: var(--sys-color-text-dark);

    &:hover {
      background: var(--sys-color-secondary-main);
      color: white;
    }
  }

  /* Add source type buttons */
  .source-type-buttons {
    display: flex;
    gap: 8px;
    margin-top: 12px;
  }

  .source-type-btn {
    flex: 1 1 0;
    min-width: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 16px 8px;
    border: 1px solid var(--sys-color-primary-main);
    border-radius: var(--sys-shape-1);
    background: var(--sys-color-surface-paper);
    cursor: pointer;
    transition: all 0.15s ease;

    &:hover {
      background: var(--sys-color-primary-main);
      border-color: var(--sys-color-primary-main);
    }

    &:hover .source-type-icon {
      color: white;
    }

    &:hover .source-type-label {
      color: white;
    }
  }

  .source-type-icon {
    width: 28px;
    height: 28px;
    color: var(--sys-color-primary-main);
    transition: color 0.15s ease;
  }

  .source-type-label {
    font-size: 12px;
    font-weight: 500;
    color: var(--sys-color-text-dark);
    transition: color 0.15s ease;
  }

  /* Fields list */
  .fields-container {
    max-height: 200px;
    overflow-y: auto;
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-0);
    background: var(--sys-color-surface-paper);
    margin-top: 4px;
  }

  .field-item {
    display: flex;
    align-items: center;
    padding: 8px 10px;
    border-bottom: 1px solid var(--sys-color-divider-tertiary);
    gap: 10px;

    &:last-child {
      border-bottom: none;
    }

    &:hover {
      background: rgba(255, 255, 255, 0.03);
    }
  }

  .field-name {
    flex: 1;
    font-size: 12px;
    color: var(--sys-color-text-regular);
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .field-alias-input {
    width: 100px;
    flex-shrink: 0;
  }

  /* Display options */
  .display-options-row {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
    margin-top: 4px;
  }

  .display-option {
    display: flex;
    align-items: center;
    gap: 6px;
    
    label {
      font-size: 12px;
      color: var(--sys-color-text-dark);
      cursor: pointer;
    }
  }

  /* Empty state */
  .empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 24px 16px;
    text-align: center;
    color: var(--sys-color-text-regular);
    font-size: 12px;
    background: var(--sys-color-surface-paper);
    border-radius: var(--sys-shape-1);
    border: 1px dashed var(--sys-color-divider-primary);
  }

  .empty-state svg {
    width: 32px;
    height: 32px;
    color: var(--sys-color-text-light);
    margin-bottom: 8px;
    opacity: 0.7;
  }

  /* Subsection divider */
  .subsection-divider {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--sys-color-text-regular);
    margin: 16px 0 10px 0;
    padding-bottom: 6px;
    border-bottom: 1px solid var(--sys-color-divider-primary);
    opacity: 0.8;
  }

  .subsection-divider:first-child {
    margin-top: 0;
  }

  /* Input row with inline elements */
  .input-row {
    display: flex;
    gap: 8px;
    align-items: center;
    width: 100%;
  }

  /* Hint text */
  .hint-text {
    font-size: 11px;
    color: var(--sys-color-text-regular);
    margin-bottom: 12px;
    line-height: 1.5;
    opacity: 0.8;
  }

  /* Data source container */
  .ds-selector-container {
    width: 100%;
    margin-top: 4px;
  }

  /* Status indicator */
  .status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    flex-shrink: 0;
    box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.1);
  }

  .status-enabled {
    background: #4ade80;
  }

  .status-disabled {
    background: var(--sys-color-text-disabled);
  }

  /* ===== PDF Settings Styles ===== */
  .logo-upload-area {
    border: 2px dashed var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-1);
    padding: 20px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s ease;
    background: var(--sys-color-surface-paper);
    
    &:hover {
      border-color: var(--sys-color-primary-main);
      background: rgba(74, 144, 164, 0.05);
    }
  }

  .logo-preview-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-1);
    background: var(--sys-color-surface-paper);
  }

  .logo-preview {
    max-width: 150px;
    max-height: 80px;
    object-fit: contain;
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-0);
    background: white;
    padding: 8px;
  }

  .logo-actions {
    display: flex;
    gap: 8px;
  }

  .color-input-row {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
  }

  .color-picker {
    width: 40px;
    height: 28px;
    padding: 0;
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-0);
    cursor: pointer;
    background: transparent;
  }

  .pdf-section-card {
    background: var(--sys-color-surface-paper);
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-1);
    padding: 12px;
    margin-bottom: 12px;
  }

  .pdf-section-title {
    font-size: 12px;
    font-weight: 600;
    color: var(--sys-color-text-dark);
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .pdf-section-title svg {
    opacity: 0.7;
  }

  .textarea-input {
    width: 100%;
    min-height: 60px;
    padding: 8px;
    font-size: 12px;
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-0);
    resize: vertical;
    font-family: inherit;
  }

  .position-buttons {
    display: flex;
    gap: 4px;
  }

  .position-btn {
    flex: 1;
    padding: 6px 12px;
    font-size: 11px;
    border: 1px solid var(--sys-color-divider-secondary);
    background: var(--sys-color-surface-paper);
    cursor: pointer;
    transition: all 0.15s ease;

    &:first-child {
      border-radius: var(--sys-shape-0) 0 0 var(--sys-shape-0);
    }

    &:last-child {
      border-radius: 0 var(--sys-shape-0) var(--sys-shape-0) 0;
    }

    &.active {
      background: var(--sys-color-primary-main);
      border-color: var(--sys-color-primary-main);
      color: white;
    }

    &:hover:not(.active) {
      background: rgba(255, 255, 255, 0.1);
    }
  }

  /* Import/Export Section Styles */
  .import-export-section {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .import-export-buttons {
    display: flex;
    gap: 8px;
  }

  .import-export-btn {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 16px;
    border: 1px solid var(--sys-color-primary-main);
    border-radius: var(--sys-shape-1);
    background: var(--sys-color-surface-paper);
    color: var(--sys-color-primary-main);
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.15s ease;

    &:hover {
      background: var(--sys-color-primary-main);
      color: white;
    }

    &:hover svg {
      color: white;
    }
  }

  .import-export-btn svg {
    width: 16px;
    height: 16px;
    transition: color 0.15s ease;
  }

  .import-export-info {
    font-size: 11px;
    color: var(--sys-color-text-regular);
    line-height: 1.5;
    padding: 10px;
    background: var(--sys-color-surface-background);
    border-radius: var(--sys-shape-0);
    border: 1px solid var(--sys-color-divider-tertiary);
  }

  .import-status {
    padding: 10px;
    border-radius: var(--sys-shape-0);
    font-size: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .import-status-success {
    background: rgba(74, 222, 128, 0.1);
    border: 1px solid rgba(74, 222, 128, 0.3);
    color: #4ade80;
  }

  .import-status-error {
    background: rgba(248, 113, 113, 0.1);
    border: 1px solid rgba(248, 113, 113, 0.3);
    color: #f87171;
  }

  /* Rich Text Section Styles */
  .content-type-selector {
    display: flex;
    gap: 8px;
    margin-bottom: 12px;
  }

  .content-type-btn {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 10px 12px;
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-1);
    background: var(--sys-color-surface-paper);
    cursor: pointer;
    transition: all 0.15s ease;
    font-size: 12px;
    color: var(--sys-color-text-dark);

    &:hover {
      border-color: var(--sys-color-primary-main);
      background: rgba(74, 144, 164, 0.05);
    }

    &.active {
      border-color: var(--sys-color-primary-main);
      background: var(--sys-color-primary-main);
      color: white;
    }

    &.active svg {
      color: white;
    }
  }

  .content-type-btn svg {
    width: 16px;
    height: 16px;
    color: var(--sys-color-text-regular);
    transition: color 0.15s ease;
  }

  .rich-text-editor {
    width: 100%;
    min-height: 120px;
    padding: 10px;
    font-size: 12px;
    font-family: monospace;
    border: 1px solid var(--sys-color-divider-secondary);
    border-radius: var(--sys-shape-0);
    resize: vertical;
    line-height: 1.5;
  }

  .rich-text-help {
    font-size: 11px;
    color: var(--sys-color-text-regular);
    margin-top: 6px;
    line-height: 1.5;
    padding: 8px;
    background: var(--sys-color-surface-background);
    border-radius: var(--sys-shape-0);
    border: 1px solid var(--sys-color-divider-tertiary);
  }

  .rich-text-help code {
    background: rgba(0, 0, 0, 0.1);
    padding: 1px 4px;
    border-radius: 3px;
    font-size: 10px;
  }

  .button-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-top: 8px;
  }

  .button-item {
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 10px;
    border: 1px solid var(--sys-color-divider-tertiary);
    border-radius: var(--sys-shape-0);
    background: var(--sys-color-surface-background);
  }

  .button-item-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .button-item-row {
    display: flex;
    gap: 8px;
    align-items: center;
  }

  .button-item-row > * {
    flex: 1;
  }

  .button-style-selector {
    display: flex;
    gap: 4px;
  }

  .button-style-btn {
    flex: 1;
    padding: 4px 8px;
    font-size: 10px;
    border: 1px solid var(--sys-color-divider-secondary);
    background: var(--sys-color-surface-paper);
    cursor: pointer;
    transition: all 0.15s ease;

    &:first-child {
      border-radius: var(--sys-shape-0) 0 0 var(--sys-shape-0);
    }

    &:last-child {
      border-radius: 0 var(--sys-shape-0) var(--sys-shape-0) 0;
    }

    &.active {
      background: var(--sys-color-primary-main);
      border-color: var(--sys-color-primary-main);
      color: white;
    }

    &:hover:not(.active) {
      background: rgba(255, 255, 255, 0.1);
    }
  }

  /* ColorField inline validation message */
  .color-field-error {
    color: #B91C1C;
    font-size: 11px;
    margin-top: 2px;
    display: block;
  }
`
