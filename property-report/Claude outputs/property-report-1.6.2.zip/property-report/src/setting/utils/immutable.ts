// Immutable-to-mutable conversion helpers for the setting panel. This module owns
// the toMutable* functions that turn jimu-core Immutable arrays (or already-plain
// arrays) into fresh mutable copies before the setting code edits them and writes
// them back through onSettingChange. Behaviour matches the original inline
// helpers in setting.tsx, including the 'n' to 'name' normalisation for fields.
import type { SectionConfig, LayerConfig, FieldConfig, SearchSourceConfig, RichTextButton } from '../../config'

// Helper functions for Immutable conversion
export const toMutableSections = (sections: any): SectionConfig[] => {
    if (!sections) return []
    if (typeof sections.asMutable === 'function') {
        return sections.asMutable({ deep: true })
    }
    return [...sections]
}

export const toMutableLayers = (layers: any): LayerConfig[] => {
    if (!layers) return []
    if (typeof layers.asMutable === 'function') {
        return layers.asMutable({ deep: true })
    }
    // Deep copy to ensure nested objects are mutable
    return layers.map((l: any) => {
        if (typeof l.asMutable === 'function') {
            return l.asMutable({ deep: true })
        }
        return { ...l }
    })
}

export const toMutableFields = (fields: any): FieldConfig[] => {
    if (!fields) return []
    let result: any[]
    if (typeof fields.asMutable === 'function') {
        result = fields.asMutable({ deep: true })
    } else {
        // Deep copy to ensure nested objects like format are mutable
        result = fields.map((f: any) => {
            if (typeof f.asMutable === 'function') {
                return f.asMutable({ deep: true })
            }
            // Manual deep copy for plain objects
            return {
                ...f,
                format: f.format ? { ...f.format } : undefined
            }
        })
    }
    // Normalize: XML import may store field name as 'n' instead of 'name'
    return result.map((f: any) => {
        if (f.n !== undefined && f.name === undefined) {
            const { n, ...rest } = f
            return { name: n, ...rest }
        }
        return f
    })
}

export const toMutableSearchSources = (sources: any): SearchSourceConfig[] => {
    if (!sources) return []
    if (typeof sources.asMutable === 'function') {
        return sources.asMutable({ deep: true })
    }
    return [...sources]
}

export const toMutableStringArray = (arr: any): string[] => {
    if (!arr) return []
    if (typeof arr.asMutable === 'function') {
        return arr.asMutable({ deep: true })
    }
    return [...arr]
}

export const toMutableRichTextButtons = (buttons: any): RichTextButton[] => {
    if (!buttons) return []
    if (typeof buttons.asMutable === 'function') {
        return buttons.asMutable({ deep: true })
    }
    return [...buttons]
}
