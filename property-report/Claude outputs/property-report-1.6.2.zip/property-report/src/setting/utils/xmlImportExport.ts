// XML import and export for Property Report widget settings. This module owns the
// pure serialisation and parsing logic that used to live inside the setting
// component: escapeXml, valueToXml, exportSettingsToXml (config to XML text),
// parseXmlElement (XML element to value) and importSettingsFromXml (XML text plus
// the current config to a merged config). File reading, downloads and status
// messages stay in the UI layer. Hardening applied here versus the original:
// dangerous tag names (__proto__, constructor, prototype) are rejected, top-level
// keys are whitelisted against CONFIG_KEYS, string leaves are no longer trimmed,
// empty containers round-trip as [] / {} through a type attribute, and 'value'
// is treated as string-only so numeric-looking text is preserved.
import type { Config } from '../../config'
import { CONFIG_KEYS } from '../../defaults'

/** Tag names that must never be used as object keys when parsing. */
export const FORBIDDEN_KEYS = new Set(['__proto__', 'constructor', 'prototype'])

/** Keys whose leaf text must stay a string even when it looks numeric or boolean. */
// Comprehensive list of keys that should always remain strings (IDs, names, URLs, colors, etc.)
// This prevents numeric-looking strings like "2945-144-01-012" from being parsed as numbers
// Updated for version 1.9 - includes all config.ts string fields
export const stringOnlyKeys = new Set<string>([
    // IDs and identifiers (string-based IDs only)
    'sectionId', 'layerId', 'sourceId', 'buttonId', 'dataSourceId', 'tableId', 'actionId',
    'mapWidgetId',

    // Names and titles
    'name', 'alias', 'layerTitle', 'sectionTitle', 'sourceName', 'tableName',
    'organizationName', 'geocoderName', 'label', 'linkText',
    'reportTitle', 'subtitleText', 'pdfTitle', 'resultsPanelTitle',
    'tocTitle', 'separatePaneTitle', 'paneTitle',

    // URLs and file references
    'url', 'layerUrl', 'geocoderUrl', 'tableUrl', 'basemapUrl', 'urlTemplate', 'linkBaseUrl',
    'base64', 'logoBase64', 'regularBase64', 'boldBase64',
    'fileName', 'logoFileName', 'linkUrlField',

    // Field references (field names that could look like numbers)
    'displayField', 'chartField', 'categoryField', 'valueField', 'groupByField',
    'sortField', 'defaultSortField', 'primaryKeyField', 'foreignKeyField',
    'imageField', 'fieldName', 'xAxisLabel', 'yAxisLabel',
    'titleField', 'subtitleField', 'subtitleSuffix', 'subtitlePrefix',

    // Colors (hex values that could be parsed incorrectly)
    'primaryColor', 'sectionHeaderColor', 'sectionHeaderTextColor', 'alternateRowColor',
    'borderColor', 'linkColor', 'headerColor', 'headerTextColor', 'footerColor', 'footerTextColor',
    'tableHeaderBgColor', 'tableHeaderTextColor', 'tableDataTextColor', 'tableBorderColor',
    'layerTitleBgColor', 'layerTitleTextColor',
    'highlightColor', 'backgroundColor', 'color', 'rowHighlightColor', 'showAllOnMapColor',
    'relatedTableHeaderColor',

    // Text content (could contain any characters)
    'richTextContent', 'disclaimerText', 'contactText', 'chartDescription',
    'altText', 'accessibilityContact', 'prefix', 'suffix', 'customNoResultsText',

    // PDF Accessibility text/template fields
    'documentLanguage', 'documentAuthor', 'documentCreator',
    'mapAltTextTemplate', 'logoAltTextTemplate', 'chartAltTextTemplate',
    'tableSummaryTemplate', 'relatedTableSummaryTemplate',

    // Enum/type strings (must stay as strings, not parsed as other types)
    'type', 'numberFormat', 'dateFormat', 'textFormat',
    'coordinateSystem', 'coordinateFormat', 'customCoordinateLabel', 'dataLayout', 'bufferUnit', 'spatialBufferUnit',
    'titleMode', 'sizeMode', 'position', 'verticalAlign', 'shape',
    'legendPosition', 'pageNumberPosition', 'contactPosition', 'titlePosition', 'datePosition',
    'richTextPosition', 'headerLayout', 'pageNumberFormat', 'chartType', 'chartMode',
    'style', 'curveType', 'sortBy', 'sortOrder', 'defaultSortOrder',
    'relationshipType', 'spatialRelationship', 'displayMode', 'aggregation',
    'chartDescriptionPosition', 'attributeLayout', 'icon', 'fontFamily',
    'displayPane', 'searchRadiusUnit', 'distanceUnit',

    // Custom font name
    'customFontName',

    // v1.2.0 additions: report summary template, permalink param, and section alert fields
    'reportSummaryTemplate', 'permalinkParam',
    'alertId', 'field', 'operator', 'severity', 'message',

    // Alert comparison values may be numeric-looking strings (zip codes, parcel ids)
    'value'
])

/** Arrays whose items should always be strings (NOT number arrays like pageSizeOptions). */
export const stringArrayKeys = new Set<string>([
    'searchFields', 'colorScheme',
    'primaryFields', 'secondaryFields', 'valueFields',
    'compareFields'  // Chart compare fields array
])

// Helper to escape XML special characters
export const escapeXml = (str: string): string => {
    if (typeof str !== 'string') return String(str || '')
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;')
}

// Helper to convert a value to XML element
export const valueToXml = (key: string, value: any, indent: string = ''): string => {
    if (value === null || value === undefined) {
        return `${indent}<${key} />\n`
    }

    if (Array.isArray(value) || (value && typeof value.asMutable === 'function')) {
        const arr = typeof value.asMutable === 'function' ? value.asMutable({ deep: true }) : value
        if (arr.length === 0) {
            // type attribute lets the importer restore an empty array instead of null
            return `${indent}<${key} type="array"></${key}>\n`
        }
        let xml = `${indent}<${key}>\n`
        arr.forEach((item: any) => {
            xml += valueToXml('item', item, indent + '  ')
        })
        xml += `${indent}</${key}>\n`
        return xml
    }

    if (typeof value === 'object') {
        const obj = typeof value.asMutable === 'function' ? value.asMutable({ deep: true }) : value
        const keys = Object.keys(obj)
        if (keys.length === 0) {
            // type attribute lets the importer restore an empty object instead of null
            return `${indent}<${key} type="object"></${key}>\n`
        }
        let xml = `${indent}<${key}>\n`
        keys.forEach((k: string) => {
            xml += valueToXml(k, obj[k], indent + '  ')
        })
        xml += `${indent}</${key}>\n`
        return xml
    }

    if (typeof value === 'boolean') {
        return `${indent}<${key}>${value ? 'true' : 'false'}</${key}>\n`
    }

    if (typeof value === 'number') {
        return `${indent}<${key}>${value}</${key}>\n`
    }

    return `${indent}<${key}>${escapeXml(String(value))}</${key}>\n`
}

// Ensure field configs use 'name' (not the legacy 'n') so XML is portable
const normalizeFieldConfig = (field: any): any => {
    if (!field || typeof field !== 'object') return field
    // If field has 'n' but not 'name', rename 'n' to 'name'
    if (field.n !== undefined && field.name === undefined) {
        const { n, ...rest } = field
        return { name: n, ...rest }
    }
    return field
}

const normalizeExportFields = (fieldArr: any[]): any[] => {
    if (!Array.isArray(fieldArr)) return fieldArr
    return fieldArr.map(normalizeFieldConfig)
}

// Walks sections -> layers -> fields / relatedTables and headerInfo.displayFields,
// renaming 'n' to 'name'. Mutates and returns the given settings object.
export const normalizeFieldsInSettings = (settings: any): any => {
    if (!settings) return settings

    if (settings.sections && Array.isArray(settings.sections)) {
        settings.sections = settings.sections.map((section: any) => {
            if (section && section.layers && Array.isArray(section.layers)) {
                section.layers = section.layers.map((layer: any) => {
                    if (!layer) return layer
                    if (layer.fields && Array.isArray(layer.fields)) {
                        layer.fields = normalizeExportFields(layer.fields)
                    }
                    if (layer.relatedTables && Array.isArray(layer.relatedTables)) {
                        layer.relatedTables = layer.relatedTables.map((rt: any) => {
                            if (rt && rt.fields && Array.isArray(rt.fields)) {
                                rt.fields = normalizeExportFields(rt.fields)
                            }
                            return rt
                        })
                    }
                    return layer
                })
            }
            return section
        })
    }

    if (settings.headerInfo?.displayFields && Array.isArray(settings.headerInfo.displayFields)) {
        settings.headerInfo.displayFields = normalizeExportFields(settings.headerInfo.displayFields)
    }

    return settings
}

/**
 * Serialise the widget config (minus mapWidgetId) to the settings XML document.
 * Accepts an Immutable config or a plain object. Returns the XML text; the caller
 * is responsible for downloading it.
 */
export const exportSettingsToXml = (config: any): string => {
    // Get all config except mapWidgetId
    const configToExport: any = {}

    // Copy all config properties except mapWidgetId
    const configObj = config && typeof config.asMutable === 'function'
        ? config.asMutable({ deep: true })
        : { ...(config || {}) }

    Object.keys(configObj).forEach((key: string) => {
        if (key !== 'mapWidgetId') {
            configToExport[key] = configObj[key]
        }
    })

    // Normalize field configs before export: ensure 'name' property (not 'n')
    // This guarantees portable XML that uses consistent <name> tags
    normalizeFieldsInSettings(configToExport)

    // Build XML with comprehensive comments
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n'
    xml += '<!-- ============================================== -->\n'
    xml += '<!-- Experience Builder Property Report Widget Settings -->\n'
    xml += `<!-- Exported: ${new Date().toISOString()} -->\n`
    xml += '<!-- ============================================== -->\n'
    xml += '<!-- \n'
    xml += '  This file contains all widget settings EXCEPT map connection.\n'
    xml += '  \n'
    xml += '  =====================================================\n'
    xml += '  TOP-LEVEL SETTINGS:\n'
    xml += '  =====================================================\n'
    xml += '  - searchSources (geocoders, layer searches, URL searches)\n'
    xml += '      - sourceId, sourceName, enabled, type\n'
    xml += '      - geocoderUrl, geocoderName\n'
    xml += '      - dataSourceId, useDataSource, searchFields, displayField\n'
    xml += '      - exactMatch, maxSuggestions, url\n'
    xml += '      - highlightEnabled, highlightColor\n'
    xml += '  \n'
    xml += '  - sections (data display configuration)\n'
    xml += '      - sectionId, sectionTitle, expanded\n'
    xml += '      - displayAsTable, displayAsChart, chartField\n'
    xml += '      - displayPane (inline/separate), separatePaneTitle, separatePaneThreshold\n'
    xml += '      - richTextContent, richTextButtons, richTextPosition\n'
    xml += '      - excludeFromPdf, chartExcludeFromPdf, richTextExcludeFromPdf\n'
    xml += '      - chartConfig, tableConfig\n'
    xml += '      - layers[] (see LAYER CONFIG below)\n'
    xml += '  \n'
    xml += '  - headerInfo (parcel info layer for report header)\n'
    xml += '      - enabled, dataSourceId, useDataSource, layerUrl\n'
    xml += '      - displayFields[] (name, alias, visible, format, excludeFromPdf, hideNull)\n'
    xml += '      - geocoderUrl\n'
    xml += '  \n'
    xml += '  - highlightLayer (geometry highlighting on search)\n'
    xml += '      - enabled, dataSourceId, useDataSource, layerUrl\n'
    xml += '      - highlightColor, fillOpacity, outSpatialReference\n'
    xml += '      - geometryOffsetX, geometryOffsetY (datum correction)\n'
    xml += '  \n'
    xml += '  - propertyPreview (feature preview card at top of results)\n'
    xml += '      - enabled, showMapPreview, mapPreviewHeight, mapPreviewZoomLevel\n'
    xml += '      - showBasemap, highlightColor, basemapUrl\n'
    xml += '      - imageField, imageHeight\n'
    xml += '      - showAttributes, attributeLayout (horizontal/vertical/grid)\n'
    xml += '      - primaryFields[], secondaryFields[]\n'
    xml += '      - showZoomButton, showCopyButton\n'
    xml += '      - customActions[] (actionId, label, icon, urlTemplate, openInNewTab)\n'
    xml += '  \n'
    xml += '  - resultsPanelTitle\n'
    xml += '  \n'
    xml += '  =====================================================\n'
    xml += '  LAYER CONFIG OPTIONS (per layer within section):\n'
    xml += '  =====================================================\n'
    xml += '  - layerId, layerTitle\n'
    xml += '  - dataSourceId, useDataSource, layerUrl\n'
    xml += '  - fields[] (name, alias, visible, format, excludeFromPdf, hideNull)\n'
    xml += '  - bufferDistance, bufferUnit\n'
    xml += '  - expanded (default expanded state: true=expanded, false=collapsed)\n'
    xml += '  - displayMode (table/list/card - how to display multiple records)\n'
    xml += '  - defaultSortField, defaultSortOrder (asc/desc)\n'
    xml += '  - enableRowHighlight, enableRowZoom, showAllOnMap\n'
    xml += '  - showAllOnMapColor, rowHighlightColor, rowHighlightFillOpacity, rowZoomScale\n'
    xml += '  - useCustomNoResultsText, customNoResultsText\n'
    xml += '  \n'
    xml += '  - relatedTables[] (related data configuration)\n'
    xml += '      - tableId, tableName, tableUrl\n'
    xml += '      - relationshipType (key/relationshipClass/spatial)\n'
    xml += '      - primaryKeyField, foreignKeyField (for key relationships)\n'
    xml += '      - relationshipId (for relationship class)\n'
    xml += '      - spatialRelationship, spatialBuffer, spatialBufferUnit, useParentGeometry\n'
    xml += '      - fields[] (with excludeFromPdf, hideNull options per field)\n'
    xml += '      - displayMode (table/list/card), maxRecords\n'
    xml += '      - expanded (default expanded state: true=expanded, false=collapsed)\n'
    xml += '      - displayPane (inline/separate), separatePaneTitle\n'
    xml += '      - sortField, sortOrder, enableInteractiveSorting\n'
    xml += '      - defaultSortField, defaultSortOrder\n'
    xml += '      - enableChart, chartConfig\n'
    xml += '      - groupByField, aggregateFields[] (fieldName, aggregation, alias)\n'
    xml += '      - pdfIncludeChart, pdfMaxRecords, pdfExclude, pdfShowTableSummary\n'
    xml += '  \n'
    xml += '  - nearbyConfig (distance-sorted feature display)\n'
    xml += '      - enabled, titleField, subtitleField, subtitleSuffix, subtitlePrefix\n'
    xml += '      - linkUrlField\n'
    xml += '      - maxFeatures, searchRadius, searchRadiusUnit\n'
    xml += '      - distanceUnit, distancePrecision, showDistanceBadge\n'
    xml += '      - sortOrder\n'
    xml += '      - includeInPdf, pdfMaxFeatures\n'
    xml += '  \n'
    xml += '  - layerRichTextContent (HTML content for layer-level info)\n'
    xml += '  - layerRichTextButtons[] (buttonId, label, url, style, openInNewTab)\n'
    xml += '  - layerRichTextPosition (before/after)\n'
    xml += '  - layerRichTextExcludeFromPdf\n'
    xml += '  - hideLayerRichTextWhenNoResults\n'
    xml += '  \n'
    xml += '  =====================================================\n'
    xml += '  PROPERTY PREVIEW (propertyPreview)\n'
    xml += '  =====================================================\n'
    xml += '  - enabled\n'
    xml += '  - showMapPreview, mapPreviewHeight, mapPreviewZoomLevel\n'
    xml += '  - showBasemap, highlightColor, basemapUrl\n'
    xml += '  - imageField, imageHeight\n'
    xml += '  - showAttributes, attributeLayout (horizontal/vertical/grid)\n'
    xml += '  - primaryFields[], secondaryFields[]\n'
    xml += '  - showZoomButton, showCopyButton\n'
    xml += '  - customActions[] (actionId, label, icon, urlTemplate, openInNewTab)\n'
    xml += '  \n'
    xml += '  =====================================================\n'
    xml += '  PDF EXPORT SETTINGS\n'
    xml += '  =====================================================\n'
    xml += '  - pdfTitle, pdfIncludeTables, pdfIncludeCharts\n'
    xml += '  - pdfIncludeRelatedTables, pdfIncludeRelatedTableCharts\n'
    xml += '  \n'
    xml += '  - pdfHeader (header configuration)\n'
    xml += '      - logoBase64, logoFileName, logoWidth, logoHeight (legacy)\n'
    xml += '      - logo (enhanced logo configuration):\n'
    xml += '          base64, fileName, originalWidth, originalHeight,\n'
    xml += '          sizeMode (auto/fit/stretch/custom), customWidth, customHeight,\n'
    xml += '          maxWidth, maxHeight, position (left/center/right),\n'
    xml += '          verticalAlign (top/middle/bottom), shape (default/circle/rounded),\n'
    xml += '          borderRadius, backgroundColor, padding, altText\n'
    xml += '      - headerHeight, organizationName\n'
    xml += '      - showTitle, titleFontSize, titleMode (default/custom)\n'
    xml += '      - reportTitle, subtitleText\n'
    xml += '      - headerTextColor, headerColor\n'
    xml += '      - includeMap, mapHeight, mapScaleMode, mapScale, mapFitPadding\n'
    xml += '      - showGeneratedDate\n'
    xml += '      - titlePosition, datePosition, headerLayout\n'
    xml += '  \n'
    xml += '  - pdfFooter (footer configuration)\n'
    xml += '      - enabled, showPageNumbers, pageNumberFormat, pageNumberPosition\n'
    xml += '      - disclaimerText, disclaimerFontSize\n'
    xml += '      - contactText, contactPosition\n'
    xml += '      - footerHeight, footerColor, footerTextColor, showTopBorder\n'
    xml += '  \n'
    xml += '  - pdfStyle (styling and layout)\n'
    xml += '      - primaryColor, sectionHeaderColor, sectionHeaderTextColor\n'
    xml += '      - alternateRowColor, borderColor, linkColor\n'
    xml += '      - fontFamily (helvetica/times/courier/Noto Sans/Roboto/etc/custom)\n'
    xml += '      - customFont (name, regularBase64, boldBase64)\n'
    xml += '      - dataLayout (table/two-column/cards/auto), twoColumnGap\n'
    xml += '      - showSectionBorders, compactMode\n'
    xml += '      - tableHeaderBgColor, tableHeaderTextColor, tableHeaderFontSize\n'
    xml += '      - layerTitleBgColor, layerTitleTextColor\n'
    xml += '      - tableHeaderHeight, tableDataFontSize, tableDataTextColor\n'
    xml += '      - tableRowHeight, tableShowBorders, tableBorderColor\n'
    xml += '      - tableStripedRows, tableMaxColumns, tableMaxRows, tableCellPadding\n'
    xml += '      - showAccessibilityText, showTableSummaries, showRelatedTableSummaries\n'
    xml += '      - showFullUrlsInPdf\n'
    xml += '      - enablePdfBookmarks, enableHierarchicalBookmarks\n'
    xml += '      - showSectionNumbers, showGeneratedTimestamp\n'
    xml += '      - accessibilityContact, highContrastMode, largeTextMode\n'
    xml += '      - enableTableOfContents, tocTitle, tocIncludeLayers\n'
    xml += '      - tocIncludeRelatedTables, tocPageBreakAfter\n'
    xml += '      - relatedTableHeaderColor, relatedTableIndent\n'
    xml += '      - relatedTableMaxRows, includeRelatedTableCharts\n'
    xml += '  \n'
    xml += '  - pdfAccessibility (WCAG 2.1 compliance)\n'
    xml += '      - documentLanguage (130+ language codes supported)\n'
    xml += '      - documentAuthor, documentCreator\n'
    xml += '      - includeMapAltText, includeLogoAltText\n'
    xml += '      - mapAltTextTemplate, logoAltTextTemplate, chartAltTextTemplate\n'
    xml += '      - includeTableSummaries, tableSummaryTemplate\n'
    xml += '      - includeRelatedTableSummaries, relatedTableSummaryTemplate\n'
    xml += '      - minimumFontSize, includeReadingOrderMarkers\n'
    xml += '      - tocTitle\n'
    xml += '  \n'
    xml += '  =====================================================\n'
    xml += '  DEFAULT CONFIGURATIONS\n'
    xml += '  =====================================================\n'
    xml += '  - defaultChartConfig (global chart settings)\n'
    xml += '      - chartType (bar/pie/donut/area/line/radialBar/composite)\n'
    xml += '      - chartMode (category/fields)\n'
    xml += '      - categoryField, valueField, aggregation (count/sum/avg/min/max)\n'
    xml += '      - compareFields[] (fieldName, alias, color, enabled)\n'
    xml += '      - groupByField, valueFields[]\n'
    xml += '      - showLegend, legendPosition (top/bottom/left/right)\n'
    xml += '      - showValues, showGrid, animate, stacked\n'
    xml += '      - curveType (linear/natural/monotone/step)\n'
    xml += '      - colorScheme[], height\n'
    xml += '      - xAxisLabel, yAxisLabel\n'
    xml += '      - maxCategories, sortBy (value/label/none), sortOrder (asc/desc)\n'
    xml += '      - chartDescription, chartDescriptionPosition (before/after)\n'
    xml += '  \n'
    xml += '  - defaultTableConfig (global table settings)\n'
    xml += '      - enableSorting, enableFiltering, enablePagination\n'
    xml += '      - pageSize, pageSizeOptions[], stickyHeader\n'
    xml += '      - stripedRows, highlightOnHover, compactMode\n'
    xml += '      - showRowNumbers, resizableColumns\n'
    xml += '  \n'
    xml += '  =====================================================\n'
    xml += '  PERFORMANCE SETTINGS\n'
    xml += '  =====================================================\n'
    xml += '  - enableClientSideQuery (use LayerView for faster queries)\n'
    xml += '  \n'
    xml += '  =====================================================\n'
    xml += '  SEARCH & DISPLAY SETTINGS\n'
    xml += '  =====================================================\n'
    xml += '  - combinedMaxSuggestions, showSourceLabels\n'
    xml += '  - coordinateSystem (map/wgs84/webmercator/custom)\n'
    xml += '  - customCoordinateWkid (EPSG/WKID code)\n'
    xml += '  - customCoordinateLabel (display label)\n'
    xml += '  - coordinateFormat (decimal/dms)\n'
    xml += '  - coordinatePrecision, showCoordinates\n'
    xml += '  - enableUseCurrentLocation (GPS location button)\n'
    xml += '  \n'
    xml += '  =====================================================\n'
    xml += '  FIELD FORMAT OPTIONS (per field)\n'
    xml += '  =====================================================\n'
    xml += '  - type (auto/number/date/text/link)\n'
    xml += '  - numberFormat (default/none/currency/percent/decimal)\n'
    xml += '  - decimalPlaces, useGrouping\n'
    xml += '  - dateFormat (default/short/medium/long/year-only)\n'
    xml += '  - textFormat (default/uppercase/lowercase/titlecase)\n'
    xml += '  - prefix, suffix, linkText\n'
    xml += '  - useLinkBaseUrl, linkBaseUrl (prepend base URL to field value for links)\n'
    xml += '  - excludeFromPdf, hideNull\n'
    xml += '  \n'
    xml += '  =====================================================\n'
    xml += '  RICH TEXT CONFIGURATION (per section)\n'
    xml += '  =====================================================\n'
    xml += '  - richTextContent (HTML)\n'
    xml += '  - richTextButtons[] (buttonId, label, url, style, openInNewTab)\n'
    xml += '  - richTextPosition (before/after)\n'
    xml += '  - richTextExcludeFromPdf\n'
    xml += '  \n'
    xml += '  NOTE: Data source connections (useDataSource) are exported but may need\n'
    xml += '  to be reconfigured after import if data sources have different IDs.\n'
    xml += '  Layers configured with direct URLs (layerUrl) will work without changes.\n'
    xml += '  \n'
    xml += '  To import: Use the Import button in widget settings.\n'
    xml += '  Map widget connection must be configured separately.\n'
    xml += '-->\n'
    xml += '<WidgetSettings version="2.2">\n'

    Object.keys(configToExport).forEach((key: string) => {
        xml += valueToXml(key, configToExport[key], '  ')
    })

    xml += '</WidgetSettings>\n'
    return xml
}

/**
 * Parse one XML element into a JS value. Leaves become string / number / boolean
 * (or null when empty, unless a type="array" / type="object" attribute asks for an
 * empty container). Elements whose children are all <item> become arrays; other
 * elements become objects. Children with forbidden tag names are skipped and
 * reported through the optional warnings array.
 */
export const parseXmlElement = (element: Element, parentKey?: string, warnings?: string[]): any => {
    const children = Array.from(element.children)
    const tagName = element.tagName

    // No children - return text content or null
    if (children.length === 0) {
        const raw = element.textContent ?? ''
        const trimmed = raw.trim()
        if (trimmed === '') {
            // Empty element: honour the exporter's container hint, else null as before
            const typeAttr = element.getAttribute('type')
            if (typeAttr === 'array') return []
            if (typeAttr === 'object') return {}
            return null
        }

        // If this key should always be a string, return as string (untrimmed)
        if (stringOnlyKeys.has(tagName)) {
            return raw
        }

        // If this is an item in a string array, return as string (untrimmed)
        if (tagName === 'item' && parentKey && stringArrayKeys.has(parentKey)) {
            return raw
        }

        if (trimmed === 'true') return true
        if (trimmed === 'false') return false
        // Only parse as number if it's purely numeric (and not an ID-like field)
        if (/^-?\d+(\.\d+)?$/.test(trimmed)) return parseFloat(trimmed)
        return raw
    }

    // Check if all children are 'item' elements (array)
    const allItems = children.every(child => child.tagName === 'item')
    if (allItems && children.length > 0) {
        return children.map(child => parseXmlElement(child, tagName, warnings))
    }

    // Object with named properties
    const obj: any = {}
    children.forEach(child => {
        const key = child.tagName
        if (FORBIDDEN_KEYS.has(key)) {
            if (warnings) warnings.push(`Ignored unsafe element <${key}> inside <${tagName}>`)
            return
        }
        obj[key] = parseXmlElement(child, key, warnings)
    })
    return obj
}

export interface ImportSettingsResult {
    /** The merged config (same shape as currentConfig: Immutable if it was Immutable). */
    config: any
    /** Human readable notes about anything skipped during import. */
    warnings: string[]
    /** Top-level keys that were applied to the config. */
    importedKeys: string[]
    /** The parsed top-level values that were applied, for building status messages. */
    imported: Record<string, any>
    /** The version attribute from the WidgetSettings root ('1.0' when absent). */
    version: string
}

/**
 * Parse a settings XML document and merge it onto currentConfig. Throws an Error
 * with a user-facing message when the XML is malformed or the root is wrong.
 * mapWidgetId is never imported and is always preserved from currentConfig.
 * Unknown top-level keys (not in CONFIG_KEYS) are skipped with a warning.
 */
export const importSettingsFromXml = (xmlText: string, currentConfig: any): ImportSettingsResult => {
    const warnings: string[] = []

    const parser = new DOMParser()
    const xmlDoc = parser.parseFromString(xmlText, 'application/xml')

    // Check for parse errors
    const parseError = xmlDoc.querySelector('parsererror')
    if (parseError) {
        throw new Error('Invalid XML file format')
    }

    const root = xmlDoc.documentElement
    if (!root || root.tagName !== 'WidgetSettings') {
        throw new Error('Invalid settings file format - missing WidgetSettings root element')
    }

    // Get version for compatibility handling
    const version = root.getAttribute('version') || '1.0'

    const allowedKeys = new Set<string>(CONFIG_KEYS as string[])

    // Parse all settings from XML
    const importedSettings: Record<string, any> = {}
    const importedKeys: string[] = []

    Array.from(root.children).forEach(child => {
        const key = child.tagName
        // Skip mapWidgetId if somehow present
        if (key === 'mapWidgetId') return
        if (FORBIDDEN_KEYS.has(key)) {
            warnings.push(`Ignored unsafe top-level element <${key}>`)
            return
        }
        if (!allowedKeys.has(key)) {
            warnings.push(`Ignored unknown setting <${key}>`)
            return
        }
        importedSettings[key] = parseXmlElement(child, key, warnings)
        importedKeys.push(key)
    })

    // Normalize field configs: XML may use <n> for field names but runtime expects 'name'
    normalizeFieldsInSettings(importedSettings)

    // Preserve the current mapWidgetId
    const isImmutable = currentConfig && typeof currentConfig.set === 'function'
    const currentMapWidgetId = currentConfig ? currentConfig.mapWidgetId : undefined

    // Apply imported settings
    let newConfig: any = currentConfig || {}
    if (isImmutable) {
        Object.keys(importedSettings).forEach((key: string) => {
            newConfig = newConfig.set(key, importedSettings[key])
        })
        // Ensure mapWidgetId is preserved
        newConfig = newConfig.set('mapWidgetId', currentMapWidgetId)
    } else {
        newConfig = { ...newConfig, ...importedSettings, mapWidgetId: currentMapWidgetId }
    }

    return { config: newConfig as Config | any, warnings, importedKeys, imported: importedSettings, version }
}

/**
 * Build the human readable detail fragments used in the import success message
 * (for example "2 search sources", "3 sections", "PDF header (logo, map)").
 * Pure; takes the `imported` map returned by importSettingsFromXml.
 */
export const describeImportedSettings = (importedSettings: Record<string, any>): string[] => {
    const details: string[] = []
    if (importedSettings.searchSources?.length) details.push(`${importedSettings.searchSources.length} search sources`)
    if (importedSettings.sections?.length) {
        let layerCount = 0
        let relatedTableCount = 0
        let nearbyCount = 0
        let pdfExcludedCount = 0
        let chartCount = 0
        let richTextCount = 0
        importedSettings.sections.forEach((s: any) => {
            if (s.excludeFromPdf) pdfExcludedCount++
            if (s.chartConfig || s.displayAsChart) chartCount++
            if (s.richTextContent) richTextCount++
            if (s.layers?.length) {
                layerCount += s.layers.length
                s.layers.forEach((l: any) => {
                    if (l.relatedTables?.length) relatedTableCount += l.relatedTables.length
                    if (l.nearbyConfig?.enabled) nearbyCount++
                })
            }
        })
        details.push(`${importedSettings.sections.length} sections`)
        if (layerCount > 0) details.push(`${layerCount} layers`)
        if (relatedTableCount > 0) details.push(`${relatedTableCount} related tables`)
        if (nearbyCount > 0) details.push(`${nearbyCount} nearby configs`)
        if (chartCount > 0) details.push(`${chartCount} charts`)
        if (richTextCount > 0) details.push(`${richTextCount} rich text blocks`)
        if (pdfExcludedCount > 0) details.push(`${pdfExcludedCount} PDF-excluded sections`)
    }
    if (importedSettings.headerInfo?.enabled) details.push('header info')
    if (importedSettings.highlightLayer?.enabled) details.push('highlight layer')
    if (importedSettings.propertyPreview?.enabled) {
        const previewDetails: string[] = []
        if (importedSettings.propertyPreview.showMapPreview) previewDetails.push('map')
        if (importedSettings.propertyPreview.customActions?.length) previewDetails.push(`${importedSettings.propertyPreview.customActions.length} actions`)
        details.push(`property preview${previewDetails.length ? ' (' + previewDetails.join(', ') + ')' : ''}`)
    }
    if (importedSettings.pdfHeader) {
        const headerDetails: string[] = []
        if (importedSettings.pdfHeader.logo?.base64 || importedSettings.pdfHeader.logoBase64) headerDetails.push('logo')
        if (importedSettings.pdfHeader.includeMap !== false) headerDetails.push('map')
        details.push(`PDF header${headerDetails.length ? ' (' + headerDetails.join(', ') + ')' : ''}`)
    }
    if (importedSettings.pdfFooter?.enabled !== false) details.push('PDF footer')
    if (importedSettings.pdfStyle) {
        const styleDetails: string[] = []
        if (importedSettings.pdfStyle.fontFamily && importedSettings.pdfStyle.fontFamily !== 'helvetica') styleDetails.push(importedSettings.pdfStyle.fontFamily)
        if (importedSettings.pdfStyle.enableTableOfContents) styleDetails.push('TOC')
        if (importedSettings.pdfStyle.enablePdfBookmarks !== false) styleDetails.push('bookmarks')
        details.push(`PDF styles${styleDetails.length ? ' (' + styleDetails.join(', ') + ')' : ''}`)
    }
    if (importedSettings.pdfAccessibility) details.push('PDF accessibility')
    if (importedSettings.pdfIncludeRelatedTables) details.push('related tables in PDF')
    if (importedSettings.pdfIncludeRelatedTableCharts) details.push('related charts in PDF')
    if (importedSettings.defaultChartConfig) details.push('chart defaults')
    if (importedSettings.defaultTableConfig) details.push('table defaults')
    if (importedSettings.coordinateSystem || importedSettings.coordinateFormat || importedSettings.showCoordinates !== undefined || importedSettings.enableUseCurrentLocation !== undefined) details.push('coordinate settings')
    if (importedSettings.combinedMaxSuggestions || importedSettings.showSourceLabels !== undefined) details.push('search settings')
    if (importedSettings.enableClientSideQuery !== undefined) details.push('performance settings')
    if (importedSettings.resultsPanelTitle) details.push('panel title')
    return details
}
