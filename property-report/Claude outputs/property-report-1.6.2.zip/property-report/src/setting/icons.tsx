/** @jsx jsx */
// Icon components for the Property Report setting panel. This module owns every
// inline SVG icon used by the setting UI (chevrons, list actions, panel headers,
// import/export, rich text). Each icon is a stateless component with no props and
// is exported by name so the setting panel and its sub-components can share them.
import { React, jsx } from 'jimu-core'

// Simple SVG icons for compatibility
export const ChevronDownIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="12" height="12" fill="currentColor">
        <path d="M8 10.5L3 5.5h10L8 10.5z" />
    </svg>
)

export const ChevronRightIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="12" height="12" fill="currentColor">
        <path d="M5.5 3l5 5-5 5V3z" />
    </svg>
)

export const TrashIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
        <path d="M5 2V1h6v1h4v1H1V2h4zm1 3v8h1V5H6zm3 0v8h1V5H9zM2 4h12l-1 11H3L2 4z" />
    </svg>
)

export const MoveUpIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
        <path d="M8 3L3 8h3v5h4V8h3L8 3z" />
    </svg>
)

export const MoveDownIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
        <path d="M8 13l5-5h-3V3H6v5H3l5 5z" />
    </svg>
)

export const DragHandleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
        <path d="M5 3h2v2H5V3zm4 0h2v2H9V3zM5 7h2v2H5V7zm4 0h2v2H9V7zM5 11h2v2H5v-2zm4 0h2v2H9v-2z" />
    </svg>
)

export const PlusIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
        <path d="M7 7V2h2v5h5v2H9v5H7V9H2V7h5z" />
    </svg>
)

export const SearchIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="24" height="24" fill="currentColor">
        <path d="M11.5 6.5a5 5 0 1 0-2.12 4.09l4.06 4.06 1.41-1.41-4.06-4.06A5 5 0 0 0 11.5 6.5zm-5 3a3 3 0 1 1 0-6 3 3 0 0 1 0 6z" />
    </svg>
)

export const LayersIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="24" height="24" fill="currentColor">
        <path d="M8 1L1 4.5 8 8l7-3.5L8 1zM1 8l7 3.5L15 8l-1.5-.75L8 10 2.5 7.25 1 8zm0 3l7 3.5 7-3.5-1.5-.75L8 13l-5.5-2.75L1 11z" />
    </svg>
)

export const DataIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="24" height="24" fill="currentColor">
        <path d="M8 1C4.5 1 2 2.12 2 3.5v9C2 13.88 4.5 15 8 15s6-1.12 6-2.5v-9C14 2.12 11.5 1 8 1zm0 1c3.04 0 5 .9 5 1.5S11.04 5 8 5 3 4.1 3 3.5 4.96 2 8 2zm5 10.5c0 .6-1.96 1.5-5 1.5s-5-.9-5-1.5V11c1.12.63 2.96 1 5 1s3.88-.37 5-1v1.5zm0-3c0 .6-1.96 1.5-5 1.5s-5-.9-5-1.5V8c1.12.63 2.96 1 5 1s3.88-.37 5-1v1.5zm0-3c0 .6-1.96 1.5-5 1.5s-5-.9-5-1.5V5c1.12.63 2.96 1 5 1s3.88-.37 5-1v1.5z" />
    </svg>
)

export const PinIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="24" height="24" fill="currentColor">
        <path d="M8 1C5.24 1 3 3.24 3 6c0 4 5 9 5 9s5-5 5-9c0-2.76-2.24-5-5-5zm0 7a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" />
    </svg>
)

export const UploadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16" fill="currentColor">
        <path d="M8 1L4 5h3v6h2V5h3L8 1zM2 12v2h12v-2H2z" />
    </svg>
)

export const ImageIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M14 2H2v12h12V2zm-1 11H3V3h10v10zM6 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm6 6l-2-3-2 2-1.5-1.5L4 11h8z" />
    </svg>
)

export const PdfIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M3 1v14h10V5l-4-4H3zm7 1.5L12.5 5H10V2.5zM4 14V2h5v4h3v8H4z" />
    </svg>
)

export const MapIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M5.5 1L1 3v11l4.5-2 5 2 4.5-2V1l-4.5 2-5-2zM5 3.5v8l-3 1.3V4.2L5 3.5zm1 8V3.5l4 1.6v8L6 11.5zm5-6.4v8l3-1.3V3.2l-3 1.9z" />
    </svg>
)

export const ColorIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1zm0 12.5a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11zM8 4a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zm-3 4a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zm6 0a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z" />
    </svg>
)

export const FooterIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M2 2v12h12V2H2zm11 11H3V3h10v10zM4 11h8v1H4v-1zm0-2h8v1H4V9z" />
    </svg>
)

export const LayoutIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M2 2v12h12V2H2zm5 11H3V3h4v10zm6 0H8V9h5v4zm0-5H8V3h5v5z" />
    </svg>
)

export const ChartIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M1 14h14v1H1v-1zm1-1V7h2v6H2zm3 0V4h2v9H5zm3 0V1h2v12H8zm3 0V5h2v8h-2zm3 0V3h2v10h-2z" />
    </svg>
)

export const TableIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M0 2v12h16V2H0zm1 1h4v3H1V3zm0 4h4v3H1V7zm0 4h4v2H1v-2zm5-8h4v3H6V3zm0 4h4v3H6V7zm0 4h4v2H6v-2zm5-8h4v3h-4V3zm0 4h4v3h-4V7zm0 4h4v2h-4v-2z" />
    </svg>
)

export const CoordinateIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1zM2 8a6 6 0 0 1 .94-3.22l2.12 2.12L4 8l1.06 1.06-2.12 2.16A6 6 0 0 1 2 8zm6 6a5.96 5.96 0 0 1-3.22-.94l2.16-2.12L8 12l1.06-1.06 2.16 2.12A5.96 5.96 0 0 1 8 14zm3.22-.94l-2.16-2.12L8 10l-1.06 1.06-2.16-2.16.94-3.22A6 6 0 0 1 14 8a5.96 5.96 0 0 1-.94 3.22l-2.12-2.16L10 8l1.06-1.06 2.12 2.12A5.96 5.96 0 0 1 8 14z" />
        <circle cx="8" cy="8" r="1.5" />
    </svg>
)

export const ExportIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16" fill="currentColor">
        <path d="M8 1L4 5h3v6h2V5h3L8 1zM2 13v2h12v-2H2z" />
    </svg>
)

export const ImportIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16" fill="currentColor">
        <path d="M8 11l4-4H9V1H7v6H4l4 4zM2 13v2h12v-2H2z" />
    </svg>
)

export const SettingsIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M13.5 8c0-.3 0-.5-.1-.8l1.7-1.3-1.5-2.6-2.1.6c-.4-.3-.8-.6-1.3-.8L9.9 1H6.1l-.3 2.1c-.5.2-.9.5-1.3.8l-2.1-.6-1.5 2.6 1.7 1.3c-.1.3-.1.5-.1.8s0 .5.1.8l-1.7 1.3 1.5 2.6 2.1-.6c.4.3.8.6 1.3.8l.3 2.1h3.8l.3-2.1c.5-.2.9-.5 1.3-.8l2.1.6 1.5-2.6-1.7-1.3c.1-.3.1-.5.1-.8zM8 11c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3z" />
    </svg>
)

export const RichTextIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="20" height="20" fill="currentColor">
        <path d="M2 2v12h12V2H2zm11 11H3V3h10v10zM4 5h8v1H4V5zm0 2h8v1H4V7zm0 2h5v1H4V9z" />
    </svg>
)

export const LinkIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
        <path d="M6.879 9.934a.81.81 0 01-.575-.238 3.818 3.818 0 010-5.392l3-3C10.024.584 10.982.187 12 .187s1.976.397 2.696 1.117a3.818 3.818 0 010 5.392l-1.371 1.371a.813.813 0 01-1.149-1.149l1.371-1.371A2.19 2.19 0 0012 1.812c-.584 0-1.134.228-1.547.641l-3 3a2.19 2.19 0 000 3.094.813.813 0 01-.574 1.387z" />
        <path d="M4 15.813a3.789 3.789 0 01-2.696-1.117 3.818 3.818 0 010-5.392l1.371-1.371a.813.813 0 011.149 1.149l-1.371 1.371a2.19 2.19 0 003.094 3.094l3-3a2.19 2.19 0 000-3.094.813.813 0 011.149-1.149 3.818 3.818 0 010 5.392l-3 3A3.789 3.789 0 014 15.813z" />
    </svg>
)

export const TextIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
        <path d="M2.5 2a.5.5 0 00-.5.5v2a.5.5 0 001 0V3h4.5v10H6a.5.5 0 000 1h4a.5.5 0 000-1H8.5V3H13v1.5a.5.5 0 001 0v-2a.5.5 0 00-.5-.5h-11z" />
    </svg>
)

// Info icon for tooltips
export const InfoIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor" style={{ opacity: 0.6 }}>
        <path d="M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1zm0 12.5a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11zM7 5V4h2v1H7zm0 7V6h2v6H7z" />
    </svg>
)
