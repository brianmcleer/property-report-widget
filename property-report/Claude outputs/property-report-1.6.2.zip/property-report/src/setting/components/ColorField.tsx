/** @jsx jsx */
// ColorField: the setting panel's colour editor, a native colour picker paired
// with a hex text box. This module owns that pairing and its validation. The
// picker always commits (browsers only emit valid #rrggbb values). The text box
// keeps a local draft and commits only when the draft matches /^#[0-9a-f]{6}$/i,
// otherwise it shows an inline error and leaves the stored value untouched. The
// markup reuses the existing .color-input-row and .color-picker class names so
// the hoisted setting styles apply unchanged.
import { React, jsx } from 'jimu-core'
import { TextInput } from 'jimu-ui'

const { useState, useEffect } = React

export const HEX_COLOR_PATTERN = /^#[0-9a-f]{6}$/i

export interface ColorFieldProps {
    /** Optional visible label rendered before the controls. */
    label?: string
    /** Current colour as #rrggbb. Falsy values fall back to #000000 for the picker. */
    value: string
    /** Called with a validated #rrggbb string. */
    onChange: (hex: string) => void
    /** Accessible name for the picker; the hex box gets the same name plus " hex". */
    ariaLabel: string
}

export const ColorField = ({ label, value, onChange, ariaLabel }: ColorFieldProps) => {
    const safeValue = value || '#000000'
    const [draft, setDraft] = useState<string>(safeValue)
    const [error, setError] = useState<string | null>(null)

    // Keep the draft in sync when the stored value changes from outside
    // (picker, import, another control editing the same key).
    useEffect(() => {
        setDraft(safeValue)
        setError(null)
    }, [safeValue])

    const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const next = e.target.value
        setDraft(next)
        if (HEX_COLOR_PATTERN.test(next)) {
            setError(null)
            if (next.toLowerCase() !== safeValue.toLowerCase()) {
                onChange(next)
            }
        } else {
            setError('Enter a 6-digit hex colour such as #1A6B7C')
        }
    }

    const handlePickerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const next = e.target.value
        if (HEX_COLOR_PATTERN.test(next)) {
            setDraft(next)
            setError(null)
            onChange(next)
        }
    }

    return (
        <div>
            {label && (
                <div style={{ fontSize: '12px', marginBottom: '4px' }}>{label}</div>
            )}
            <div className="color-input-row">
                <input
                    type="color"
                    className="color-picker"
                    value={HEX_COLOR_PATTERN.test(safeValue) ? safeValue : '#000000'}
                    onChange={handlePickerChange}
                    aria-label={ariaLabel}
                />
                <TextInput
                    size="sm"
                    value={draft}
                    onChange={handleTextChange}
                    style={{ width: 90 }}
                    aria-label={`${ariaLabel} hex`}
                    aria-invalid={error ? true : undefined}
                />
            </div>
            {error && (
                <span role="alert" className="color-field-error">{error}</span>
            )}
        </div>
    )
}
