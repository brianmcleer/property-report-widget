/** @jsx jsx */
// NativeAlert: a small inline alert box for the setting panel that does not
// depend on the jimu-ui Alert component. This module owns the alert's colour
// table (info, warning, error) and its inline-styled markup. Behaviour is
// unchanged from the original definition in setting.tsx.
import { React, jsx } from 'jimu-core'

export interface NativeAlertProps {
    type?: 'info' | 'warning' | 'error'
    text?: string
    withIcon?: boolean
    open?: boolean
    style?: React.CSSProperties
    children?: React.ReactNode
}

// Native Alert replacement - no jimu-ui dependency
export const NativeAlert = ({ type = 'info', text, withIcon, open, style, children }: NativeAlertProps) => {
    const colors = {
        info: { bg: '#e8f4fd', border: '#bee3f8', color: '#2b6cb0', icon: 'ℹ' },
        warning: { bg: '#fffbeb', border: '#fbd38d', color: '#975a16', icon: '⚠' },
        error: { bg: '#fff5f5', border: '#feb2b2', color: '#c53030', icon: '✕' }
    }
    const c = colors[type] || colors.info
    return (
        <div style={{
            background: c.bg, border: `1px solid ${c.border}`, color: c.color,
            borderRadius: '4px', padding: '8px 10px', fontSize: '11px',
            display: 'flex', alignItems: 'flex-start', gap: '6px',
            ...style
        }}>
            {withIcon && <span style={{ flexShrink: 0 }}>{c.icon}</span>}
            <span>{text || children}</span>
        </div>
    )
}
