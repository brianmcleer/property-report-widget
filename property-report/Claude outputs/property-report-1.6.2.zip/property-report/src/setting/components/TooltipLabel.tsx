/** @jsx jsx */
// TooltipLabel: a setting-row label followed by a small info icon whose native
// title attribute carries the help text. This module owns that label markup.
// Compared with the original in setting.tsx, the info affordance is now keyboard
// reachable (tabIndex 0) and exposed to assistive tech as an image with the
// tooltip as its accessible name. Visual output is unchanged.
import { React, jsx } from 'jimu-core'
import { InfoIcon } from '../icons'

export interface TooltipLabelProps {
    label: string
    tooltip: string
}

// Tooltip label component - displays label with info icon that shows tooltip on hover
// Uses simple title attribute for maximum compatibility with jsx pragma
export const TooltipLabel = (props: TooltipLabelProps) => {
    return (
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
            {props.label}
            <span
                title={props.tooltip}
                tabIndex={0}
                role="img"
                aria-label={props.tooltip}
                style={{ display: 'inline-flex', cursor: 'help' }}
            >
                <InfoIcon />
            </span>
        </span>
    )
}
