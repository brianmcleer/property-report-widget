/** @jsx jsx */
// CollapsiblePanel: the top-level accordion card used for every group in the
// setting panel (Map Connection, Search Sources, PDF Export Settings, ...). This
// module owns the header/content markup that was repeated inline in setting.tsx.
// Class names (.collapsible-panel, -header, -header-left, -title, -toggle,
// -content, -inner) are unchanged so the hoisted styles still apply. The header
// is a role="button" element that toggles on click, Enter and Space, and is
// linked to its content region through aria-controls / id.
import { React, jsx } from 'jimu-core'
import { ChevronDownIcon } from '../icons'

export interface CollapsiblePanelProps {
    /** Stable id, also used to derive the content region id. */
    id: string
    title: string
    /** Optional icon rendered before the title inside the header. */
    icon?: React.ReactNode
    expanded: boolean
    /** Called with the panel id when the header is activated. */
    onToggle: (id: string) => void
    children?: React.ReactNode
}

export const CollapsiblePanel = ({ id, title, icon, expanded, onToggle, children }: CollapsiblePanelProps) => {
    const contentId = `${id}-content`
    const headerId = `${id}-header`

    const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
        if (e.key === 'Enter') {
            onToggle(id)
        } else if (e.key === ' ' || e.key === 'Spacebar') {
            // Space would otherwise scroll the settings pane
            e.preventDefault()
            onToggle(id)
        }
    }

    return (
        <div className="collapsible-panel">
            <div
                id={headerId}
                className="collapsible-panel-header"
                onClick={() => onToggle(id)}
                role="button"
                tabIndex={0}
                onKeyDown={handleKeyDown}
                aria-expanded={expanded}
                aria-controls={contentId}
            >
                <div className="collapsible-panel-header-left">
                    {icon}
                    <span className="collapsible-panel-title">{title}</span>
                </div>
                <span className={`collapsible-panel-toggle ${!expanded ? 'collapsed' : ''}`}>
                    <ChevronDownIcon />
                </span>
            </div>
            <div
                id={contentId}
                className={`collapsible-panel-content ${expanded ? 'expanded' : ''}`}
                role="region"
                aria-labelledby={headerId}
            >
                <div className="collapsible-panel-inner">
                    {children}
                </div>
            </div>
        </div>
    )
}
