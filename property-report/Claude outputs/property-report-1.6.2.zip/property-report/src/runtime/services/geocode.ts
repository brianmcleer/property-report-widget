/**
 * Geocoding service calls for the Property Report runtime. Owns the direct
 * ArcGIS REST requests to a GeocodeServer (findAddressCandidates,
 * reverseGeocode, suggest). The REST API is used instead of esri/rest/locator
 * to avoid a module casing conflict on Windows in JSAPI 5.x. Every call accepts
 * an optional AbortSignal, checks the HTTP status and the service level error
 * object, and normalizes the configured URL by trimming trailing slashes.
 */
import Point from 'esri/geometry/Point'

const normalizeUrl = (geocoderUrl: string): string => String(geocoderUrl || '').trim().replace(/\/+$/, '')

// Ignore AbortError silently; it is the caller cancelling a stale request.
const isAbort = (e: any): boolean => !!e && (e.name === 'AbortError' || e.code === 20)

const postForm = async (url: string, params: URLSearchParams, signal?: AbortSignal): Promise<any> => {
    const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString(),
        signal
    })
    if (!resp.ok) throw new Error(`Geocoder request failed: HTTP ${resp.status}`)
    const data = await resp.json()
    if (data && data.error) {
        const msg = data.error.message || data.error.details?.[0] || `code ${data.error.code}`
        throw new Error(`Geocoder error: ${msg}`)
    }
    return data
}

export const restGeocode = async (geocoderUrl: string, singleLine: string, signal?: AbortSignal): Promise<Point | null> => {
    try {
        const params = new URLSearchParams({
            f: 'json', SingleLine: singleLine, maxLocations: '1', outFields: 'Match_addr'
        })
        const data = await postForm(`${normalizeUrl(geocoderUrl)}/findAddressCandidates`, params, signal)
        if (data.candidates?.length > 0) {
            const loc = data.candidates[0].location
            return new Point({ x: loc.x, y: loc.y, spatialReference: data.spatialReference ?? { wkid: 4326 } })
        }
    } catch (e) {
        if (!isAbort(e)) console.warn('Geocoding failed:', e)
    }
    return null
}

export const restReverseGeocode = async (geocoderUrl: string, point: Point, signal?: AbortSignal): Promise<string | null> => {
    try {
        const params = new URLSearchParams({
            f: 'json',
            location: JSON.stringify({ x: point.x, y: point.y, spatialReference: { wkid: point.spatialReference?.wkid ?? 4326 } })
        })
        const data = await postForm(`${normalizeUrl(geocoderUrl)}/reverseGeocode`, params, signal)
        return data.address?.Match_addr || data.address?.Address || null
    } catch (e) {
        if (!isAbort(e)) console.warn('Reverse geocoding failed:', e)
    }
    return null
}

export const restSuggest = async (
    geocoderUrl: string,
    text: string,
    location?: any,
    signal?: AbortSignal
): Promise<Array<{ text: string; magicKey?: string; isCollection?: boolean }>> => {
    try {
        const params = new URLSearchParams({ f: 'json', text, maxSuggestions: '5' })
        if (location && location.x != null && location.y != null) {
            params.set('location', JSON.stringify({
                x: location.x,
                y: location.y,
                spatialReference: { wkid: location.spatialReference?.wkid ?? 4326 }
            }))
        }
        const data = await postForm(`${normalizeUrl(geocoderUrl)}/suggest`, params, signal)
        return Array.isArray(data.suggestions) ? data.suggestions : []
    } catch (e) {
        if (!isAbort(e)) console.warn('Suggest failed:', e)
    }
    return []
}
