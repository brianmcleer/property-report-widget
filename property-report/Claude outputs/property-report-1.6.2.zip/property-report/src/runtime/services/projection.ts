/**
 * Projection engine loader for the Property Report runtime. Owns the one-time
 * load of esri/geometry/projection through loadArcGISJSAPIModules (including
 * the projection.load() call JSAPI 5.x requires before project() works) and
 * hands out the loaded module to the query pipeline, coordinate display and
 * map preview. Failure resolves to null rather than throwing so callers can
 * fall back to unprojected coordinates.
 */
import { loadArcGISJSAPIModules } from 'jimu-arcgis'

let projection: any = null
let loading: Promise<any | null> | null = null

// Loads the projection module once and caches it. Repeated calls share the same
// promise; a failed load resolves null (and is not retried) so a widget that
// cannot load the engine does not spam the network on every search.
export const ensureProjection = (): Promise<any | null> => {
    if (projection) return Promise.resolve(projection)
    if (loading) return loading
    loading = loadArcGISJSAPIModules(['esri/geometry/projection'])
        .then((modules: any[]) => {
            const mod = modules?.[0] ?? null
            // Must call projection.load() before projection.project() works in JSAPI 5.x
            const loadPromise = (mod && typeof mod.load === 'function')
                ? mod.load()
                : Promise.resolve()
            return Promise.resolve(loadPromise).then(() => {
                projection = mod
                return projection
            })
        })
        .catch((e: any) => {
            console.warn('Projection engine unavailable:', e)
            return null
        })
    return loading
}

// Returns the loaded projection module, or null when ensureProjection has not
// completed (or failed).
export const getProjection = (): any | null => projection
