/**
 * Lazy PDF library loader for the Property Report runtime. Owns the on-demand
 * import of jspdf and html2canvas, which together add several hundred KB and
 * are only needed when a report is exported. The first export triggers the
 * import; later exports reuse the loaded modules. Import failures are wrapped
 * in an Error with a message suitable for showing to the user.
 */

let jsPDF: any = null
let html2canvas: any = null
let loading: Promise<{ jsPDF: any; html2canvas: any }> | null = null

export const PDF_LIBS_LOAD_ERROR = 'The PDF export libraries could not be loaded. Check your network connection and try again.'

export const loadPdfLibs = (): Promise<{ jsPDF: any; html2canvas: any }> => {
    if (jsPDF && html2canvas) return Promise.resolve({ jsPDF, html2canvas })
    if (loading) return loading
    loading = Promise.all([import('jspdf'), import('html2canvas')])
        .then(([j, h]) => {
            jsPDF = (j as any).default || j
            html2canvas = (h as any).default || h
            return { jsPDF, html2canvas }
        })
        .catch((e) => {
            loading = null
            console.error('Failed to load PDF libraries:', e)
            const err = new Error(PDF_LIBS_LOAD_ERROR)
            ;(err as any).cause = e
            throw err
        })
    return loading
}

// Returns the already-loaded libraries, or nulls if loadPdfLibs has not finished.
export const getPdfLibs = (): { jsPDF: any; html2canvas: any } => ({ jsPDF, html2canvas })
