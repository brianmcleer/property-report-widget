/**
 * Layer and data source caching for the Property Report runtime. Owns the
 * per-URL FeatureLayer cache (so service metadata loads once per layer for the
 * lifetime of the app), the per-layer coded value domain lookup cache, and the
 * on-demand DataSource resolution that works around the framework not having
 * created a configured DataSource before the first search. In-flight work is
 * cached as promises so concurrent callers share one request, and failed
 * entries are evicted so the next call retries instead of replaying the error.
 */
import { DataSourceManager } from 'jimu-core'
import FeatureLayer from 'esri/layers/FeatureLayer'
import type { DomainLookup } from '../types'

// RELIABILITY: on the very first search of a session the framework may not have
// created a configured DataSource yet; getDataSource() then returns nothing and the
// layer silently drops out of the report (community report: first search empty,
// second and later searches fine). Create the data source on demand and await its
// readiness so the first search behaves like every later one.
const dataSourcePromiseById = new Map<string, Promise<any | null>>()

export const resolveDataSource = (dataSourceId: string): Promise<any | null> => {
    if (!dataSourceId) return Promise.resolve(null)
    const inFlight = dataSourcePromiseById.get(dataSourceId)
    if (inFlight) return inFlight

    const p = (async (): Promise<any | null> => {
        try {
            const dsm: any = DataSourceManager.getInstance()
            let ds: any = dsm.getDataSource(dataSourceId)
            if (!ds && typeof dsm.createDataSourceById === 'function') {
                try { ds = await dsm.createDataSourceById(dataSourceId) } catch (e) { ds = null }
            }
            if (ds) { try { await ds.ready?.() } catch (e) { /* url may still resolve */ } }
            return ds || null
        } catch (e) { return null }
    })()

    dataSourcePromiseById.set(dataSourceId, p)
    // A null result means the framework could not produce the data source right
    // now; evict so a later search retries rather than staying empty forever.
    p.then(ds => { if (!ds) dataSourcePromiseById.delete(dataSourceId) }, () => dataSourcePromiseById.delete(dataSourceId))
    return p
}

// PERF: constructing a new FeatureLayer per query forces the JS API to refetch the
// service metadata on every search. Cache instances by URL so metadata loads once
// per layer for the lifetime of the app; queryFeatures on a shared instance is safe
// because these layers are never mutated after creation.
const layerCacheByUrl = new Map<string, FeatureLayer>()

export const getCachedLayer = (url: string): FeatureLayer => {
    let cached = layerCacheByUrl.get(url)
    // If a cached layer failed to load earlier (bad URL, auth, service down) drop
    // it so this search constructs a fresh instance instead of reusing a broken one.
    if (cached && (cached as any).loadStatus === 'failed') {
        layerCacheByUrl.delete(url)
        cached = undefined
    }
    if (!cached) {
        cached = new FeatureLayer({ url })
        layerCacheByUrl.set(url, cached)
    }
    return cached
}

// Removes a layer (and its domain lookup) from the caches, for example after a
// query error that suggests the cached metadata is stale.
export const evictCachedLayer = (url: string): void => {
    layerCacheByUrl.delete(url)
    for (const key of Array.from(domainLookupPromiseByKey.keys())) {
        if (key.startsWith(`${url}/`)) domainLookupPromiseByKey.delete(key)
    }
}

// PERF: domain lookups walk every field's coded values; cache per layer URL.
// The promise is cached so concurrent queries against the same layer share one
// load; a failed load is evicted so it can be retried.
const domainLookupPromiseByKey = new Map<string, Promise<DomainLookup>>()

const domainCacheKey = (layer: FeatureLayer): string => `${(layer as any).url || ''}/${(layer as any).layerId ?? ''}`

/**
 * Extracts domain lookup from a FeatureLayer's fields.
 * Returns a mapping of field name -> code -> description
 */
export const extractDomainLookup = (layer: FeatureLayer): Promise<DomainLookup> => {
    const cacheKey = domainCacheKey(layer)
    const hit = domainLookupPromiseByKey.get(cacheKey)
    if (hit) return hit

    const p = (async (): Promise<DomainLookup> => {
        const domainLookup: DomainLookup = {}
        // Ensure layer is loaded to access field metadata. A load failure
        // propagates so the cache entry is evicted below.
        await layer.load()

        if (layer.fields) {
            for (const field of layer.fields) {
                // Check if field has a coded value domain
                if (field.domain && field.domain.type === 'coded-value') {
                    const codedValueDomain = field.domain as any
                    if (codedValueDomain.codedValues) {
                        domainLookup[field.name] = {}
                        for (const cv of codedValueDomain.codedValues) {
                            // Map both the code value and its string representation
                            domainLookup[field.name][cv.code] = cv.name
                            // Also map string version of code for flexibility
                            if (typeof cv.code === 'number') {
                                domainLookup[field.name][String(cv.code)] = cv.name
                            }
                        }
                    }
                }
            }
        }
        return domainLookup
    })()

    domainLookupPromiseByKey.set(cacheKey, p)

    // Callers always get a lookup object (possibly empty), matching the original
    // behavior of warning and continuing when metadata cannot be read.
    const safe = p.catch((e): DomainLookup => {
        console.warn('Failed to extract domain lookup:', e)
        if (domainLookupPromiseByKey.get(cacheKey) === safe) domainLookupPromiseByKey.delete(cacheKey)
        return {}
    })
    domainLookupPromiseByKey.set(cacheKey, safe)
    return safe
}
