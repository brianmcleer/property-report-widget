/**
 * Shared runtime types for the Property Report widget. Owns the result and
 * suggestion shapes passed between the query pipeline, the display components,
 * and the PDF generator (domain lookups, layer and section results, nearby
 * features, PDF bookmarks and table of contents entries, search suggestions).
 * Config shapes stay in ../config; only cross-module runtime types live here.
 */
import type Point from 'esri/geometry/Point'
import type { SectionConfig, LayerConfig, RelatedTableConfig, NearbyDisplayConfig } from '../config'

// Domain lookup for coded value domains - maps field name to code -> description
export type DomainLookup = Record<string, Record<string | number, string>>

export interface RelatedTableResult {
    tableConfig: RelatedTableConfig
    records: any[]
    error?: string
    domainLookup?: DomainLookup  // Domain descriptions for coded value fields
}

// =====================================================
// PDF Generation Interfaces
// =====================================================

// Hierarchical bookmark structure for PDF navigation (WCAG 2.4.5)
export interface PdfBookmark {
    title: string
    page: number
    y: number
    level: number  // 0 = section, 1 = layer, 2 = related table
    parentId?: string  // Parent bookmark ID for hierarchy
    id: string
}

// Table of Contents entry
export interface TocEntry {
    title: string
    page: number
    level: number  // Indentation level
    type: 'section' | 'layer' | 'relatedTable' | 'chart'
}

// Related table chart capture data
export interface RelatedTableChartCapture {
    tableId: string
    tableName: string
    imageData: string
    width: number
    height: number
}

export interface LayerResult {
    layerConfig: LayerConfig
    features: any[]
    relatedData?: RelatedTableResult[]
    domainLookup?: DomainLookup  // Domain descriptions for coded value fields
}

// Nearby feature for section-level nearby layers
export interface NearbyFeature {
    title: string
    subtitle?: string
    distance: number
    distanceFormatted: string
    linkUrl?: string
    geometry?: any
    attributes: Record<string, any>
}

// Nearby result for a layer in nearby display mode
export interface NearbyResult {
    layerConfig: LayerConfig          // The layer this nearby result is for
    nearbyConfig: NearbyDisplayConfig // The nearby display settings
    features: NearbyFeature[]
    error?: string
}

export interface SectionResult {
    sectionConfig: SectionConfig
    layerResults: LayerResult[]
    totalFeatures: number
    chartData?: any[]
    nearbyResults?: NearbyResult[]  // Nearby features for layers with nearby mode enabled
}

export interface SearchSuggestion {
    text: string
    subtext?: string
    point?: Point
    geometry?: any
    sourceName: string
    sourceType: 'geocoder' | 'layer' | 'url'
    sourceId?: string
    highlightEnabled?: boolean
    highlightColor?: string
}

export interface GroupedSuggestions { sourceName: string; sourceType: 'geocoder' | 'layer' | 'url'; suggestions: SearchSuggestion[] }
