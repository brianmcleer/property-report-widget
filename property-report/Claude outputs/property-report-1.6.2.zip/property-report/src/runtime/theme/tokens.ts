/**
 * Design tokens for the Property Report runtime. Owns the WCAG AA color
 * palette used by the widget stylesheet and components, the accessible chart
 * color list, and the default PDF accessibility settings (metadata, alt text
 * templates, table summary templates). These are plain constants with no
 * React or ArcGIS dependencies so any module can import them.
 */

// =====================================================
// WCAG 2.1 PDF ACCESSIBILITY CONFIGURATION
// These defaults ensure PDF exports meet accessibility standards
// =====================================================
export const PDF_ACCESSIBILITY_DEFAULTS = {
    // Document metadata (WCAG 2.4.2 Page Titled)
    documentLanguage: 'en-US',
    documentAuthor: 'GIS Division',
    documentCreator: 'Property Report Widget',

    // Alt text settings (WCAG 1.1.1 Non-text Content)
    includeMapAltText: true,
    includeLogoAltText: true,
    mapAltTextTemplate: 'Map showing the location of {address}',
    logoAltTextTemplate: 'Organization logo',
    chartAltTextTemplate: 'Chart showing {chartType} visualization of {dataDescription}',

    // Table accessibility (WCAG 1.3.1 Info and Relationships)
    includeTableSummaries: true,
    tableSummaryTemplate: 'Data table: {layerTitle} - {recordCount} records, {columnCount} columns',

    // Related table accessibility (WCAG 1.3.1)
    includeRelatedTableSummaries: true,
    relatedTableSummaryTemplate: 'Related data: {tableName} - {recordCount} records, {columnCount} columns',

    // Font accessibility (WCAG 1.4.4 Resize Text)
    minimumFontSize: 9,

    // Link accessibility (WCAG 2.4.4 Link Purpose)
    showFullUrls: false, // Option to append URLs for print accessibility

    // Reading order (WCAG 1.3.2 Meaningful Sequence)
    includeReadingOrderMarkers: true,

    // Table of Contents (WCAG 2.4.5 Multiple Ways)
    tocTitle: 'Table of Contents'
}

// =====================================================
// ACCESSIBILITY: Updated Design System with WCAG AA Compliant Colors
// Minimum 4.5:1 contrast ratio for normal text
// Minimum 3:1 contrast ratio for large text and UI components
// =====================================================
export const theme = {
    // Links and accents - meets 4.5:1 on white
    link: '#0056B3',
    linkHover: '#003D80',

    // Neutrals
    white: '#FFFFFF',
    bg: '#FFFFFF',
    bgAlt: '#F5F5F5',
    border: '#CCCCCC',
    borderLight: '#E0E0E0',

    // Text - all meet 4.5:1 contrast on white background
    textPrimary: '#1A1A1A',
    textSecondary: '#4A4A4A',
    textMuted: '#595959', // Updated from #888888 to meet 4.5:1 contrast

    // Section header - meets 3:1 for large text
    sectionHeader: '#1A6B7C',
    sectionHeaderBg: '#E8F4F8',

    // Status - meets 4.5:1 on respective backgrounds
    error: '#B81C1C',
    errorBg: '#FFF5F5',

    // Focus state - high visibility
    focus: '#0056B3',
    focusOutline: '#0056B3',

    // Chart colors - accessible palette
    chart: ['#1A6B7C', '#2E7D32', '#C2410C', '#6B21A8', '#0369A1', '#B91C1C', '#15803D', '#7C3AED']
}

export const CHART_COLORS = theme.chart
