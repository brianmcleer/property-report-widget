/**
 * Widget stylesheet for the Property Report runtime. Owns the single Emotion
 * css template that styles every runtime component (search header, sections,
 * tables, charts, nearby lists, property preview, separate panes, print and
 * mobile rules). Class names are the contract with the components; do not
 * rename them here without updating the JSX. Colors come from theme tokens
 * plus the per-app primary colors passed in by the widget.
 */
import { css } from 'jimu-core'
import { theme } from './tokens'

// ACCESSIBILITY: Enhanced Styles with Focus Management
// Font sizes use rem units for WCAG 1.4.4 (Resize Text)
// Base: 16px = 1rem, so 13px = 0.8125rem, 14px = 0.875rem, etc.
export const getStyles = (themeColors: { primary: string; primaryDark: string; primaryLight: string }) => css`
    display: flex;
    flex-direction: column;
    height: 100%;
    width: 100%;
    background: ${theme.white};
    font-size: 0.8125rem; /* 13px base font */
    line-height: 1.5;
    color: ${theme.textPrimary};
    overflow: hidden;
    /* Ensure widget fills its parent container */
    flex: 1 1 auto;
    min-height: 0;
    /* Required for absolute-positioned separate-pane to fill widget correctly */
    position: relative;

    /* CSS Custom Properties for dynamic theming */
    --theme-primary: ${themeColors.primary};
    --theme-primary-dark: ${themeColors.primaryDark};
    --theme-primary-light: ${themeColors.primaryLight};

    * { box-sizing: border-box; }

    /* ===== ACCESSIBILITY: Skip Link ===== */
    .skip-link {
        position: absolute;
        top: -40px;
        left: 0;
        padding: 8px 16px;
        background: var(--theme-primary);
        color: white;
        text-decoration: none;
        font-weight: bold;
        z-index: 10000;
        transition: top 0.2s ease;
    }

    .skip-link:focus {
        top: 0;
        outline: 3px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    /* ===== ACCESSIBILITY: Global Focus Styles ===== */
    *:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    *:focus:not(:focus-visible) {
        outline: none;
    }

    *:focus-visible {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    /* ===== Screen Reader Only Content ===== */
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
    }

    /* ===== Search Header ===== */
    .search-header {
        background: ${theme.white};
        padding: 10px 15px;
        border-bottom: 1px solid ${theme.border};
    }

    .search-row {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
    }

    .search-input-container {
        flex: 1 1 100%;
        position: relative;
    }

    .search-input {
        width: 100%;
        height: 34px;
        padding: 0 32px 0 12px;
        border: 1px solid ${theme.border};
        font-size: 0.875rem;
        color: ${theme.textPrimary};
        background: ${theme.white};
    }

    .search-input:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: -1px;
        border-color: ${theme.focus};
    }

    .search-input[aria-invalid="true"] {
        border-color: ${theme.error};
        background: ${theme.errorBg};
    }

    .search-input[aria-invalid="true"]:focus {
        outline-color: ${theme.error};
        border-color: ${theme.error};
    }

    .search-input::placeholder {
        color: ${theme.textMuted};
    }

    .search-clear-btn {
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
        width: 24px;
        height: 24px;
        border: none;
        background: transparent;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        color: ${theme.textSecondary};
        border-radius: 50%;
        transition: all 0.15s ease;
    }

    .search-clear-btn:hover {
        background: ${theme.bgAlt};
        color: ${theme.textPrimary};
    }

    .search-clear-btn:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 1px;
    }

    .search-clear-btn svg {
        width: 14px;
        height: 14px;
    }

    .search-btn {
        height: 34px;
        flex: 1 1 auto;
        padding: 0 20px;
        background: var(--theme-primary);
        color: white;
        border: none;
        font-size: 0.875rem;
        font-weight: 500;
        cursor: pointer;
        transition: background 0.2s ease;
    }

    .search-btn:hover:not(:disabled) { 
        background: var(--theme-primary-dark);
    }

    .search-btn:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }
    
    .search-btn:disabled { 
        opacity: 0.6; 
        cursor: not-allowed; 
    }

    .select-location-btn {
        height: 34px;
        width: 34px;
        padding: 0;
        background: ${theme.white};
        border: 1px solid ${theme.border};
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: ${theme.textSecondary};
        transition: all 0.15s ease;
    }

    .select-location-btn:hover:not(.active) {
        background: ${theme.bgAlt};
        color: ${theme.textPrimary};
        border-color: ${theme.textMuted};
    }

    .select-location-btn:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    .select-location-btn.active {
        background: var(--theme-primary);
        border-color: var(--theme-primary);
        color: white;
    }

    .select-location-btn.active:hover {
        background: #145663;
    }

    .select-location-btn svg {
        width: 18px;
        height: 18px;
    }

    /* Current location button specific styles */
    .current-location-btn.active {
        background: #4285F4;
        border-color: #4285F4;
        color: white;
    }

    .current-location-btn.active:hover {
        background: #3367D6;
    }

    .current-location-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }

    /* ===== ACCESSIBILITY: Enhanced Suggestions Dropdown ===== */
    .suggestions-dropdown {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: ${theme.white};
        border: 1px solid ${theme.border};
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        max-height: 300px;
        overflow-y: auto;
    }

    .suggestion-group {
        padding: 6px 12px;
        background: ${theme.bgAlt};
        font-size: 0.6875rem;
        font-weight: bold;
        color: ${theme.textMuted};
        text-transform: uppercase;
        border-bottom: 1px solid ${theme.border};
    }

    .suggestion-item {
        padding: 10px 12px;
        cursor: pointer;
        border-bottom: 1px solid ${theme.borderLight};
    }

    .suggestion-item:hover,
    .suggestion-item.highlighted {
        background: ${theme.sectionHeaderBg};
    }

    .suggestion-item:focus {
        outline: none;
        background: ${theme.sectionHeaderBg};
        box-shadow: inset 0 0 0 2px ${theme.focusOutline};
    }

    .suggestion-item[aria-selected="true"] {
        background: ${theme.sectionHeaderBg};
    }

    .suggestion-item:last-child { border-bottom: none; }

    .suggestion-text {
        font-size: 0.875rem;
        color: ${theme.textPrimary};
    }

    .suggestion-subtext {
        font-size: 0.75rem;
        color: ${theme.textMuted};
        margin-top: 2px;
    }

    /* ===== Results Container ===== */
    .results-container {
        flex: 1 1 0%;
        overflow-y: auto;
        background: ${theme.white};
        position: relative;
        min-height: 100px;
        padding-bottom: 20px;
    }

    /* Ensure last section doesn't get cut off */
    .results-container > *:last-child {
        margin-bottom: 0;
    }

    /* ===== Address Header ===== */
    .address-header {
        padding: 12px 16px;
        border-bottom: 1px solid ${theme.border};
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: flex-start;
        position: sticky;
        top: 0;
        background: ${theme.white};
        z-index: 10;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0);
        transition: box-shadow 0.2s ease;
        gap: 10px;
    }

    /* Add subtle shadow when content is scrolled underneath */
    .results-container.scrolled .address-header {
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .address-info {
        flex: 1 1 240px;
        min-width: 200px; /* Force the action buttons to wrap to their own row when narrow */
        overflow: hidden;
    }

    .address-title {
        font-size: 1.25rem;
        font-weight: bold;
        color: ${theme.textPrimary};
        margin: 0 0 2px 0;
        word-break: break-word;
        overflow-wrap: break-word;
        line-height: 1.3;
    }

    .address-subtitle {
        font-size: 0.8125rem;
        color: ${theme.textSecondary};
        margin: 4px 0 0 0;
        word-break: break-word;
        overflow-wrap: break-word;
    }

    .header-info-fields {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin-top: 4px;
        max-width: 100%;
    }

    .header-info-item {
        display: inline-flex;
        align-items: baseline;
        flex-wrap: wrap;
        gap: 4px;
        font-size: 0.875rem;
        max-width: 100%;
        min-width: 0;
    }

    .header-info-label {
        color: ${theme.textSecondary};
        flex-shrink: 0;
    }

    .header-info-value {
        color: ${theme.textPrimary};
        font-weight: 500;
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: break-word;
    }

    .address-actions {
        display: flex;
        gap: 6px;
        flex: 1 1 auto;
        justify-content: flex-end;
    }

    .action-icon {
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: ${theme.textSecondary};
        cursor: pointer;
        border: 1px solid ${theme.border};
        background: ${theme.white};
        border-radius: 4px;
    }

    .action-icon:hover:not(:disabled) { 
        color: ${theme.textPrimary}; 
        background: ${theme.bgAlt};
    }

    .action-icon:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    .action-icon:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }

    /* ===== ACCESSIBILITY: Collapsible Section Headers ===== */
    .pm-section {
        border-bottom: 1px solid ${theme.border};
    }

    .pm-section:last-of-type {
        border-bottom: none;
        margin-bottom: 0;
    }

    .pm-section-header {
        padding: 12px 20px;
        background: ${theme.sectionHeaderBg};
        border-bottom: 1px solid ${theme.border};
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .pm-section-header:hover {
        background: #DCF0F5;
    }

    /* Keyboard focus lands on the title button inside the header. */
    .pm-section-title-btn:focus-visible,
    .layer-header .layer-title.pr-inline-btn:focus-visible {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }


    .pm-section-title {
        font-size: 0.875rem;
        font-weight: bold;
        color: var(--theme-primary);
        margin: 0;
        text-transform: uppercase;
    }


    .pm-section-toggle {
        color: ${theme.textSecondary};
        font-size: 0.625rem;
        transition: transform 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        height: 20px;
    }

    .pm-section-toggle.open { transform: rotate(180deg); }

    .pm-section-body {
        display: none;
        padding: 0;
    }

    .pm-section-body.open { display: block; }

    /* ===== Rich Text Section ===== */
    .rich-text-content {
        padding: 16px 20px;
        font-size: 0.8125rem;
        line-height: 1.7;
        color: ${theme.textPrimary};
    }

    .rich-text-content p {
        margin: 0 0 12px 0;
    }

    .rich-text-content p:last-child {
        margin-bottom: 0;
    }

    .rich-text-content a {
        color: ${theme.link};
        text-decoration: underline;
    }

    .rich-text-content a:hover {
        color: ${theme.linkHover};
    }

    .rich-text-content a:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    .rich-text-content strong, .rich-text-content b {
        font-weight: bold;
    }

    .rich-text-content em, .rich-text-content i {
        font-style: italic;
    }

    .rich-text-content ul, .rich-text-content ol {
        margin: 0 0 12px 0;
        padding-left: 24px;
    }

    .rich-text-content li {
        margin-bottom: 4px;
    }

    .rich-text-buttons {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        padding: 0 20px 16px 20px;
    }

    .rich-text-btn {
        display: inline-block;
        padding: 10px 20px;
        font-size: 0.8125rem;
        font-weight: 500;
        text-decoration: none;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.15s ease;
        border: 1px solid ${theme.border};
    }

    .rich-text-btn:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    .rich-text-btn-default {
        background: ${theme.white};
        color: ${theme.textPrimary};
        border-color: ${theme.border};
    }

    .rich-text-btn-default:hover {
        background: ${theme.bgAlt};
        border-color: ${theme.textMuted};
    }

    .rich-text-btn-primary {
        background: var(--theme-primary);
        color: ${theme.white};
        border-color: var(--theme-primary);
    }

    .rich-text-btn-primary:hover {
        background: var(--theme-primary-dark);
        border-color: var(--theme-primary-dark);
    }

    .rich-text-btn-outline {
        background: transparent;
        color: var(--theme-primary);
        border-color: var(--theme-primary);
    }

    .rich-text-btn-outline:hover {
        background: ${theme.sectionHeaderBg};
    }

    /* ===== Data Row (Key-Value) ===== */
    .data-row {
        display: flex;
        padding: 8px 20px;
        border-bottom: 1px solid ${theme.borderLight};
        min-height: 36px;
        align-items: center;
    }

    .data-row:last-child { border-bottom: none; }

    .data-label {
        width: 140px;
        flex-shrink: 0;
        font-weight: bold;
        color: ${theme.textSecondary};
        font-size: 0.8125rem;
        line-height: 1.4;
        margin: 0;
        padding: 0;
    }

    .data-value {
        flex: 1;
        color: ${theme.textPrimary};
        font-size: 0.8125rem;
        line-height: 1.4;
        margin: 0;
        padding: 0;
    }

    /* Reset dl/dt/dd browser defaults */
    dl {
        margin: 0;
        padding: 0;
    }

    dt, dd {
        margin: 0;
        padding: 0;
    }

    .data-value a {
        color: ${theme.link};
        text-decoration: underline;
        cursor: pointer;
    }

    .data-value a:hover {
        color: ${theme.linkHover};
    }

    .data-value a:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    /* ===== Layer Subsection ===== */
    .layer-subsection {
        border-top: 1px solid ${theme.border};
    }

    .layer-subsection:first-child { border-top: none; }

    .layer-header {
        padding: 10px 20px;
        background: ${theme.bgAlt};
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid ${theme.borderLight};
    }

    .layer-header:hover { background: #EBEBEB; }

    .layer-header:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: -2px;
    }

    .layer-header-left {
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    .layer-header-right {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .layer-toggle {
        color: ${theme.textMuted};
        font-size: 0.625rem;
        transition: transform 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 16px;
        height: 16px;
    }

    .layer-toggle.open { transform: rotate(180deg); }

    .layer-title {
        font-size: 0.8125rem;
        font-weight: bold;
        color: ${theme.textPrimary};
        line-height: 1.4;
    }

    .layer-count {
        font-size: 0.8125rem;
        color: ${theme.textMuted};
        line-height: 1.4;
    }

    .layer-body {
        display: none;
    }

    .layer-body.open { display: block; }

    /* ===== ACCESSIBILITY: Enhanced Table (TanStack) ===== */
    .table-filter-row {
        display: flex;
        gap: 8px;
        padding: 8px 12px;
        background: ${theme.bgAlt};
        border-bottom: 1px solid ${theme.border};
    }

    .table-filter-input {
        flex: 1;
        padding: 6px 10px;
        border: 1px solid ${theme.border};
        border-radius: 3px;
        font-size: 0.75rem;
        min-width: 0;
    }

    .table-filter-input:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: -1px;
        border-color: ${theme.focus};
    }

    .table-wrapper {
        overflow-x: auto;
    }

    .table-wrapper.sticky-header {
        max-height: 400px;
        overflow-y: auto;
    }

    /* Override max-height when table is inside separate pane */
    .separate-pane-content .table-wrapper.sticky-header {
        max-height: none;
        overflow: visible;
    }

    /* Disable sticky header inside separate pane since parent scrolls */
    .separate-pane-content .table-wrapper.sticky-header thead {
        position: static;
    }

    /* Override all collapsible body max-heights inside separate pane */
    .separate-pane-content .nearby-body.open,
    .separate-pane-content .nearby-separate-body.open {
        max-height: none;
    }

    .table-wrapper.sticky-header thead {
        position: sticky;
        top: 0;
        z-index: 1;
    }

    .enhanced-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.75rem;
    }

    .enhanced-table caption {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
    }

    .enhanced-table th {
        text-align: left;
        padding: 10px 12px;
        background: ${theme.bgAlt};
        font-weight: 600;
        color: ${theme.textSecondary};
        border-bottom: 2px solid ${theme.border};
        font-size: 0.6875rem;
        white-space: nowrap;
    }

    .enhanced-table th.sortable {
        cursor: pointer;
        user-select: none;
    }

    .enhanced-table th.sortable:hover {
        background: ${theme.border};
    }

    .enhanced-table th.sortable:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: -2px;
    }

    .enhanced-table .th-content {
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .enhanced-table .sort-indicator {
        font-size: 0.625rem;
        color: ${theme.link};
    }

    .enhanced-table td {
        padding: 8px 12px;
        border-bottom: 1px solid ${theme.borderLight};
        color: ${theme.textPrimary};
    }

    .enhanced-table.striped tbody tr:nth-child(even) td {
        background: ${theme.bgAlt};
    }

    .enhanced-table tbody tr.hover-highlight:hover td {
        background: #E8F4F8 !important;
    }

    /* Interactive rows - highlight/zoom enabled */
    .enhanced-table tbody tr.interactive-row {
        transition: background-color 0.15s ease;
        cursor: pointer;
    }

    .enhanced-table tbody tr.interactive-row:hover td {
        background: #FFF3E0 !important;
    }

    .enhanced-table tbody tr.interactive-row:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: -2px;
    }

    .enhanced-table tbody tr.interactive-row:focus td {
        background: #FFF3E0 !important;
    }

    .enhanced-table tbody tr.interactive-row.hover-highlight:hover td {
        background: #FFF3E0 !important;
    }

    /* Row zoom button in layer header */
    .row-zoom-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 24px;
        height: 24px;
        margin-left: auto;
        padding: 0;
        background: ${theme.white};
        border: 1px solid ${theme.border};
        border-radius: 4px;
        color: var(--theme-primary);
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .row-zoom-btn:hover {
        background: var(--theme-primary);
        color: ${theme.white};
        border-color: var(--theme-primary);
    }

    .row-zoom-btn:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    .enhanced-table.compact th,
    .enhanced-table.compact td {
        padding: 4px 8px;
    }

    .enhanced-table td a {
        color: ${theme.link};
        text-decoration: underline;
    }

    .enhanced-table td a:hover {
        color: ${theme.linkHover};
    }

    .enhanced-table td a:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    /* ===== Column Resize Handles ===== */
    .enhanced-table th.resizable {
        position: relative;
    }

    .enhanced-table .resize-handle {
        position: absolute;
        top: 0;
        right: 0;
        width: 8px;
        height: 100%;
        cursor: col-resize;
        background: transparent;
        z-index: 1;
        transition: background-color 0.15s ease;
        touch-action: none;
        user-select: none;
    }

    .enhanced-table .resize-handle:hover,
    .enhanced-table .resize-handle:focus,
    .enhanced-table .resize-handle.resizing {
        background: ${theme.link};
        outline: none;
    }

    .enhanced-table .resize-handle:focus-visible {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 0;
    }

    .enhanced-table .resize-handle::after {
        content: '';
        position: absolute;
        top: 25%;
        right: 3px;
        width: 2px;
        height: 50%;
        background: ${theme.border};
        border-radius: 1px;
    }

    .enhanced-table .resize-handle:hover::after,
    .enhanced-table .resize-handle:focus::after,
    .enhanced-table .resize-handle.resizing::after {
        background: ${theme.white};
    }

    /* ===== ACCESSIBILITY: Pagination Controls ===== */
    .table-pagination {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 12px;
        background: ${theme.bgAlt};
        border-top: 1px solid ${theme.border};
        font-size: 0.75rem;
    }

    .pagination-info {
        color: ${theme.textSecondary};
    }

    .pagination-controls {
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .pagination-btn {
        padding: 6px 10px;
        border: 1px solid ${theme.border};
        background: ${theme.white};
        cursor: pointer;
        font-size: 0.75rem;
        border-radius: 3px;
        color: ${theme.textSecondary};
        min-width: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .pagination-btn:hover:not(:disabled) {
        background: ${theme.bgAlt};
        border-color: ${theme.textMuted};
    }

    .pagination-btn:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    .pagination-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
    }

    .pagination-page {
        padding: 0 8px;
        color: ${theme.textSecondary};
    }

    /* ===== Charts ===== */
    .charts-container {
        padding: 15px 20px;
        background: ${theme.bgAlt};
        border-bottom: 1px solid ${theme.border};
    }

    .charts-row {
        display: flex;
        gap: 20px;
    }

    .chart-box {
        flex: 1;
        background: ${theme.white};
        border: 1px solid ${theme.border};
        padding: 12px;
    }

    .chart-title {
        font-size: 0.6875rem;
        font-weight: bold;
        color: ${theme.textMuted};
        margin-bottom: 10px;
        text-transform: uppercase;
    }

    .chart-container { 
        height: 150px;
        font-family: inherit;
    }

    .chart-description {
        background: ${theme.white};
        border: 1px solid ${theme.border};
        border-radius: 4px;
        padding: 12px 15px;
        margin: 8px 0;
        font-size: 0.8125rem;
        line-height: 1.5;
        color: ${theme.textPrimary};
    }

    .chart-description a {
        color: var(--theme-primary);
        text-decoration: underline;
    }

    .chart-description a:hover {
        text-decoration: none;
    }

    /* ===== Property Preview ===== */
    .property-preview {
        background: ${theme.white};
        border: 1px solid ${theme.border};
        border-radius: 6px;
        margin: 0 15px 15px;
        overflow: hidden;
    }

    .property-preview-map {
        width: 100%;
        background: ${theme.bgAlt};
        position: relative;
    }

    .property-preview-content {
        padding: 12px;
    }

    .property-preview-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 10px;
        gap: 10px;
        flex-wrap: wrap;
    }

    .property-preview-title {
        font-size: 1rem;
        font-weight: 600;
        color: ${theme.textPrimary};
        line-height: 1.3;
        word-break: break-word;
        overflow-wrap: break-word;
        min-width: 0;
        flex: 1;
    }

    .property-preview-subtitle {
        font-size: 0.75rem;
        color: ${theme.textMuted};
        margin-top: 2px;
    }

    .property-preview-actions {
        display: flex;
        gap: 6px;
    }

    .property-preview-btn {
        padding: 6px 10px;
        font-size: 0.6875rem;
        border: 1px solid ${theme.border};
        background: ${theme.white};
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        color: ${theme.textSecondary};
        transition: all 0.15s ease;
    }

    .property-preview-btn:hover {
        background: ${theme.bgAlt};
        border-color: var(--theme-primary);
        color: var(--theme-primary);
    }

    .property-preview-attributes {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
    }

    .property-preview-attributes.horizontal {
        flex-direction: row;
    }

    .property-preview-attributes.vertical {
        flex-direction: column;
    }

    .property-preview-attributes.grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    }

    .property-attr-item {
        flex: 0 0 auto;
    }

    .property-attr-label {
        font-size: 0.625rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: ${theme.textMuted};
        margin-bottom: 2px;
    }

    .property-attr-value {
        font-size: 0.8125rem;
        font-weight: 500;
        color: ${theme.textPrimary};
    }

    /* ===== Related Tables ===== */
    .related-table-section {
        margin-top: 12px;
        padding: 12px 0 0 0;
        border-top: 1px dashed ${theme.borderLight};
    }

    .related-table-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
        padding: 8px 4px;
        cursor: pointer;
        border-radius: 4px;
        transition: background-color 0.15s;
    }

    .related-table-header:hover {
        background: ${theme.bgAlt};
    }

    .related-table-header:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: -2px;
    }

    .related-table-header-left {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .related-table-toggle {
        color: ${theme.textMuted};
        font-size: 0.5rem;
        transition: transform 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 14px;
        height: 14px;
    }

    .related-table-toggle.open { transform: rotate(180deg); }

    .related-table-body {
        display: none;
    }

    .related-table-body.open { display: block; }

    .related-table-title {
        font-size: 0.75rem;
        font-weight: 600;
        color: ${theme.textSecondary};
    }

    .related-table-count {
        font-size: 0.6875rem;
        color: ${theme.textMuted};
        padding: 2px 6px;
        background: ${theme.bgAlt};
        border-radius: 10px;
    }

    .related-card {
        background: ${theme.bgAlt};
        border: 1px solid ${theme.borderLight};
        border-radius: 4px;
        padding: 10px;
        margin-bottom: 8px;
    }

    .related-card:last-child {
        margin-bottom: 0;
    }

    .layer-cards .related-card {
        transition: box-shadow 0.15s ease, border-color 0.15s ease;
    }

    .layer-cards .related-card:hover {
        border-color: var(--theme-primary);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .layer-cards .related-card:focus {
        outline: 2px solid var(--theme-primary);
        outline-offset: 2px;
    }

    /* ===== Nearby Features Styles ===== */
    .nearby-section {
        margin-top: 8px;
        border-top: 1px solid ${theme.border};
    }

    .nearby-header {
        padding: 10px 20px;
        background: ${theme.bgAlt};
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid ${theme.borderLight};
        transition: background-color 0.15s ease;
    }

    .nearby-header:hover {
        background: #EBEBEB;
    }

    .nearby-header:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: -2px;
    }

    .nearby-header-left {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .nearby-title {
        font-size: 0.8125rem;
        font-weight: 600;
        color: ${theme.textPrimary};
    }

    .nearby-header-right {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .nearby-subtitle {
        font-size: 0.75rem;
        color: ${theme.textMuted};
        font-style: italic;
        padding-right: 4px;
    }

    .nearby-toggle {
        color: ${theme.textMuted};
        font-size: 0.625rem;
        transition: transform 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 16px;
        height: 16px;
    }

    .nearby-toggle.open {
        transform: rotate(180deg);
    }

    .nearby-body {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease-out;
    }

    .nearby-body.open {
        max-height: none;
        transition: max-height 0.3s ease-in;
    }

    .nearby-list {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .nearby-item {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        padding: 10px 20px;
        border-bottom: 1px solid ${theme.borderLight};
        gap: 12px;
        transition: background-color 0.15s ease;
    }

    .nearby-item.zoomable {
        cursor: pointer;
    }

    .nearby-item:hover {
        background: ${theme.bgAlt};
    }

    .nearby-item:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: -2px;
        background: ${theme.bgAlt};
    }

    .nearby-item:last-child {
        border-bottom: none;
    }

    .nearby-item-content {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 2px;
        padding-left: 8px;
        border-left: 3px solid ${theme.border};
    }

    .nearby-item-name {
        font-size: 0.8125rem;
        font-weight: 500;
        color: ${theme.textPrimary};
        text-decoration: none;
        max-width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .nearby-item-name-link {
        font-size: 0.8125rem;
        font-weight: 500;
        color: ${theme.link};
        text-decoration: none;
        cursor: pointer;
        max-width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .nearby-item-name-link:hover {
        color: ${theme.linkHover};
        text-decoration: underline;
    }

    .nearby-item-name-link:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    .nearby-item-name.has-link {
        color: ${theme.link};
        cursor: pointer;
    }

    .nearby-item-name.has-link:hover {
        color: ${theme.linkHover};
        text-decoration: underline;
    }

    .nearby-item-secondary {
        font-size: 0.75rem;
        color: ${theme.textMuted};
    }

    .nearby-item-distance {
        flex-shrink: 0;
        padding: 4px 10px;
        background: ${theme.bgAlt};
        border: 1px solid ${theme.border};
        border-radius: 12px;
        font-size: 0.6875rem;
        font-weight: 600;
        color: ${theme.textSecondary};
        white-space: nowrap;
    }

    .nearby-no-results {
        padding: 12px;
        text-align: center;
        color: ${theme.textMuted};
        font-size: 0.75rem;
        font-style: italic;
    }

    .nearby-error {
        padding: 12px;
        text-align: center;
        color: ${theme.error};
        font-size: 0.75rem;
        background: ${theme.errorBg};
        border-radius: 4px;
    }

    /* ===== Separate Pane for Related Tables ===== */
    .related-table-separate-pane-trigger {
        background: ${theme.bgAlt};
        border: 1px solid ${theme.borderLight};
        border-radius: 4px;
        padding: 12px;
        text-align: center;
    }

    /* ===== Separate Pane for Sections ===== */
    .section-separate-pane-trigger {
        background: ${theme.bgAlt};
        border: 1px solid ${theme.borderLight};
        border-radius: 4px;
        padding: 16px;
        margin: 8px 12px;
        text-align: center;
    }

    /* ===== Nearby Separate Pane Triggers (individual layers) ===== */
    .nearby-separate-trigger {
        border-top: 1px solid ${theme.borderLight};
    }

    .nearby-separate-trigger:first-child {
        border-top: none;
    }

    .nearby-separate-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 16px;
        cursor: pointer;
        background: ${theme.bgAlt};
        transition: background-color 0.15s ease;
    }

    .nearby-separate-header:hover {
        background: ${theme.borderLight};
    }

    .nearby-separate-header:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: -2px;
    }

    .nearby-separate-header-left {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .nearby-separate-header-right {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .nearby-separate-title {
        font-size: 0.875rem;
        font-weight: 600;
        color: ${theme.textPrimary};
    }

    .nearby-separate-badge {
        font-size: 0.75rem;
        color: ${theme.textMuted};
        padding: 2px 8px;
        background: ${theme.white};
        border-radius: 10px;
    }

    .nearby-separate-toggle {
        width: 16px;
        height: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        color: ${theme.textMuted};
        transition: transform 0.2s ease;
    }

    .nearby-separate-toggle.open {
        transform: rotate(180deg);
    }

    .nearby-separate-body {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease-out;
    }

    .nearby-separate-body.open {
        max-height: none;
        transition: max-height 0.3s ease-in;
    }

    .nearby-separate-content {
        background: ${theme.white};
        border-top: 1px solid ${theme.borderLight};
        padding: 16px;
        text-align: center;
    }

    .nearby-separate-count {
        margin: 0 0 8px;
        font-size: 12px;
        color: ${theme.textSecondary};
    }

    .section-pane-content {
        padding: 0;
    }

    .section-pane-content .layer-subsection {
        margin: 0;
        border: none;
    }

    .section-pane-content .charts-container {
        padding: 0 0 16px;
    }

    .view-details-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        background: var(--theme-primary);
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 0.75rem;
        font-weight: 500;
        cursor: pointer;
        transition: background 0.2s ease;
    }

    .view-details-btn:hover {
        background: var(--theme-primary-dark);
    }

    .view-details-btn:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    /* Separate Pane Container - flex layout to fill widget */
    .separate-pane {
        flex: 1 1 auto;
        min-height: 0;
        background: ${theme.white};
        z-index: 100;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .separate-pane-header {
        flex-shrink: 0;
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 16px;
        background: ${theme.sectionHeaderBg};
        border-bottom: 1px solid ${theme.border};
    }

    .back-btn {
        display: flex;
        align-items: center;
        gap: 4px;
        padding: 6px 10px;
        background: transparent;
        border: 1px solid ${theme.border};
        border-radius: 4px;
        font-size: 0.75rem;
        color: ${theme.textPrimary};
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .back-btn:hover {
        background: ${theme.white};
        border-color: var(--theme-primary);
        color: var(--theme-primary);
    }

    .back-btn:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    .separate-pane-title {
        flex: 1;
    }

    .separate-pane-title h2 {
        margin: 0;
        font-size: 0.875rem;
        font-weight: 600;
        color: var(--theme-primary);
    }

    .separate-pane-subtitle {
        font-size: 0.6875rem;
        color: ${theme.textMuted};
        margin-top: 2px;
    }

    .separate-pane-content {
        flex: 1 1 auto;
        min-height: 0;
        overflow: auto;
        padding: 16px;
    }

    /* Remove horizontal scroll from nested elements - parent handles it */
    .separate-pane-content .table-wrapper {
        overflow-x: visible;
        overflow-y: visible;
    }

    /* Related table body in separate pane */
    .separate-pane-content .related-table-body > div {
        overflow-x: visible;
        overflow-y: visible;
    }

    /* ===== Footer Actions ===== */
    .actions-footer {
        padding: 15px 20px;
        background: ${theme.white};
        border-top: 1px solid ${theme.border};
        display: flex;
        gap: 10px;
    }

    .btn {
        padding: 8px 16px;
        font-size: 0.8125rem;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .btn:focus {
        outline: 2px solid ${theme.focusOutline};
        outline-offset: 2px;
    }

    .btn-primary {
        background: var(--theme-primary);
        color: white;
        border: none;
    }

    .btn-primary:hover { background: var(--theme-primary-dark); }

    .btn-secondary {
        background: ${theme.white};
        color: ${theme.textPrimary};
        border: 1px solid ${theme.border};
    }

    .btn-secondary:hover { background: ${theme.bgAlt}; }

    /* ===== States ===== */
    .empty-state {
        padding: 40px 20px;
        text-align: center;
        color: ${theme.textSecondary};
    }

    .empty-state p {
        margin: 8px 0;
        font-size: 0.875rem;
        line-height: 1.5;
    }

    .empty-state strong {
        color: ${theme.textPrimary};
        font-size: 1rem;
    }

    .loading-state {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 60px;
        color: ${theme.textSecondary};
    }
    .loading-state .loading-primary {
        margin-top: 12px;
        font-weight: 500;
        color: ${theme.textPrimary};
        text-align: center;
    }
    .loading-state .loading-secondary {
        margin-top: 4px;
        font-size: 12px;
        color: ${theme.textSecondary};
        text-align: center;
        max-width: 260px;
    }
    .loading-state .loading-slow-hint {
        margin-top: 8px;
        font-size: 12px;
        color: ${theme.textSecondary};
        text-align: center;
        max-width: 260px;
        opacity: 0;
        animation: prw-loading-slow-hint 0.4s ease 8s forwards;
    }
    @keyframes prw-loading-slow-hint {
        to { opacity: 1; }
    }
    .streaming-note { padding: 8px 16px; font-size: 12px; color: ${theme.textSecondary}; display: flex; align-items: center; gap: 8px; }
    .recent-searches { padding: 10px 16px 0; }
    .recent-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; }
    .recent-label { font-size: 12px; font-weight: 600; color: ${theme.textSecondary}; }
    .recent-chips { display: flex; flex-direction: column; gap: 4px; }
    .recent-chip { display: block; width: 100%; text-align: left; border: 1px solid ${theme.borderLight}; background: ${theme.bgAlt}; border-radius: 6px; padding: 6px 10px; font-size: 12px; cursor: pointer; color: ${theme.textPrimary}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .recent-chip:hover { border-color: #1976d2; background: ${theme.white}; }
    .recent-clear { border: none; background: none; font-size: 11px; color: ${theme.textMuted}; cursor: pointer; text-decoration: underline; flex-shrink: 0; }
    .report-summary { margin: 10px 16px 0; padding: 10px 12px; background: ${theme.bgAlt}; border-left: 3px solid #1976d2; border-radius: 4px; font-size: 13px; line-height: 1.5; color: ${theme.textPrimary}; }
    .section-tools { display: flex; justify-content: flex-end; margin: 0 0 6px; }
    .csv-export-btn { display: inline-flex; align-items: center; gap: 4px; border: 1px solid ${theme.borderLight}; background: #ffffff; border-radius: 4px; padding: 2px 8px; font-size: 11px; cursor: pointer; color: ${theme.textSecondary}; }
    .csv-export-btn:hover { color: ${theme.textPrimary}; border-color: #1976d2; }
    .section-alerts { display: flex; flex-direction: column; gap: 6px; margin-bottom: 8px; }
    .section-alert { padding: 8px 10px; border-radius: 4px; font-size: 12.5px; border: 1px solid; }
    .section-alert-info { background: #eef6fd; border-color: #90c7f0; color: #0b5394; }
    .section-alert-warning { background: #fdf6e3; border-color: #f0d48a; color: #7a5b00; }
    .section-alert-critical { background: #fdecea; border-color: #f2a6a0; color: #8a1c12; }
    .comparison-pending { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: 8px 16px 0; padding: 8px 12px; background: #eef6fd; border: 1px solid #90c7f0; border-radius: 4px; font-size: 12.5px; color: #0b5394; }
    .comparison-panel { margin: 10px 16px 0; border: 1px solid ${theme.borderLight}; border-radius: 6px; background: #ffffff; }
    .comparison-header { display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; border-bottom: 1px solid ${theme.borderLight}; background: ${theme.bgAlt}; border-radius: 6px 6px 0 0; }
    .comparison-title { font-size: 13px; font-weight: 600; color: ${theme.textPrimary}; }
    .comparison-close { border: none; background: none; cursor: pointer; color: ${theme.textSecondary}; display: inline-flex; padding: 4px; }
    .comparison-group { padding: 8px 12px 4px; }
    .comparison-group-title { font-size: 12px; font-weight: 600; color: ${theme.textSecondary}; text-transform: uppercase; letter-spacing: 0.03em; margin-bottom: 4px; }
    .comparison-table { width: 100%; border-collapse: collapse; font-size: 12.5px; margin-bottom: 8px; }
    .comparison-table th, .comparison-table td { text-align: left; padding: 4px 6px; border-bottom: 1px solid ${theme.borderLight}; vertical-align: top; }
    .comparison-table thead th { font-weight: 600; color: ${theme.textSecondary}; }
    .comparison-table tbody th { font-weight: 500; color: ${theme.textPrimary}; width: 34%; }
    .comparison-diff td, .comparison-diff th { background: #fdf6e3; }
    .comparison-note { padding: 0 12px 10px; font-size: 11.5px; color: ${theme.textMuted}; margin: 0; }

    .pdf-generating-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255, 255, 255, 0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
    }

    .pdf-generating-content {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 24px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        position: sticky;
        top: 50%;
        transform: translateY(-50%);
    }

    /* Lock scrolling during PDF generation */
    .results-container.generating-pdf {
        overflow-y: hidden !important;
    }

    /* ===== ACCESSIBILITY: Error Banner with Alert Role ===== */
    .error-banner {
        padding: 12px 20px;
        background: ${theme.errorBg};
        border-bottom: 1px solid #FFDDDD;
        color: ${theme.error};
        font-size: 0.8125rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .error-close {
        background: none;
        border: none;
        color: ${theme.error};
        font-size: 1.25rem;
        cursor: pointer;
        padding: 4px 8px;
        line-height: 1;
    }

    .error-close:hover {
        background: rgba(0,0,0,0.1);
    }

    .error-close:focus {
        outline: 2px solid ${theme.error};
        outline-offset: 2px;
    }

    .no-results {
        padding: 20px;
        text-align: center;
        color: ${theme.textMuted};
        font-style: italic;
        font-size: 0.8125rem;
    }

    /* ===== Scrollbar ===== */
    ::-webkit-scrollbar { width: 8px; }
    ::-webkit-scrollbar-track { background: ${theme.bgAlt}; }
    ::-webkit-scrollbar-thumb { background: #BBB; border-radius: 4px; }
    ::-webkit-scrollbar-thumb:hover { background: #999; }

    /* ===== ACCESSIBILITY: High Contrast Mode Support ===== */
    @media (prefers-contrast: high) {
        .search-input,
        .table-filter-input,
        .pagination-btn,
        .action-icon,
        .select-location-btn {
            border-width: 2px;
        }

        *:focus,
        *:focus-visible {
            outline-width: 3px;
        }
    }

    /* ===== ACCESSIBILITY: Reduced Motion Support ===== */
    @media (prefers-reduced-motion: reduce) {
        *,
        *::before,
        *::after {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
        }
    }

    /* ===== MOBILE RESPONSIVE STYLES ===== */
    /* Small screens and mobile devices */
    @media (max-width: 480px) {
        /* Search Header - Stack elements vertically on very small screens */
        .search-header {
            padding: 8px 10px;
        }

        .search-row {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: stretch;
        }

        .search-input-container {
            flex: 1 1 100%;
            order: 1;
        }

        .search-input {
            height: 40px;
            font-size: 16px; /* Prevents iOS zoom on focus */
        }

        .select-location-btn {
            order: 2;
            flex: 0 0 44px;
            height: 40px;
            width: 44px;
        }

        .search-btn {
            flex: 1 1 auto;
            order: 3;
            min-width: 0;
            height: 40px;
            padding: 0 16px;
            font-size: 0.9375rem;
        }

        /* Suggestions dropdown - larger items for touch */
        .suggestions-dropdown {
            max-height: 250px;
        }

        .suggestion-item {
            padding: 12px;
            min-height: 48px;
        }

        .suggestion-text {
            font-size: 0.9375rem;
        }

        /* Address Header - Improved mobile layout */
        .address-header {
            padding: 10px 12px;
            flex-direction: row;
            flex-wrap: wrap;
            align-items: flex-start;
            gap: 8px;
        }

        .address-info {
            min-width: 0; /* Allow text truncation */
            flex: 1 1 100%; /* Full width; buttons move to their own row below */
            order: 1;
        }

        .address-title {
            font-size: 1rem;
            word-break: break-word;
            overflow-wrap: break-word;
            hyphens: auto;
            line-height: 1.3;
            padding-right: 5px;
        }

        .address-subtitle {
            font-size: 0.75rem;
            word-break: break-all;
        }

        .header-info-fields {
            gap: 6px 10px;
            margin-top: 6px;
        }

        .header-info-item {
            font-size: 0.8125rem;
            flex: 0 0 auto;
            max-width: 100%;
        }

        .header-info-label,
        .header-info-value {
            overflow: visible;
            text-overflow: clip;
            white-space: normal;
            overflow-wrap: anywhere;
        }

        .address-actions {
            order: 2;
            flex: 1 1 100%;
            justify-content: flex-end;
            gap: 6px;
            padding-top: 8px;
            margin-top: 2px;
            border-top: 1px solid ${theme.borderLight};
        }

        .action-icon {
            width: 28px;
            height: 28px;
        }

        .action-icon svg {
            width: 16px;
            height: 16px;
        }

        /* Section Headers */
        .pm-section-header {
            padding: 10px 12px;
        }

        .pm-section-title {
            font-size: 0.8125rem;
        }

        /* Layer Headers */
        .layer-header {
            padding: 8px 12px;
        }

        /* Table Improvements */
        .table-wrapper {
            font-size: 0.75rem;
        }

        .table-filter-input {
            width: 100%;
        }

        .pagination-controls {
            justify-content: center;
            width: 100%;
        }

        /* Property Preview */
        .property-preview-header {
            padding: 10px 12px;
            flex-direction: column;
            gap: 8px;
        }

        .property-preview-content {
            padding: 10px 12px;
        }

        /* Nearby sections */
        .nearby-section {
            margin: 0 8px;
        }

        .nearby-header {
            padding: 8px 10px;
        }

        .nearby-item {
            padding: 8px 10px;
        }

        /* Separate Pane */
        .separate-pane-header {
            padding: 10px 12px;
        }

        .separate-pane-content {
            padding: 0 8px;
        }

        /* Empty state - reduced padding on mobile */
        .empty-state {
            padding: 30px 15px;
        }

        .empty-state p {
            font-size: 0.8125rem;
        }

        /* Error banner - better wrapping and tap target */
        .error-banner {
            padding: 10px 12px;
            gap: 8px;
        }

        .error-banner span {
            flex: 1;
            line-height: 1.4;
        }

        .error-close {
            min-width: 32px;
            min-height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    }

    /* Medium screens - tablets and small laptops */
    @media (max-width: 768px) and (min-width: 481px) {
        .address-header {
            padding: 12px 15px;
        }

        .address-title {
            font-size: 1.125rem;
            word-break: break-word;
            overflow-wrap: break-word;
        }

        .header-info-fields {
            gap: 8px 12px;
        }

        .header-info-item {
            font-size: 0.8125rem;
        }

        .pm-section-header {
            padding: 10px 15px;
        }

        .layer-header {
            padding: 8px 15px;
        }
    }

    /* Touch device optimizations */
    @media (hover: none) and (pointer: coarse) {
        /* Larger touch targets (WCAG 2.5.5 - Target Size) */
        .action-icon {
            min-width: 44px;
            min-height: 44px;
        }

        .pm-section-header,
        .layer-header,
        .nearby-header,
        .related-table-header {
            min-height: 44px;
        }

        .suggestion-item {
            padding: 12px;
            min-height: 44px;
        }

        .pagination-btn {
            min-width: 36px;
            min-height: 36px;
        }

        /* Improve tap feedback */
        .search-btn:active,
        .select-location-btn:active,
        .action-icon:active {
            opacity: 0.7;
        }
    }

    /* Landscape mobile - prevent header from taking too much space */
    @media (max-height: 500px) and (orientation: landscape) {
        .address-header {
            padding: 8px 12px;
            position: relative; /* Remove sticky on landscape mobile */
        }

        .address-title {
            font-size: 0.9375rem;
        }

        .header-info-fields {
            display: none; /* Hide extra fields in cramped landscape */
        }

        .search-header {
            padding: 6px 10px;
        }
    }


    /* NEW: error banner actions (retry + dismiss) */
    .error-actions { display: inline-flex; align-items: center; gap: 6px; flex-shrink: 0; }
    .error-retry {
        border: 1px solid currentColor;
        background: transparent;
        color: inherit;
        border-radius: 4px;
        padding: 2px 10px;
        font-size: 12px;
        min-height: 24px;
        cursor: pointer;
    }
    .error-retry:hover { background: rgba(0, 0, 0, 0.06); }
    .error-retry:focus-visible { outline: 2px solid currentColor; outline-offset: 1px; }

    /* NEW: shared reset for buttons that must look like the text they replaced,
       used where a div with role="button" was converted to a real button. */
    .pr-inline-btn {
        border: none;
        background: none;
        padding: 0;
        margin: 0;
        font: inherit;
        color: inherit;
        text-align: left;
        cursor: pointer;
    }
    .pr-inline-btn:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }

    /* NEW: whole-report empty state */
    .report-empty-summary {
        display: flex;
        gap: 10px;
        align-items: flex-start;
        margin: 10px 12px;
        padding: 12px 14px;
        border: 1px solid ${theme.borderLight};
        border-left: 4px solid ${theme.sectionHeader};
        border-radius: 6px;
        background: ${theme.sectionHeaderBg};
        color: ${theme.textPrimary};
        font-size: 13px;
        line-height: 1.5;
    }
    .report-empty-summary svg { flex-shrink: 0; color: ${theme.sectionHeader}; margin-top: 1px; }
    .report-empty-summary strong { display: block; margin-bottom: 2px; }
    .report-empty-summary span { color: ${theme.textSecondary}; }

    /* ===== Bells and whistles ===== */

    /* More menu */
    .more-menu { position: relative; display: inline-flex; }
    .more-menu-list {
        position: absolute;
        top: calc(100% + 4px);
        right: 0;
        min-width: 220px;
        background: ${theme.white};
        border: 1px solid ${theme.border};
        border-radius: 6px;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        padding: 4px;
        z-index: 30;
        display: flex;
        flex-direction: column;
    }
    .more-menu-item {
        border: none;
        background: none;
        text-align: left;
        padding: 8px 10px;
        font-size: 13px;
        color: ${theme.textPrimary};
        border-radius: 4px;
        cursor: pointer;
        min-height: 32px;
    }
    .more-menu-item:hover, .more-menu-item:focus-visible { background: ${theme.sectionHeaderBg}; outline: none; }
    .more-menu-item:focus-visible { box-shadow: inset 0 0 0 2px ${theme.focusOutline}; }

    /* Report tools strip (find, refresh, unit) */
    .report-tools {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 6px 12px;
        border-bottom: 1px solid ${theme.borderLight};
        background: ${theme.bgAlt};
        flex-wrap: wrap;
    }
    .tool-spacer { flex: 1 1 auto; }
    .tool-chip {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        border: 1px solid ${theme.borderLight};
        background: ${theme.white};
        color: ${theme.textSecondary};
        border-radius: 999px;
        padding: 3px 10px;
        font-size: 12px;
        min-height: 26px;
        cursor: pointer;
    }
    .tool-chip:hover { color: ${theme.textPrimary}; border-color: ${theme.sectionHeader}; }
    .tool-chip:disabled { opacity: 0.5; cursor: default; }
    .tool-chip:focus-visible { outline: 2px solid ${theme.focusOutline}; outline-offset: 1px; }
    .tool-select-wrap { padding: 0 6px 0 8px; }
    .tool-select { border: none; background: transparent; font-size: 12px; color: inherit; min-height: 24px; }
    .tool-stamp { font-size: 11px; color: ${theme.textMuted}; }

    .find-bar {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: ${theme.white};
        border: 1px solid ${theme.border};
        border-radius: 6px;
        padding: 2px 6px 2px 8px;
        color: ${theme.textSecondary};
        flex: 1 1 260px;
        max-width: 420px;
    }
    .find-bar:focus-within { border-color: ${theme.focusOutline}; box-shadow: 0 0 0 2px rgba(0, 86, 179, 0.2); }
    .find-input { flex: 1 1 auto; border: none; background: transparent; font-size: 13px; min-height: 26px; color: ${theme.textPrimary}; outline: none; min-width: 0; }
    .find-count { font-size: 11px; color: ${theme.textMuted}; white-space: nowrap; }
    .find-close { border: none; background: none; font-size: 16px; line-height: 1; color: ${theme.textMuted}; cursor: pointer; padding: 2px 4px; min-width: 24px; min-height: 24px; }
    .find-close:hover { color: ${theme.textPrimary}; }
    .find-mark { background: #FFF3B0; color: inherit; padding: 0 1px; border-radius: 2px; }
    .find-badge {
        display: inline-block;
        margin-left: 8px;
        font-size: 0.6875rem;
        font-weight: 600;
        text-transform: none;
        color: ${theme.sectionHeader};
        background: ${theme.white};
        border: 1px solid ${theme.sectionHeader};
        border-radius: 999px;
        padding: 0 7px;
        vertical-align: middle;
    }
    .find-badge-none { color: ${theme.textMuted}; border-color: ${theme.borderLight}; }

    /* Streaming progress */
    .load-progress { position: relative; height: 18px; margin: 0 12px 6px; background: ${theme.bgAlt}; border-radius: 4px; overflow: hidden; }
    .load-progress-bar { position: absolute; inset: 0 auto 0 0; background: ${theme.sectionHeader}; opacity: 0.25; transition: width 0.25s ease; }
    .load-progress-text { position: relative; display: block; text-align: center; font-size: 11px; line-height: 18px; color: ${theme.textSecondary}; }

    /* Panels (saved reports, QR, shortcuts) */
    .pr-panel-backdrop {
        position: absolute;
        inset: 0;
        background: rgba(0, 0, 0, 0.35);
        display: flex;
        align-items: flex-start;
        justify-content: center;
        padding: 24px 12px;
        z-index: 40;
        overflow: auto;
    }
    .pr-panel {
        background: ${theme.white};
        border-radius: 8px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.25);
        width: min(560px, 100%);
        max-height: 100%;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }
    .pr-panel-narrow { width: min(400px, 100%); }
    .pr-panel-header { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border-bottom: 1px solid ${theme.borderLight}; }
    .pr-panel-header h2 { margin: 0; font-size: 0.9375rem; color: ${theme.textPrimary}; }
    .pr-panel-close { border: none; background: none; font-size: 20px; line-height: 1; color: ${theme.textMuted}; cursor: pointer; min-width: 28px; min-height: 28px; border-radius: 4px; }
    .pr-panel-close:hover { color: ${theme.textPrimary}; background: ${theme.bgAlt}; }
    .pr-panel-body { padding: 12px 16px 16px; overflow: auto; font-size: 13px; color: ${theme.textPrimary}; }
    .pr-panel-body h3 { margin: 8px 0 6px; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.04em; color: ${theme.textMuted}; }
    .pr-panel-subhead { display: flex; align-items: center; justify-content: space-between; margin-top: 14px; }
    .pr-panel-empty { color: ${theme.textMuted}; margin: 4px 0 8px; }
    .pr-panel-note { color: ${theme.textMuted}; font-size: 11px; margin: 12px 0 0; }
    .pr-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
    .pr-list-item { display: flex; align-items: center; gap: 8px; border: 1px solid ${theme.borderLight}; border-radius: 6px; padding: 6px 8px; }
    .pr-list-main { flex: 1 1 auto; min-width: 0; border: none; background: none; text-align: left; cursor: pointer; display: flex; flex-direction: column; gap: 2px; padding: 2px 4px; border-radius: 4px; }
    .pr-list-main:hover { background: ${theme.sectionHeaderBg}; }
    .pr-list-main:focus-visible { outline: 2px solid ${theme.focusOutline}; }
    .pr-list-name { font-weight: 600; color: ${theme.textPrimary}; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .pr-list-sub, .pr-list-counts { font-size: 11px; color: ${theme.textMuted}; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .pr-list-actions { display: inline-flex; gap: 4px; flex-shrink: 0; }
    .pr-mini { border: 1px solid ${theme.borderLight}; background: ${theme.white}; color: ${theme.textSecondary}; border-radius: 4px; padding: 3px 8px; font-size: 11px; cursor: pointer; min-height: 24px; }
    .pr-mini:hover { color: ${theme.textPrimary}; border-color: ${theme.sectionHeader}; }
    .pr-mini-danger:hover { color: ${theme.error}; border-color: ${theme.error}; }
    .pr-qr-body { display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center; }
    .pr-qr-body img { border: 1px solid ${theme.borderLight}; border-radius: 6px; background: #fff; padding: 6px; }
    .pr-qr-url { font-size: 11px; color: ${theme.textMuted}; word-break: break-all; margin: 0; max-width: 100%; }
    .pr-qr-actions { display: flex; gap: 8px; }
    .pr-keys { margin: 0; display: grid; grid-template-columns: auto 1fr; gap: 6px 14px; }
    .pr-keys-row { display: contents; }
    .pr-keys dt, .pr-keys dd { margin: 0; }
    .pr-keys kbd { display: inline-block; min-width: 22px; text-align: center; border: 1px solid ${theme.border}; border-bottom-width: 2px; border-radius: 4px; padding: 1px 6px; font-family: inherit; font-size: 12px; background: ${theme.bgAlt}; }

    /* Click-to-copy on values */
    .copyable { display: inline; }
    .copy-value-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        height: 20px;
        margin-left: 4px;
        padding: 0;
        border: none;
        border-radius: 3px;
        background: transparent;
        color: ${theme.textMuted};
        vertical-align: middle;
        cursor: pointer;
        opacity: 0;
        transition: opacity 0.12s;
    }
    .data-row:hover .copy-value-btn,
    .header-info-item:hover .copy-value-btn,
    .copy-value-btn:focus-visible,
    .copyable.copied .copy-value-btn { opacity: 1; }
    .copy-value-btn:hover { background: ${theme.bgAlt}; color: ${theme.textPrimary}; }
    .copy-value-btn:focus-visible { outline: 2px solid ${theme.focusOutline}; outline-offset: 1px; }
    .copyable.copied .copy-value-btn { color: #2E7D32; }
    @media (hover: none) { .copy-value-btn { opacity: 0.6; } }

    /* =====================================================
       PRINT
       The widget previously had no print rules at all, so using the
       browser's own Print command produced the live UI: search box,
       toolbar icons, collapsed sections and all. These rules turn the
       report into a printable document without going through PDF
       export, which matters for anyone who just wants a paper copy or
       a "Print to PDF" from the browser.
       ===================================================== */
    @media print {
        /* Ink and contrast: print black on white regardless of theme. */
        .jimu-widget, .widget-property-report {
            background: #ffffff !important;
            color: #000000 !important;
            height: auto !important;
            overflow: visible !important;
        }

        /* Interactive chrome has no meaning on paper. */
        .skip-link,
        .search-header,
        .suggestions-dropdown,
        .recent-searches,
        .address-actions,
        .action-icon,
        .csv-export-btn,
        .pagination-controls,
        .property-preview-actions,
        .row-zoom-btn,
        .view-details-btn,
        .error-close,
        .comparison-close,
        .search-clear-btn,
        .pdf-generating-overlay,
        .loading-state,
        .expand-all-btn,
        .report-tools,
        .load-progress,
        .more-menu,
        .pr-panel-backdrop,
        .copy-value-btn,
        .find-badge {
            display: none !important;
        }

        /* Collapsed content must print. Nothing is hidden on paper. */
        .pm-section-body,
        .layer-body,
        .nearby-body,
        .related-table-body,
        .nearby-separate-body {
            display: block !important;
            max-height: none !important;
            overflow: visible !important;
            opacity: 1 !important;
            visibility: visible !important;
        }
        .pm-section-toggle,
        .layer-toggle,
        .nearby-toggle {
            display: none !important;
        }

        /* Keep a section, table row or chart from splitting across pages. */
        .pm-section {
            break-inside: avoid;
            page-break-inside: avoid;
            border: 1px solid #cccccc !important;
            box-shadow: none !important;
            margin-bottom: 10pt;
        }
        .pm-section-header,
        .layer-header,
        .related-table-header {
            break-after: avoid;
            page-break-after: avoid;
        }
        tr, .data-row, .related-card, .nearby-item, .chart-box {
            break-inside: avoid;
            page-break-inside: avoid;
        }
        thead { display: table-header-group; }
        tfoot { display: table-footer-group; }

        /* Tables: full width, visible rules, no sticky positioning. */
        .table-wrapper, .table-wrapper.sticky-header {
            overflow: visible !important;
            max-height: none !important;
        }
        .table-wrapper.sticky-header thead,
        .table-wrapper.sticky-header thead th {
            position: static !important;
        }
        table { width: 100% !important; border-collapse: collapse !important; }
        th, td {
            border: 1px solid #bbbbbb !important;
            padding: 3pt 4pt !important;
            font-size: 9pt !important;
            color: #000000 !important;
        }
        th { background: #eeeeee !important; }

        /* The report title should read as a document heading. */
        .address-header {
            position: static !important;
            border-bottom: 2pt solid #000000 !important;
            padding: 0 0 6pt 0 !important;
            background: #ffffff !important;
        }
        .address-title { font-size: 16pt !important; color: #000000 !important; }
        .pm-section-title { font-size: 11pt !important; }

        /* Spell out link targets, which a reader cannot click on paper. */
        .rich-text-content a[href^="http"]::after {
            content: " (" attr(href) ")";
            font-size: 8pt;
            word-break: break-all;
        }

        /* Charts and images must fit the page. */
        img, svg, canvas, .recharts-wrapper {
            max-width: 100% !important;
            height: auto !important;
            break-inside: avoid;
            page-break-inside: avoid;
        }

        /* Never animate while printing. */
        *, *::before, *::after {
            animation: none !important;
            transition: none !important;
        }
    }
`
