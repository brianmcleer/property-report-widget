/**
 * SQL where-clause helpers for the Property Report runtime. Owns literal
 * escaping for ArcGIS REST where clauses (single quotes doubled), IN list
 * construction that quotes strings and passes numbers through, and array
 * chunking used to keep IN lists and object id requests within service limits.
 */

// Doubles single quotes so a value can be embedded in a quoted SQL literal.
export const escapeSqlLiteral = (v: string): string => {
    if (v === null || v === undefined) return ''
    return String(v).replace(/'/g, "''")
}

// Builds the parenthesized body of an IN (...) clause. Finite numbers are
// emitted bare; everything else is quoted and escaped. Empty input yields
// "(NULL)" so the resulting where clause matches nothing instead of erroring.
export const sqlInList = (values: Array<string | number>): string => {
    if (!values || values.length === 0) return '(NULL)'
    const parts = values.map(v => {
        if (typeof v === 'number' && Number.isFinite(v)) return String(v)
        return `'${escapeSqlLiteral(String(v))}'`
    })
    return `(${parts.join(', ')})`
}

// Splits an array into consecutive slices of at most `size` items.
export const chunk = <T,>(arr: T[], size: number): T[][] => {
    if (!arr || arr.length === 0) return []
    const n = Math.max(1, Math.floor(size) || 1)
    const out: T[][] = []
    for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n))
    return out
}
