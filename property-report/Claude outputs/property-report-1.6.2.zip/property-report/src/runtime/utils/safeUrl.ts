/**
 * URL safety helper for the Property Report runtime. Owns the single rule for
 * which user-configured or data-driven URLs may be rendered as link targets:
 * only http, https, mailto and tel schemes are accepted, optionally allowing
 * relative URLs resolved against the current page. Anything else (javascript:,
 * data:, vbscript:, malformed input) yields undefined so callers can render a
 * disabled label instead of a link.
 */

const ALLOWED_PROTOCOLS = new Set(['http:', 'https:', 'mailto:', 'tel:'])

// Matches an explicit scheme prefix such as "https:" or "mailto:".
const HAS_SCHEME_RE = /^[a-z][a-z0-9+.-]*:/i

export const toSafeHref = (
    raw: string | null | undefined,
    opts?: { allowRelative?: boolean }
): string | undefined => {
    if (raw == null) return undefined
    const text = String(raw).trim()
    if (!text) return undefined
    // Control characters or non-breaking spaces inside a URL are a common
    // obfuscation trick (for example "java[TAB]script:"); reject outright.
    // eslint-disable-next-line no-control-regex
    if (/[\u0000-\u001f\u00a0]/.test(text)) return undefined

    let url: URL
    try {
        if (opts?.allowRelative) {
            const base = typeof window !== 'undefined' && window.location ? window.location.href : undefined
            url = base ? new URL(text, base) : new URL(text)
        } else {
            url = new URL(text)
        }
    } catch (e) {
        return undefined
    }

    if (!ALLOWED_PROTOCOLS.has(url.protocol)) return undefined
    // Return the original text for absolute URLs so query strings and fragments
    // are not re-encoded; return the resolved URL for relative input.
    if (opts?.allowRelative && !HAS_SCHEME_RE.test(text)) return url.href
    return text
}
