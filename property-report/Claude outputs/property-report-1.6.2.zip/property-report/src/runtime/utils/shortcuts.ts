/**
 * Keyboard shortcuts for the Property Report runtime. Owns the shortcut table
 * and the pure matcher that turns a keyboard event into an action id. Shortcuts
 * are single keys with no modifier so they never collide with browser or screen
 * reader commands, and they are ignored while the user is typing in a field
 * (except Escape, which is how you leave a field).
 */

export type ShortcutAction =
    | 'focusSearch' | 'find' | 'print' | 'pdf' | 'copy' | 'save' | 'expandAll' | 'clear' | 'help' | 'escape'

export interface Shortcut { key: string, action: ShortcutAction, label: string }

export const SHORTCUTS: Shortcut[] = [
    { key: '/', action: 'focusSearch', label: 'Focus the search box' },
    { key: 'f', action: 'find', label: 'Find in report' },
    { key: 'p', action: 'print', label: 'Print' },
    { key: 'd', action: 'pdf', label: 'Download PDF' },
    { key: 'c', action: 'copy', label: 'Copy report as text' },
    { key: 's', action: 'save', label: 'Save this report' },
    { key: 'e', action: 'expandAll', label: 'Expand or collapse all sections' },
    { key: 'x', action: 'clear', label: 'Clear results' },
    { key: '?', action: 'help', label: 'Show keyboard shortcuts' },
    { key: 'Escape', action: 'escape', label: 'Close panels or clear the find box' }
]

export interface KeyLike {
    key: string
    ctrlKey?: boolean
    metaKey?: boolean
    altKey?: boolean
    // The event target, used to decide whether the user is typing.
    target?: { tagName?: string, isContentEditable?: boolean, getAttribute?: (n: string) => string | null } | null
}

const isTypingTarget = (t: KeyLike['target']): boolean => {
    if (!t) return false
    const tag = (t.tagName || '').toUpperCase()
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return true
    if (t.isContentEditable) return true
    const role = t.getAttribute ? t.getAttribute('role') : null
    return role === 'textbox' || role === 'combobox' || role === 'searchbox'
}

// Returns the action for an event, or null when it should be ignored.
export const matchShortcut = (e: KeyLike): ShortcutAction | null => {
    if (e.ctrlKey || e.metaKey || e.altKey) return null
    const typing = isTypingTarget(e.target)
    if (e.key === 'Escape') return 'escape'
    if (typing) return null
    const hit = SHORTCUTS.find(s => s.key === e.key || s.key.toLowerCase() === e.key.toLowerCase())
    return hit ? hit.action : null
}
