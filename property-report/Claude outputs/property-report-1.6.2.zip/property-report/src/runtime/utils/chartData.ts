/**
 * Chart data aggregation for the Property Report runtime. Owns the pure
 * transformation from attribute records to Recharts-ready rows: category mode
 * groups records by a field and aggregates a value field (count, sum, avg, min,
 * max) with sorting and an "Other" bucket beyond maxCategories; fields mode
 * compares several numeric fields, optionally grouped by a category. This is
 * the same logic the section query uses, exposed so related table charts can
 * aggregate their records instead of passing raw rows to the chart.
 */
import type { ChartConfig, ChartFieldConfig } from '../../config'
import { CHART_COLORS } from '../theme/tokens'
import { toMutable } from './configMerge'

export interface ChartDatum {
    name: string
    value: number
    fill?: string
    // Fields mode with groupByField adds one numeric key per compared field (alias or field name).
    [series: string]: any
}

const round2 = (n: number): number => Math.round(n * 100) / 100

export const aggregateChartData = (records: any[], chartConfig: ChartConfig | null | undefined): ChartDatum[] => {
    const rows = Array.isArray(records) ? records : []
    if (rows.length === 0) return []

    const cfg: ChartConfig = (chartConfig && typeof (chartConfig as any).asMutable === 'function')
        ? (chartConfig as any).asMutable({ deep: true })
        : (chartConfig || {})

    const chartMode = cfg.chartMode || 'category'
    const categoryField = cfg.categoryField
    const valueField = cfg.valueField
    const aggregation = cfg.aggregation || 'count'
    const maxCategories = cfg.maxCategories || 10
    const sortBy = cfg.sortBy || 'value'
    const sortOrder = cfg.sortOrder || 'desc'
    const compareFields = toMutable<ChartFieldConfig>(cfg.compareFields)
    const groupByField = cfg.groupByField

    if (chartMode === 'fields') {
        // FIELDS COMPARISON MODE - compare multiple numeric fields
        const enabledFields = compareFields.filter(f => f && f.enabled)
        if (enabledFields.length === 0) return []

        if (groupByField) {
            // Group field comparison by a category
            const groups: Record<string, Record<string, number[]>> = {}
            rows.forEach(f => {
                const category = String(f?.[groupByField] ?? 'Unknown')
                if (!groups[category]) {
                    groups[category] = {}
                    enabledFields.forEach(ef => { groups[category][ef.fieldName] = [] })
                }
                enabledFields.forEach(ef => {
                    const numVal = parseFloat(f?.[ef.fieldName])
                    if (!isNaN(numVal)) groups[category][ef.fieldName].push(numVal)
                })
            })

            // Aggregate and format for multi-series chart. These rows carry one
            // key per compared field and deliberately no 'value' key: EnhancedChart
            // treats every key other than name/fill as a series, so adding 'value'
            // would draw an extra bar.
            return Object.entries(groups).map(([name, fieldValues]) => {
                const dataPoint: Record<string, any> = { name }
                enabledFields.forEach(ef => {
                    const values = fieldValues[ef.fieldName] || []
                    const sum = values.reduce((a, b) => a + b, 0)
                    dataPoint[ef.alias || ef.fieldName] = round2(sum)
                })
                return dataPoint as ChartDatum
            })
        }

        // Sum all values for each field (no grouping)
        const fieldTotals: Record<string, number> = {}
        enabledFields.forEach(ef => { fieldTotals[ef.fieldName] = 0 })
        rows.forEach(f => {
            enabledFields.forEach(ef => {
                const numVal = parseFloat(f?.[ef.fieldName])
                if (!isNaN(numVal)) fieldTotals[ef.fieldName] += numVal
            })
        })

        // Format as simple bar chart data
        return enabledFields.map((ef, i) => ({
            name: ef.alias || ef.fieldName,
            value: round2(fieldTotals[ef.fieldName]),
            fill: ef.color || CHART_COLORS[i % CHART_COLORS.length]
        }))
    }

    // CATEGORY MODE - group by a category field
    if (!categoryField) return []

    const groups: Record<string, number[]> = {}
    rows.forEach(f => {
        const category = String(f?.[categoryField] ?? 'Unknown')
        if (!groups[category]) groups[category] = []
        if (aggregation === 'count') {
            groups[category].push(1)
        } else if (valueField) {
            const numVal = parseFloat(f?.[valueField])
            if (!isNaN(numVal)) groups[category].push(numVal)
        }
    })

    // Aggregate values per category
    const aggregatedData: ChartDatum[] = Object.entries(groups).map(([name, values]) => {
        let value = 0
        if (values.length > 0) {
            switch (aggregation) {
                case 'count':
                    value = values.length
                    break
                case 'sum':
                    value = values.reduce((a, b) => a + b, 0)
                    break
                case 'avg':
                    value = values.reduce((a, b) => a + b, 0) / values.length
                    break
                case 'min':
                    value = Math.min(...values)
                    break
                case 'max':
                    value = Math.max(...values)
                    break
                default:
                    value = values.length
            }
        }
        // Round to 2 decimal places for display
        return { name, value: round2(value) }
    })

    // Sort data
    if (sortBy !== 'none') {
        aggregatedData.sort((a, b) => {
            if (sortBy === 'value') {
                return sortOrder === 'desc' ? b.value - a.value : a.value - b.value
            }
            return sortOrder === 'desc'
                ? b.name.localeCompare(a.name)
                : a.name.localeCompare(b.name)
        })
    }

    // Limit categories and group remainder as "Other"
    if (aggregatedData.length > maxCategories) {
        const topCategories = aggregatedData.slice(0, maxCategories - 1)
        const otherCategories = aggregatedData.slice(maxCategories - 1)
        const otherValue = otherCategories.reduce((sum, item) => sum + item.value, 0)
        topCategories.push({
            name: `Other (${otherCategories.length})`,
            value: round2(otherValue)
        })
        return topCategories
    }
    return aggregatedData
}
