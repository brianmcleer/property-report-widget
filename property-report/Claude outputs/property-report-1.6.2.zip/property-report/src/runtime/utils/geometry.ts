/**
 * Geometry helpers for the Property Report runtime. Owns extraction of
 * latitude and longitude from an ArcGIS Point without depending on the
 * projection engine: geographic points and Web Mercator points are converted
 * directly, anything in another projected system yields nulls so callers never
 * mistake projected x/y meters for degrees.
 */
import type Point from 'esri/geometry/Point'

const WEB_MERCATOR_WKIDS = new Set([3857, 102100, 102113, 900913])
const EARTH_RADIUS_M = 6378137

export const isWebMercatorWkid = (wkid: number | null | undefined): boolean =>
    wkid != null && WEB_MERCATOR_WKIDS.has(Number(wkid))

// Inverse spherical Mercator: meters to degrees.
const webMercatorToLatLng = (x: number, y: number): { lat: number, lng: number } => {
    const lng = (x / EARTH_RADIUS_M) * (180 / Math.PI)
    const lat = (2 * Math.atan(Math.exp(y / EARTH_RADIUS_M)) - Math.PI / 2) * (180 / Math.PI)
    return { lat, lng }
}

export const getCoordinates = (point: Point | null | undefined): { lat: number | null, lng: number | null } => {
    if (!point) return { lat: null, lng: null }
    if (point.latitude != null && point.longitude != null) return { lat: point.latitude, lng: point.longitude }
    const sr: any = point.spatialReference
    if (point.x == null || point.y == null) return { lat: null, lng: null }
    if (sr?.isGeographic) return { lat: point.y, lng: point.x }
    if (sr?.isWebMercator || isWebMercatorWkid(sr?.wkid) || isWebMercatorWkid(sr?.latestWkid)) {
        return webMercatorToLatLng(point.x, point.y)
    }
    // Some other projected coordinate system: x/y are not degrees. Callers that
    // need lat/lng must project first (see services/projection).
    return { lat: null, lng: null }
}
