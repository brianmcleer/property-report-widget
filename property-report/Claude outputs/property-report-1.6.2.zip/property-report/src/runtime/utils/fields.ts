/**
 * Field inspection helpers for the Property Report runtime. Owns field type
 * detection for sorting (explicit format type first, then a sample of record
 * values), the hideNull filter that drops columns whose values are all empty,
 * and small predicates over ArcGIS field type names.
 */
import type { FieldConfig } from '../../config'

export type DetectedFieldType = 'number' | 'date' | 'text'

const DATE_STRING_RE = /^\d{4}-\d{2}-\d{2}/
const US_DATE_STRING_RE = /^\d{1,2}\/\d{1,2}\/\d{2,4}/

const isEmpty = (v: any): boolean => v == null || v === ''

// Classifies a single value the same way the related table sorter does.
const detectValueType = (v: any): DetectedFieldType | null => {
    if (isEmpty(v)) return null
    if (typeof v === 'number') return 'number'
    if (v instanceof Date) return 'date'
    if (typeof v === 'string') {
        if (DATE_STRING_RE.test(v) || US_DATE_STRING_RE.test(v)) return 'date'
        if (!isNaN(parseFloat(v)) && isFinite(Number(v))) return 'number'
    }
    return 'text'
}

// Detect field type for smart sorting. The configured format type wins; otherwise
// the first non-empty value among the records decides. Accepts a FieldConfig or
// a bare field name.
export const detectFieldType = (field: FieldConfig | string, records: any[]): DetectedFieldType => {
    const name = typeof field === 'string' ? field : field?.name
    const formatType = typeof field === 'string' ? undefined : field?.format?.type
    if (formatType === 'date') return 'date'
    if (formatType === 'number') return 'number'
    if (formatType === 'text' || formatType === 'link') return 'text'

    if (!name || !records || records.length === 0) return 'text'
    for (const rec of records) {
        const t = detectValueType(rec?.[name])
        if (t) return t
    }
    return 'text'
}

// Filter out fields where hideNull is true and ALL values are null/empty.
export const filterHideNullFields = <T extends { name: string; hideNull?: boolean }>(fields: T[], rows: any[]): T[] => {
    if (!fields) return []
    const list = rows || []
    return fields.filter(field => {
        if (!field || !field.hideNull) return true // Keep field if hideNull is not enabled
        const allNull = list.every((row: any) => isEmpty(row?.[field.name]))
        return !allNull // Keep field if NOT all values are null
    })
}

export const fieldTypeIsDate = (esriType: string | null | undefined): boolean =>
    esriType === 'esriFieldTypeDate' || esriType === 'esriFieldTypeDateOnly' || esriType === 'esriFieldTypeTimestampOffset' || esriType === 'date' || esriType === 'date-only'

const NUMERIC_ESRI_TYPES = new Set([
    'esriFieldTypeSmallInteger', 'esriFieldTypeInteger', 'esriFieldTypeBigInteger',
    'esriFieldTypeSingle', 'esriFieldTypeDouble', 'esriFieldTypeOID',
    'small-integer', 'integer', 'big-integer', 'single', 'double', 'oid', 'long'
])

export const fieldTypeIsNumeric = (esriType: string | null | undefined): boolean =>
    esriType != null && NUMERIC_ESRI_TYPES.has(esriType)
