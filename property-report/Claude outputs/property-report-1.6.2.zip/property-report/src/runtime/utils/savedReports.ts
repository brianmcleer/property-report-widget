/**
 * Saved and recently viewed reports for the Property Report runtime. Owns the
 * localStorage persistence for two lists: reports a user deliberately saved with
 * a name, and properties recently viewed. Both store the resolved point (x, y,
 * spatial reference) so a saved report reopens exactly where it was rather than
 * being re-geocoded from text. Storage is per widget instance, validated on
 * read, and capped so a busy user cannot fill the origin's quota.
 */

export interface SavedPoint { x: number, y: number, wkid: number }

export interface SavedReport {
    id: string
    name: string
    address: string
    point: SavedPoint | null
    savedAt: string           // ISO timestamp
    headerData: Record<string, any> | null
    // Light summary for the list view: section title -> feature count.
    sectionCounts: Array<{ title: string, count: number }>
    // Optional full snapshot for offline comparison. Kept small by callers.
    snapshot?: any
}

export interface RecentReport {
    address: string
    point: SavedPoint | null
    viewedAt: string
}

const SAVED_LIMIT = 50
const RECENT_LIMIT = 12
const MAX_BYTES = 1_500_000  // stay well under typical 5 MB origin quota

const isFiniteNum = (v: any): v is number => typeof v === 'number' && isFinite(v)

export const isValidPoint = (p: any): p is SavedPoint =>
    !!p && isFiniteNum(p.x) && isFiniteNum(p.y) && isFiniteNum(p.wkid)

const safeParse = <T,>(raw: string | null, guard: (v: any) => v is T): T[] => {
    if (!raw) return []
    try {
        const v = JSON.parse(raw)
        return Array.isArray(v) ? v.filter(guard) : []
    } catch (e) {
        return []
    }
}

const isSavedReport = (v: any): v is SavedReport =>
    !!v && typeof v.id === 'string' && typeof v.name === 'string' &&
    typeof v.address === 'string' && typeof v.savedAt === 'string' &&
    (v.point === null || isValidPoint(v.point)) &&
    Array.isArray(v.sectionCounts)

const isRecent = (v: any): v is RecentReport =>
    !!v && typeof v.address === 'string' && typeof v.viewedAt === 'string' &&
    (v.point === null || isValidPoint(v.point))

const storage = (): Storage | null => {
    try { return typeof window !== 'undefined' ? window.localStorage : null } catch (e) { return null }
}

export const makeReportId = (): string => {
    try {
        if (typeof crypto !== 'undefined' && typeof (crypto as any).randomUUID === 'function') return (crypto as any).randomUUID()
    } catch (e) { /* fall through */ }
    return `r_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`
}

const write = (key: string, value: any): boolean => {
    const s = storage()
    if (!s) return false
    try {
        let json = JSON.stringify(value)
        // If the payload is too large, drop snapshots first, then oldest entries.
        if (json.length > MAX_BYTES && Array.isArray(value)) {
            const trimmed = value.map((r: any) => ({ ...r, snapshot: undefined }))
            json = JSON.stringify(trimmed)
            while (json.length > MAX_BYTES && trimmed.length > 1) {
                trimmed.pop()
                json = JSON.stringify(trimmed)
            }
        }
        s.setItem(key, json)
        return true
    } catch (e) {
        return false
    }
}

// ---- Saved reports ----

export const loadSavedReports = (key: string): SavedReport[] => {
    const s = storage()
    return s ? safeParse(s.getItem(key), isSavedReport) : []
}

export const saveReport = (key: string, report: Omit<SavedReport, 'id' | 'savedAt'> & { id?: string }): SavedReport[] => {
    const list = loadSavedReports(key)
    const entry: SavedReport = {
        ...report,
        id: report.id || makeReportId(),
        savedAt: new Date().toISOString(),
        name: (report.name || report.address || 'Saved report').trim().slice(0, 120)
    }
    // Replace an existing entry with the same id or same point+name.
    const next = [entry, ...list.filter(r => r.id !== entry.id && !(r.name === entry.name && samePoint(r.point, entry.point)))]
        .slice(0, SAVED_LIMIT)
    write(key, next)
    return next
}

export const renameSavedReport = (key: string, id: string, name: string): SavedReport[] => {
    const next = loadSavedReports(key).map(r => r.id === id ? { ...r, name: name.trim().slice(0, 120) || r.name } : r)
    write(key, next)
    return next
}

export const deleteSavedReport = (key: string, id: string): SavedReport[] => {
    const next = loadSavedReports(key).filter(r => r.id !== id)
    write(key, next)
    return next
}

export const clearSavedReports = (key: string): void => {
    const s = storage()
    try { s?.removeItem(key) } catch (e) { /* ignore */ }
}

// ---- Recently viewed ----

export const loadRecent = (key: string): RecentReport[] => {
    const s = storage()
    return s ? safeParse(s.getItem(key), isRecent) : []
}

export const pushRecent = (key: string, entry: Omit<RecentReport, 'viewedAt'>): RecentReport[] => {
    const address = (entry.address || '').trim()
    if (!address && !entry.point) return loadRecent(key)
    const list = loadRecent(key).filter(r => !(r.address === address && samePoint(r.point, entry.point)))
    const next = [{ address, point: entry.point, viewedAt: new Date().toISOString() }, ...list].slice(0, RECENT_LIMIT)
    write(key, next)
    return next
}

export const clearRecent = (key: string): void => {
    const s = storage()
    try { s?.removeItem(key) } catch (e) { /* ignore */ }
}

export const samePoint = (a: SavedPoint | null, b: SavedPoint | null): boolean => {
    if (!a || !b) return a === b
    return a.wkid === b.wkid && Math.abs(a.x - b.x) < 1e-6 && Math.abs(a.y - b.y) < 1e-6
}

// Human friendly relative time for list rows ("3 min ago", "yesterday").
export const relativeTime = (iso: string, now: Date = new Date()): string => {
    const t = new Date(iso).getTime()
    if (!isFinite(t)) return ''
    const diff = Math.max(0, now.getTime() - t)
    const m = Math.round(diff / 60000)
    if (m < 1) return 'just now'
    if (m < 60) return `${m} min ago`
    const h = Math.round(m / 60)
    if (h < 24) return `${h} hr ago`
    const d = Math.round(h / 24)
    if (d === 1) return 'yesterday'
    if (d < 30) return `${d} days ago`
    return new Date(iso).toLocaleDateString()
}
