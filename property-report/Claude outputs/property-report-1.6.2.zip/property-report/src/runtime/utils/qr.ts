/**
 * QR code generation for the Property Report runtime. Owns the single wrapper
 * around the `qrcode` package used to turn a share link into a PNG data URL for
 * the on-screen share panel and the PDF header. A printed report can then be
 * scanned to open the live, interactive version at the same property. Fails
 * soft: any error yields null and callers simply omit the code.
 */
import QRCode from 'qrcode'

export interface QrOptions {
    size?: number           // pixels, default 160
    margin?: number         // modules of quiet zone, default 1
    dark?: string           // hex, default black
    light?: string          // hex, default white
}

export const buildQrDataUrl = async (text: string, opts?: QrOptions): Promise<string | null> => {
    if (!text) return null
    try {
        return await QRCode.toDataURL(text, {
            errorCorrectionLevel: 'M',
            margin: opts?.margin ?? 1,
            width: opts?.size ?? 160,
            color: { dark: opts?.dark || '#000000', light: opts?.light || '#FFFFFF' }
        })
    } catch (e) {
        console.warn('QR code generation failed:', e)
        return null
    }
}

// Share links can get long once coordinates and open sections are appended.
// QR version 40 at level M holds about 2,300 bytes; keep a comfortable margin.
export const QR_MAX_TEXT = 1800
export const fitsInQr = (text: string): boolean => !!text && text.length <= QR_MAX_TEXT
