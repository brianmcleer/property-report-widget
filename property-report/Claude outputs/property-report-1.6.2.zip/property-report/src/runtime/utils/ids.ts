/**
 * Element id helpers for the Property Report runtime. Owns generation of the
 * unique ids used to wire ARIA relationships (aria-controls, aria-labelledby,
 * aria-describedby) between headers, bodies and status regions. useStableId is
 * a hook that keeps one id for the lifetime of a component instance without
 * relying on React.useId, so it works on the React version bundled with older
 * Experience Builder releases.
 */
import { React } from 'jimu-core'

const { useRef } = React

// Strips characters that are not valid in an HTML id / CSS selector.
const cleanSeed = (seed: string): string => String(seed).replace(/[^A-Za-z0-9_-]+/g, '-')

const randomSuffix = (): string => {
    try {
        const c: any = typeof crypto !== 'undefined' ? crypto : undefined
        if (c && typeof c.randomUUID === 'function') return c.randomUUID().slice(0, 8)
    } catch (e) { /* fall through to Math.random */ }
    return Math.random().toString(36).slice(2, 11)
}

// Builds a unique id with the given prefix, e.g. "widget-1f3a9c2b".
export const makeId = (prefix: string): string => `${prefix}-${randomSuffix()}`

// Hook: returns an id that stays the same across re-renders. When a seed is
// provided (a configured layerId or tableId) the id is derived from it so
// server and client output match; otherwise a random suffix is generated once.
export const useStableId = (prefix: string, seed?: string): string => {
    const ref = useRef<string | null>(null)
    const seedKey = seed ? cleanSeed(seed) : ''
    const wanted = seedKey ? `${prefix}-${seedKey}` : null
    if (ref.current === null || (wanted && ref.current !== wanted)) {
        ref.current = wanted ?? makeId(prefix)
    }
    return ref.current
}
