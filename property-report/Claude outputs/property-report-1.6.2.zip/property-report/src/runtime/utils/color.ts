/**
 * Color helpers for the Property Report runtime. Owns parsing of configured
 * colors (3, 6 and 8 digit hex plus rgb()/rgba() strings) into RGB triplets
 * for jsPDF, and the WCAG relative luminance and contrast math used to pick a
 * readable foreground (black or white) for a configured background color.
 */
import { theme } from '../theme/tokens'

const FALLBACK_RGB = [26, 107, 124]  // theme.sectionHeader (#1A6B7C)

const clamp255 = (n: number): number => Math.max(0, Math.min(255, Math.round(n)))

// Parses a color string into [r, g, b]. Accepts #RGB, #RRGGBB, #RRGGBBAA (alpha
// is ignored), rgb(r, g, b) and rgba(r, g, b, a). Unknown input falls back to
// the theme primary and logs a warning so bad config is visible in the console.
export const hexToRgb = (hex: string): number[] => {
    if (typeof hex === 'string') {
        const s = hex.trim()

        const short = /^#?([a-f\d])([a-f\d])([a-f\d])$/i.exec(s)
        if (short) {
            return [
                parseInt(short[1] + short[1], 16),
                parseInt(short[2] + short[2], 16),
                parseInt(short[3] + short[3], 16)
            ]
        }

        const full = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})(?:[a-f\d]{2})?$/i.exec(s)
        if (full) {
            return [
                parseInt(full[1], 16),
                parseInt(full[2], 16),
                parseInt(full[3], 16)
            ]
        }

        const rgb = /^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*[\d.]+\s*)?\)$/i.exec(s)
        if (rgb) {
            return [clamp255(Number(rgb[1])), clamp255(Number(rgb[2])), clamp255(Number(rgb[3]))]
        }
    }

    console.warn('Unrecognized color value, using theme primary instead:', hex, theme.sectionHeader)
    return [...FALLBACK_RGB]
}

// WCAG 2.1 relative luminance of an sRGB triplet (0 = black, 1 = white).
export const relativeLuminance = (rgb: number[]): number => {
    const [r, g, b] = rgb.map(c => {
        const v = clamp255(c) / 255
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)
    })
    return 0.2126 * r + 0.7152 * g + 0.0722 * b
}

// WCAG contrast ratio between two colors (1 to 21). Arguments may be RGB
// triplets or any string hexToRgb understands.
export const contrastRatio = (a: number[] | string, b: number[] | string): number => {
    const la = relativeLuminance(typeof a === 'string' ? hexToRgb(a) : a)
    const lb = relativeLuminance(typeof b === 'string' ? hexToRgb(b) : b)
    const lighter = Math.max(la, lb)
    const darker = Math.min(la, lb)
    return (lighter + 0.05) / (darker + 0.05)
}

// Chooses black or white text for the given background, whichever has the
// higher contrast ratio.
export const pickForeground = (bgHex: string): '#000000' | '#FFFFFF' => {
    const bg = hexToRgb(bgHex)
    const withBlack = contrastRatio(bg, [0, 0, 0])
    const withWhite = contrastRatio(bg, [255, 255, 255])
    return withWhite >= withBlack ? '#FFFFFF' : '#000000'
}
