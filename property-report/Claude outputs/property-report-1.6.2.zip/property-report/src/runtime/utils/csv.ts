/**
 * CSV helpers for the Property Report runtime. Owns cell escaping for the
 * per-section CSV export, including neutralization of spreadsheet formula
 * injection (cells starting with =, +, -, @, tab or carriage return get a
 * leading apostrophe and are quoted), and assembly of rows into a CRLF
 * delimited document.
 */

// Characters that make a spreadsheet treat a cell as a formula.
const FORMULA_LEAD_RE = /^[=+\-@\t\r]/

export const csvEscape = (v: any): string => {
    if (v === null || v === undefined) return ''
    let s = String(v)
    let mustQuote = /[",\n\r]/.test(s)
    if (FORMULA_LEAD_RE.test(s)) {
        s = "'" + s
        mustQuote = true
    }
    return mustQuote ? '"' + s.replace(/"/g, '""') + '"' : s
}

// Joins already-stringified cells into a CSV document. Every cell is escaped
// here, so callers pass raw strings.
export const buildCsv = (rows: string[][]): string => {
    if (!rows || rows.length === 0) return ''
    return rows.map(row => (row || []).map(cell => csvEscape(cell)).join(',')).join('\r\n')
}
