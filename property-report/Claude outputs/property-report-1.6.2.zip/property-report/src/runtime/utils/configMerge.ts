/**
 * Config normalization helpers for the Property Report runtime. Owns the
 * conversion of Experience Builder Immutable config values into plain
 * arrays and objects, the field config normalization that repairs XML-imported
 * shapes (n -> name, missing visible), and the merge of global default chart
 * and table settings with per-section overrides.
 */
import type { ChartConfig, TableDisplayConfig } from '../../config'

// Returns a plain mutable array from an Immutable list, an array, or any other
// iterable. Non-iterable input (null, a number, a plain object) yields [].
export const toMutable = <T,>(obj: any): T[] => {
    if (!obj) return []
    if (typeof obj.asMutable === 'function') {
        const out = obj.asMutable({ deep: true })
        return Array.isArray(out) ? out : []
    }
    if (Array.isArray(obj)) return [...obj]
    if (typeof obj === 'string') return []
    if (typeof obj[Symbol.iterator] === 'function') return Array.from(obj as Iterable<T>)
    return []
}

// Normalize field configs: XML import may produce 'n' instead of 'name', and
// older configs may omit 'visible'. The runtime always expects 'name' and
// treats a missing 'visible' as true.
export const normalizeFields = (fields: any[]): any[] => {
    if (!fields || !Array.isArray(fields)) return fields
    return fields.map(f => {
        if (!f || typeof f !== 'object') return f
        let out = f
        if ((f as any).n !== undefined && f.name === undefined) {
            const { n, ...rest } = f
            out = { name: n, ...rest }
        }
        if (out.visible === undefined) {
            out = { ...out, visible: true }
        }
        return out
    })
}

export const toPlainObject = <T,>(obj: any): T | undefined => {
    if (!obj) return undefined
    if (typeof obj.asMutable === 'function') return obj.asMutable({ deep: true }) as T
    if (typeof obj === 'object') return { ...obj } as T
    return obj as T
}

export const mergeChartConfig = (defaultConfig: any, sectionConfig: any, chartType: string): ChartConfig => {
    const base = toPlainObject<ChartConfig>(defaultConfig) || {}
    const section = toPlainObject<ChartConfig>(sectionConfig) || {}
    return {
        ...base,
        ...section,
        chartType: chartType as any,
        colorScheme: section.colorScheme ? toMutable<string>(section.colorScheme) :
            base.colorScheme ? toMutable<string>(base.colorScheme) : undefined
    }
}

export const mergeTableConfig = (defaultConfig: any, sectionConfig: any): TableDisplayConfig => {
    const base = toPlainObject<TableDisplayConfig>(defaultConfig) || {}
    const section = toPlainObject<TableDisplayConfig>(sectionConfig) || {}
    return {
        ...base,
        ...section,
        pageSizeOptions: section.pageSizeOptions ? toMutable<number>(section.pageSizeOptions) :
            base.pageSizeOptions ? toMutable<number>(base.pageSizeOptions) : undefined
    }
}
