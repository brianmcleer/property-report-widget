/**
 * Pointer event guards for the Property Report runtime. Owns the click
 * protection handlers that keep non-primary mouse buttons, aux clicks and
 * scroll wheel activity from triggering click actions (some Windows mice and
 * drivers fire spurious events during scrolling), plus the wrapper that applies
 * the same guard to TanStack Table sort handlers.
 */
import { React } from 'jimu-core'

// True for the primary (left) mouse button.
export const isPrimaryButton = (e: React.MouseEvent | MouseEvent): boolean => e.button === 0

// Swallow the event so no parent handler treats it as an interaction.
const suppress = (e: React.MouseEvent | React.WheelEvent): void => {
    e.preventDefault()
    e.stopPropagation()
}

// Prevent non-left-click from triggering actions
export const handleProtectedClick = (handler: () => void) => (e: React.MouseEvent) => {
    // Only respond to primary (left) mouse button
    if (!isPrimaryButton(e)) {
        suppress(e)
        return
    }
    handler()
}

// Prevent mousedown from non-primary buttons (blocks click before it fires)
export const handleProtectedMouseDown = (e: React.MouseEvent) => {
    if (!isPrimaryButton(e)) suppress(e)
}

// Prevent aux click (middle mouse button)
export const handlePreventAuxClick = (e: React.MouseEvent) => {
    suppress(e)
}

// Prevent wheel events from accidentally triggering click-like behavior
// Some Windows mice can trigger spurious events during scroll
export const handlePreventWheelClick = (e: React.WheelEvent) => {
    // Stop propagation to prevent any parent handlers from treating this as interaction
    e.stopPropagation()
}

// Wrapper for TanStack sorting handler to filter non-left clicks
export const wrapSortHandler = (handler: ((event: unknown) => void) | undefined) => {
    if (!handler) return undefined
    return (e: React.MouseEvent) => {
        if (!isPrimaryButton(e)) {
            suppress(e)
            return
        }
        handler(e)
    }
}
