/**
 * HTML helpers for the Property Report runtime. Owns conversion of rich-text
 * HTML to plain text for PDF output, HTML escaping for values interpolated
 * into markup, and HTML sanitization (DOMPurify with a conservative profile)
 * for configured rich text before it is rendered with dangerouslySetInnerHTML.
 */
import DOMPurify from 'dompurify'

// Convert rich-text HTML to plain text for PDF output using an inert DOMParser
// pass. This strips tags and decodes entities correctly in one step and avoids
// the incomplete-sanitization and double-escaping patterns CodeQL flags.
// Block-level elements (p, div, li, headings, table rows) end with a line break
// so list items and paragraphs do not run together in the PDF.
export const htmlToPlainText = (html: string): string => {
    if (!html) return ''
    const doc = new DOMParser().parseFromString(html, 'text/html')
    doc.body.querySelectorAll('br').forEach(br => br.replaceWith(' '))
    doc.body.querySelectorAll('p, div, li, h1, h2, h3, h4, h5, h6, tr').forEach(el => el.insertAdjacentText('beforeend', '\n'))
    return (doc.body.textContent || '')
        .replace(/\u00a0/g, ' ')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
}

// Escape the five characters that matter when inserting a value into HTML.
export const escapeHtml = (s: any): string => {
    if (s == null) return ''
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
}

// Sanitization profile: common inline and block formatting plus links, lists,
// tables and images. Scripts, styles, frames, embeds and forms are forbidden.
const SANITIZE_CONFIG = {
    ALLOWED_TAGS: [
        'a', 'abbr', 'b', 'blockquote', 'br', 'caption', 'code', 'dd', 'del', 'div', 'dl', 'dt',
        'em', 'figcaption', 'figure', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'hr', 'i', 'img', 'ins',
        'kbd', 'li', 'mark', 'ol', 'p', 'pre', 'q', 's', 'small', 'span', 'strike', 'strong', 'sub',
        'sup', 'table', 'tbody', 'td', 'tfoot', 'th', 'thead', 'tr', 'u', 'ul'
    ],
    ALLOWED_ATTR: [
        'href', 'title', 'target', 'rel', 'alt', 'src', 'width', 'height', 'class', 'style',
        'id', 'lang', 'dir', 'colspan', 'rowspan', 'scope', 'start', 'type', 'aria-label',
        'aria-hidden', 'aria-describedby', 'role'
    ],
    FORBID_TAGS: ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'textarea', 'select', 'link', 'meta', 'base'],
    FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover', 'formaction', 'srcdoc'],
    ADD_ATTR: ['target'],
    ALLOW_DATA_ATTR: false
}

let hookInstalled = false
const installHooks = (): void => {
    if (hookInstalled) return
    hookInstalled = true
    if (typeof (DOMPurify as any).addHook !== 'function') return
    // Force rel="noopener noreferrer" on any link that opens a new tab so the
    // opened page cannot reach back to window.opener.
    DOMPurify.addHook('afterSanitizeAttributes', (node: Element) => {
        if (node.tagName === 'A' && node.getAttribute('target') === '_blank') {
            node.setAttribute('rel', 'noopener noreferrer')
        }
    })
}

// Sanitize configured rich-text HTML with a conservative profile. Returns an
// empty string for empty input or when DOMPurify is unavailable (no DOM).
export const sanitizeHtml = (html: string): string => {
    if (!html) return ''
    if (!DOMPurify || typeof DOMPurify.sanitize !== 'function') return ''
    installHooks()
    return String(DOMPurify.sanitize(html, SANITIZE_CONFIG as any))
}
