/**
 * Report export builders for the Property Report runtime. Owns the pure
 * transformations from query results into plain text, JSON and a mailto URL, so
 * copy, email and download share one representation and can be unit tested
 * without React. The input shape mirrors the widget's SectionResult loosely to
 * avoid a circular import.
 */

export interface ExportLayer {
    layerConfig: { layerTitle?: string, layerId?: string, fields?: Array<{ name: string, alias?: string }> | any }
    features: Array<Record<string, any>>
}
export interface ExportSection {
    sectionConfig: { sectionId: string, sectionTitle?: string }
    totalFeatures: number
    layerResults: ExportLayer[]
}
export interface ExportInput {
    address: string
    coordinates?: string
    generatedAt?: Date
    headerData?: Record<string, any> | null
    sections: ExportSection[]
    shareUrl?: string
    organization?: string
}

const toArray = (v: any): any[] => {
    if (!v) return []
    if (Array.isArray(v)) return v
    if (typeof v.asMutable === 'function') return v.asMutable({ deep: true })
    try { return Array.from(v) } catch (e) { return [] }
}

const columnsFor = (lr: ExportLayer): Array<{ name: string, label: string }> => {
    const configured = toArray(lr.layerConfig.fields).map((f: any) => ({ name: f.name, label: f.alias || f.name }))
    if (configured.length) return configured
    const first = lr.features[0] || {}
    return Object.keys(first).filter(k => k !== '__geometry').map(k => ({ name: k, label: k }))
}

const clean = (v: any): string => {
    if (v == null) return ''
    if (typeof v === 'object') { try { return JSON.stringify(v) } catch (e) { return String(v) } }
    return String(v)
}

export const buildReportText = (input: ExportInput): string => {
    const lines: string[] = []
    const when = input.generatedAt || new Date()
    lines.push(input.address || 'Property Report')
    if (input.coordinates) lines.push(input.coordinates)
    lines.push(`Generated ${when.toLocaleString()}${input.organization ? ` by ${input.organization}` : ''}`)
    if (input.shareUrl) lines.push(`Live report: ${input.shareUrl}`)
    lines.push('')

    if (input.headerData) {
        for (const [k, v] of Object.entries(input.headerData)) {
            if (v != null && k !== '__geometry') lines.push(`${k}: ${clean(v)}`)
        }
        lines.push('')
    }

    for (const sr of input.sections) {
        lines.push((sr.sectionConfig.sectionTitle || 'Section').toUpperCase())
        if (sr.totalFeatures === 0) {
            lines.push('  No features found at this location')
            lines.push('')
            continue
        }
        for (const lr of sr.layerResults) {
            const feats = lr.features || []
            if (!feats.length) continue
            if (lr.layerConfig.layerTitle) lines.push(`  ${lr.layerConfig.layerTitle}`)
            const cols = columnsFor(lr)
            feats.forEach((f, i) => {
                if (feats.length > 1) lines.push(`    Record ${i + 1}`)
                for (const c of cols) {
                    if (f[c.name] == null) continue
                    lines.push(`    ${c.label}: ${clean(f[c.name])}`)
                }
            })
        }
        lines.push('')
    }
    return lines.join('\n').replace(/\n{3,}/g, '\n\n').trimEnd() + '\n'
}

export const buildReportJson = (input: ExportInput): Record<string, any> => {
    const when = input.generatedAt || new Date()
    return {
        schema: 'property-report/1',
        generatedAt: when.toISOString(),
        organization: input.organization || undefined,
        shareUrl: input.shareUrl || undefined,
        property: {
            address: input.address || null,
            coordinates: input.coordinates || null,
            attributes: input.headerData
                ? Object.fromEntries(Object.entries(input.headerData).filter(([k]) => k !== '__geometry'))
                : null
        },
        sections: input.sections.map(sr => ({
            id: sr.sectionConfig.sectionId,
            title: sr.sectionConfig.sectionTitle || null,
            featureCount: sr.totalFeatures,
            layers: sr.layerResults.map(lr => {
                const cols = columnsFor(lr)
                return {
                    id: lr.layerConfig.layerId || null,
                    title: lr.layerConfig.layerTitle || null,
                    featureCount: lr.features?.length || 0,
                    fields: cols,
                    records: (lr.features || []).map(f =>
                        Object.fromEntries(cols.map(c => [c.name, f[c.name] === undefined ? null : f[c.name]]))
                    )
                }
            })
        }))
    }
}

// mailto: has practical length limits (roughly 2,000 characters is safe across
// clients). Long reports get a truncated body with a pointer to the live link.
export const buildMailto = (input: ExportInput, opts?: { to?: string, maxBodyChars?: number }): string => {
    const max = opts?.maxBodyChars ?? 1800
    const subject = `Property Report: ${input.address || 'property'}`
    let body = buildReportText(input)
    if (body.length > max) {
        const tail = input.shareUrl ? `\n\n[Report truncated. Open the live report: ${input.shareUrl}]` : '\n\n[Report truncated]'
        body = body.slice(0, Math.max(0, max - tail.length)) + tail
    }
    const to = opts?.to ? encodeURIComponent(opts.to) : ''
    return `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
}
