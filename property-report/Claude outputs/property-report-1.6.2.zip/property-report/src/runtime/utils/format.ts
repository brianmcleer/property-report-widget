/**
 * Field value formatting for the Property Report runtime. Owns the rules that
 * turn raw attribute values into display strings: number formats (grouping,
 * decimals, currency, percent), date formats (including ArcGIS epoch
 * millisecond dates and date-only ISO strings), text casing, prefix and suffix,
 * and coded-value domain resolution. All locale-aware output uses LOCALE so the
 * widget and the PDF render identically regardless of the browser language.
 */
import type { FieldConfig } from '../../config'
import type { DomainLookup } from '../types'

export const LOCALE = 'en-US'

// Placeholder shown for null, undefined and empty values (an em dash, written
// as an escape so the source file stays ASCII).
export const EMPTY_PLACEHOLDER = '\u2014'

export interface FieldMeta {
    esriType?: string   // ArcGIS field type, e.g. 'esriFieldTypeDate'
}

// Date-only ISO strings such as 2024-03-15. These are parsed as local dates;
// new Date('2024-03-15') would treat them as UTC midnight and shift the day in
// western time zones.
const DATE_ONLY_RE = /^(\d{4})-(\d{2})-(\d{2})$/

// Anything at or above this is treated as epoch milliseconds when the format
// type is auto (1e11 ms is roughly March 1973; real attribute numbers this
// large are rare, while every current date is far above it).
const EPOCH_MS_MIN = 1e11

const isEmptyValue = (val: any): boolean => {
    if (val == null) return true
    if (typeof val === 'string' && val.trim() === '') return true
    return false
}

const toDate = (val: any): Date => {
    if (val instanceof Date) return val
    if (typeof val === 'number') return new Date(val)
    if (typeof val === 'string') {
        const m = DATE_ONLY_RE.exec(val.trim())
        if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]))
        return new Date(val)
    }
    return new Date(val)
}

export const formatFieldValue = (val: any, fieldConfig?: FieldConfig, fieldMeta?: FieldMeta): string => {
    if (isEmptyValue(val)) return EMPTY_PLACEHOLDER

    const format = fieldConfig?.format
    let result: string

    const prefix = format?.prefix || ''
    const suffix = format?.suffix || ''
    const formatType = format?.type || 'auto'

    const isDateField = fieldMeta?.esriType === 'esriFieldTypeDate'
    const looksLikeEpochMs = typeof val === 'number' && Number.isFinite(val) && Math.abs(val) >= EPOCH_MS_MIN
    const looksLikeDateString = typeof val === 'string' && /^\d{4}-\d{2}-\d{2}/.test(val)
    const useDateBranch = formatType === 'date' ||
        (formatType === 'auto' && (isDateField || looksLikeEpochMs || val instanceof Date || looksLikeDateString))

    if (useDateBranch) {
        const date = toDate(val)
        if (isNaN(date.getTime())) {
            result = String(val)
        } else {
            const dateFormat = format?.dateFormat || 'default'
            switch (dateFormat) {
                case 'short':
                    result = date.toLocaleDateString(LOCALE, { year: '2-digit', month: 'numeric', day: 'numeric' })
                    break
                case 'medium':
                    result = date.toLocaleDateString(LOCALE, { year: 'numeric', month: 'short', day: 'numeric' })
                    break
                case 'long':
                    result = date.toLocaleDateString(LOCALE, { year: 'numeric', month: 'long', day: 'numeric' })
                    break
                case 'year-only':
                    result = String(date.getFullYear())
                    break
                default:
                    result = date.toLocaleDateString(LOCALE)
            }
        }
    } else if (formatType === 'number' || (formatType === 'auto' && typeof val === 'number')) {
        const num = typeof val === 'number' ? val : parseFloat(val)
        if (isNaN(num)) {
            result = String(val)
        } else {
            const numberFormat = format?.numberFormat || 'default'
            const useGrouping = format?.useGrouping !== false
            const decimalPlaces = format?.decimalPlaces

            switch (numberFormat) {
                case 'none':
                    result = decimalPlaces !== undefined
                        ? num.toFixed(decimalPlaces)
                        : String(num)
                    break
                case 'currency':
                    result = new Intl.NumberFormat(LOCALE, {
                        style: 'currency',
                        currency: 'USD',
                        minimumFractionDigits: decimalPlaces ?? 2,
                        maximumFractionDigits: decimalPlaces ?? 2,
                        useGrouping
                    }).format(num)
                    break
                case 'percent':
                    result = num.toLocaleString(LOCALE, {
                        minimumFractionDigits: decimalPlaces ?? 0,
                        maximumFractionDigits: decimalPlaces ?? 2,
                        useGrouping
                    }) + '%'
                    break
                case 'decimal':
                    result = num.toLocaleString(LOCALE, {
                        minimumFractionDigits: decimalPlaces ?? 2,
                        maximumFractionDigits: decimalPlaces ?? 2,
                        useGrouping
                    })
                    break
                default:
                    result = useGrouping ? num.toLocaleString(LOCALE) : String(num)
            }
        }
    } else if (formatType === 'text' || formatType === 'auto') {
        result = String(val)
        const textFormat = format?.textFormat || 'default'
        switch (textFormat) {
            case 'uppercase':
                result = result.toUpperCase()
                break
            case 'lowercase':
                result = result.toLowerCase()
                break
            case 'titlecase':
                result = result.replace(/\w\S*/g, txt => txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase())
                break
        }
    } else {
        result = String(val)
    }

    return prefix + result + suffix
}

/**
 * Resolves a field value using domain lookup.
 * If the field has a coded value domain, returns the description.
 * Otherwise returns the original value.
 */
export const resolveDomainValue = (
    fieldName: string,
    value: any,
    domainLookup?: DomainLookup
): any => {
    if (value == null || value === '' || !domainLookup) {
        return value
    }

    const fieldDomain = domainLookup[fieldName]
    if (fieldDomain) {
        // Try direct lookup
        if (fieldDomain[value] !== undefined) {
            return fieldDomain[value]
        }
        // Try string conversion for numeric codes
        if (typeof value === 'number' && fieldDomain[String(value)] !== undefined) {
            return fieldDomain[String(value)]
        }
    }

    return value
}

/**
 * Formats a field value, applying domain lookup first if available.
 * This is a wrapper around formatFieldValue that resolves coded domains.
 */
export const formatFieldValueWithDomain = (
    val: any,
    fieldConfig?: FieldConfig,
    domainLookup?: DomainLookup,
    fieldMeta?: FieldMeta
): string => {
    const fieldName = fieldConfig?.name || ''
    const resolvedValue = resolveDomainValue(fieldName, val, domainLookup)
    return formatFieldValue(resolvedValue, fieldConfig, fieldMeta)
}
