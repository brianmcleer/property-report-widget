/**
 * Placeholder resolution for the Property Report runtime. Owns the {FIELD}
 * token syntax used in rich text, buttons, URL templates, summaries and alt
 * text. Tokens are looked up across an ordered list of attribute sources
 * (first non-null value wins), doubled braces are literal braces, values can
 * be HTML-escaped for markup contexts, and unresolved tokens either stay
 * literal or become a caller-supplied fallback.
 */
import { escapeHtml } from './html'

export interface PlaceholderOptions {
    escape?: boolean    // HTML-escape resolved values (use when output goes into markup)
    trim?: boolean      // Trim the resolved string value
    fallback?: string   // Replacement for unresolved placeholders (default: leave literal)
}

export type PlaceholderSource = Record<string, any> | null | undefined

// Matches "{{", "}}", or "{NAME}" where NAME contains no braces.
const TOKEN_RE = /\{\{|\}\}|\{([^{}]+)\}/g

const lookup = (name: string, sources: PlaceholderSource[]): any => {
    for (const src of sources) {
        if (!src || typeof src !== 'object') continue
        const v = (src as any)[name]
        if (v != null) return v
    }
    return undefined
}

export const resolvePlaceholders = (
    text: string,
    sources: PlaceholderSource[],
    opts?: PlaceholderOptions
): string => {
    if (!text) return ''
    const list = Array.isArray(sources) ? sources : []
    return String(text).replace(TOKEN_RE, (match: string, name: string | undefined) => {
        if (match === '{{') return '{'
        if (match === '}}') return '}'
        const key = (name || '').trim()
        const value = lookup(key, list)
        if (value == null) {
            return opts?.fallback !== undefined ? opts.fallback : match
        }
        let out = String(value)
        if (opts?.trim) out = out.trim()
        return opts?.escape ? escapeHtml(out) : out
    })
}

// True when at least one {FIELD} token cannot be filled from the sources.
// A fallback option does not make a token count as resolved; the check is
// about whether data exists for it.
export const hasUnresolvedPlaceholders = (
    text: string,
    sources: PlaceholderSource[],
    opts?: PlaceholderOptions
): boolean => {
    void opts
    return countPlaceholders(text, sources).unresolved > 0
}

// Counts {FIELD} tokens in a template. With no sources every token is unresolved.
export const countPlaceholders = (
    text: string,
    sources?: PlaceholderSource[]
): { total: number; unresolved: number } => {
    let total = 0
    let unresolved = 0
    if (!text) return { total, unresolved }
    const list = Array.isArray(sources) ? sources : []
    String(text).replace(TOKEN_RE, (match: string, name: string | undefined) => {
        if (match === '{{' || match === '}}') return match
        total++
        if (lookup((name || '').trim(), list) == null) unresolved++
        return match
    })
    return { total, unresolved }
}
