/**
 * Recent searches hook for the Property Report runtime. Owns the small list of
 * previous search strings kept in this browser's localStorage: validated
 * loading (the stored value must be a JSON array of strings, anything else is
 * ignored), case-insensitive de-duplication, a cap of 8 entries, and clearing.
 * Storage errors (private mode, quota, disabled storage) are swallowed so the
 * widget keeps working without persistence.
 */
import { React } from 'jimu-core'

const { useState, useCallback } = React

const MAX_RECENT = 8

// Parses the stored value and returns only a clean string array.
const readStored = (storageKey: string): string[] => {
    try {
        const raw = localStorage.getItem(storageKey)
        if (!raw) return []
        const parsed = JSON.parse(raw)
        if (!Array.isArray(parsed)) return []
        return parsed.filter((x): x is string => typeof x === 'string' && x.trim() !== '').slice(0, MAX_RECENT)
    } catch (e) {
        return []
    }
}

export const useRecentSearches = (storageKey: string): { recent: string[]; save: (text: string) => void; clear: () => void } => {
    const [recent, setRecent] = useState<string[]>(() => readStored(storageKey))

    const save = useCallback((text: string) => {
        const t = (text || '').trim()
        if (!t) return
        setRecent(prev => {
            const list = [t, ...prev.filter(x => x.toLowerCase() !== t.toLowerCase())].slice(0, MAX_RECENT)
            try { localStorage.setItem(storageKey, JSON.stringify(list)) } catch (e) { /* storage unavailable */ }
            return list
        })
    }, [storageKey])

    const clear = useCallback(() => {
        try { localStorage.removeItem(storageKey) } catch (e) { /* ignore */ }
        setRecent([])
    }, [storageKey])

    return { recent, save, clear }
}
