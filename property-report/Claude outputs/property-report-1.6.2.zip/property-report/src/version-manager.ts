/**
 * Config version manager for the Property Report widget. Owns the upgrade
 * steps Experience Builder runs when an app saved with an older widget version
 * is opened. Version 1.3.0 collapses legacy duplicate keys into their current
 * homes: pdfHeader.logoBase64 -> pdfHeader.logo.base64, section.chartField ->
 * section.chartConfig.categoryField, and pdfStyle.showTableSummaries ->
 * pdfAccessibility.includeTableSummaries. Upgraders are defensive because the
 * incoming config may be an Immutable object or a plain object.
 */
import { BaseVersionManager, Immutable } from 'jimu-core'

// Converts an Immutable config (or a plain one) into a deep mutable copy.
const toMutableConfig = (cfg: any): any => {
    if (!cfg) return {}
    if (typeof cfg.asMutable === 'function') return cfg.asMutable({ deep: true })
    try {
        return JSON.parse(JSON.stringify(cfg))
    } catch (e) {
        return { ...cfg }
    }
}

// Wraps a plain config back into an Immutable when jimu-core provides it.
const toImmutableConfig = (cfg: any): any => {
    try {
        if (typeof Immutable === 'function') return (Immutable as any)(cfg)
    } catch (e) { /* fall through */ }
    return cfg
}

const isObject = (v: any): boolean => v != null && typeof v === 'object' && !Array.isArray(v)

export const upgradeTo130 = (oldConfig: any): any => {
    const cfg = toMutableConfig(oldConfig)

    // pdfHeader.logoBase64 -> pdfHeader.logo.base64
    if (isObject(cfg.pdfHeader) && cfg.pdfHeader.logoBase64 !== undefined) {
        if (!isObject(cfg.pdfHeader.logo)) cfg.pdfHeader.logo = {}
        if (cfg.pdfHeader.logo.base64 == null || cfg.pdfHeader.logo.base64 === '') {
            cfg.pdfHeader.logo.base64 = cfg.pdfHeader.logoBase64
            if (cfg.pdfHeader.logo.fileName == null && cfg.pdfHeader.logoFileName != null) {
                cfg.pdfHeader.logo.fileName = cfg.pdfHeader.logoFileName
            }
        }
        delete cfg.pdfHeader.logoBase64
    }

    // section.chartField -> section.chartConfig.categoryField
    if (Array.isArray(cfg.sections)) {
        cfg.sections = cfg.sections.map((section: any) => {
            if (!isObject(section) || section.chartField === undefined) return section
            const next = { ...section }
            if (next.chartField) {
                const chartConfig = isObject(next.chartConfig) ? { ...next.chartConfig } : {}
                if (chartConfig.categoryField == null || chartConfig.categoryField === '') {
                    chartConfig.categoryField = next.chartField
                }
                next.chartConfig = chartConfig
            }
            delete next.chartField
            return next
        })
    }

    // pdfStyle.showTableSummaries -> pdfAccessibility.includeTableSummaries
    if (isObject(cfg.pdfStyle) && cfg.pdfStyle.showTableSummaries !== undefined) {
        if (!isObject(cfg.pdfAccessibility)) cfg.pdfAccessibility = {}
        if (cfg.pdfAccessibility.includeTableSummaries === undefined) {
            cfg.pdfAccessibility.includeTableSummaries = cfg.pdfStyle.showTableSummaries
        }
    }

    return toImmutableConfig(cfg)
}

export class VersionManager extends BaseVersionManager {
    versions = [
        {
            version: '1.3.0',
            description: 'Collapse legacy duplicate keys',
            upgrader: (oldConfig: any) => upgradeTo130(oldConfig)
        },
        {
            version: '1.4.0',
            description: 'Add PDF page size and chart alt text defaults',
            upgrader: (oldConfig: any) => {
                const cfg = toMutableConfig(oldConfig)
                // New optional keys. Defaults match previous behaviour so an
                // upgraded app renders identically until someone changes them.
                if (isObject(cfg.pdfStyle)) {
                    if (cfg.pdfStyle.pageSize === undefined) cfg.pdfStyle.pageSize = 'letter'
                    if (cfg.pdfStyle.pageOrientation === undefined) cfg.pdfStyle.pageOrientation = 'portrait'
                }
                if (isObject(cfg.pdfAccessibility) && cfg.pdfAccessibility.includeChartAltText === undefined) {
                    cfg.pdfAccessibility.includeChartAltText = true
                }
                return toImmutableConfig(cfg)
            }
        },
        {
            version: '1.5.0',
            description: 'Retire the PDF table of contents; default QR code on',
            upgrader: (oldConfig: any) => {
                const cfg = toMutableConfig(oldConfig)
                if (isObject(cfg.pdfStyle)) {
                    // The TOC feature was removed; make sure no stale flag survives.
                    delete cfg.pdfStyle.enableTableOfContents
                    if (cfg.pdfStyle.includeQrCode === undefined) cfg.pdfStyle.includeQrCode = true
                }
                return toImmutableConfig(cfg)
            }
        }
    ]
}

// Experience Builder imports the instance, not the class. Export both plus a
// default so the framework resolves it regardless of which convention it uses.
export const versionManager = new VersionManager()

export default versionManager
