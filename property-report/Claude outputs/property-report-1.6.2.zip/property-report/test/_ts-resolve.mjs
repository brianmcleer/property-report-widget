// Node ESM needs file extensions; the widget sources import '../theme/tokens'
// the webpack way. This hook appends .ts/.tsx (or /index.ts) for relative
// specifiers so the suites can load real source files unchanged.
// Usage: node --import ./test/_ts-resolve.mjs --experimental-strip-types test/x.test.mjs
import { register } from 'node:module'
import { existsSync } from 'node:fs'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { dirname, resolve as pathResolve } from 'node:path'

register(pathToFileURL(fileURLToPath(import.meta.url)), { data: null })

export async function resolve(specifier, context, next) {
    if (specifier.startsWith('.') && !/\.[a-z]+$/i.test(specifier) && context.parentURL?.startsWith('file:')) {
        const base = pathResolve(dirname(fileURLToPath(context.parentURL)), specifier)
        for (const cand of [base + '.ts', base + '.tsx', base + '/index.ts']) {
            if (existsSync(cand)) return next(pathToFileURL(cand).href, context)
        }
    }
    return next(specifier, context)
}
