// Unit tests for the 1.5.0 feature modules: find-in-report, saved reports,
// export builders, and keyboard shortcuts.
import { JSDOM } from 'jsdom'
const dom = new JSDOM('<!doctype html><html><body></body></html>', { url: 'https://maps.gjcity.org/app/' })
globalThis.window = dom.window
globalThis.document = dom.window.document
Object.defineProperty(globalThis, 'localStorage', { value: dom.window.localStorage, configurable: true })

const F = await import('../src/runtime/utils/reportFilter.ts')
const S = await import('../src/runtime/utils/savedReports.ts')
const E = await import('../src/runtime/utils/reportExport.ts')
const K = await import('../src/runtime/utils/shortcuts.ts')

let pass = 0, fail = 0
const check = (n, c, d = '') => { if (c) pass++; else fail++; console.log((c ? '  PASS  ' : '  FAIL  ') + n + (c ? '' : '   ' + d)) }

console.log('\n--- find in report ---')
const rec = { OWNER: 'Maria Núñez-Smith', ZONE: 'R-4', YEAR: 2024, __geometry: { x: 1 } }
check('empty filter matches everything', F.recordMatches(rec, F.parseFilter('')))
check('case-insensitive', F.recordMatches(rec, F.parseFilter('maria')))
check('accent-insensitive', F.recordMatches(rec, F.parseFilter('nunez')))
check('all terms required (AND)', F.recordMatches(rec, F.parseFilter('smith 2024')) && !F.recordMatches(rec, F.parseFilter('smith 1999')))
check('numbers searchable', F.recordMatches(rec, F.parseFilter('2024')))
check('geometry not searched', !F.recordMatches({ __geometry: { x: 'target' } }, F.parseFilter('target')))
const summary = F.summarizeMatches([
  { sectionConfig: { sectionId: 'a' }, layerResults: [{ layerConfig: { layerId: 'l1' }, features: [rec, { OWNER: 'Bob' }] }] },
  { sectionConfig: { sectionId: 'b' }, layerResults: [{ layerConfig: { layerId: 'l2' }, features: [{ OWNER: 'Zed' }] }] }
], F.parseFilter('smith'))
check('per-section match counts', summary[0].matched === 1 && summary[0].total === 2 && summary[1].matched === 0, JSON.stringify(summary))
const segs = F.highlightSegments('Maria Núñez-Smith', F.parseFilter('nunez'))
check('highlight spans the accented original text', segs.some(s => s.match && s.text === 'Núñez'), JSON.stringify(segs))
check('segments reassemble to original', segs.map(s => s.text).join('') === 'Maria Núñez-Smith')
check('highlight with no filter returns single plain segment', F.highlightSegments('abc', F.parseFilter('')).length === 1)

console.log('\n--- saved reports ---')
const KEY = 'test-saved'
S.clearSavedReports(KEY)
let list = S.saveReport(KEY, { name: 'Fire station parcel', address: '625 Ute Ave', point: { x: -108.56, y: 39.07, wkid: 4326 }, headerData: { PARCEL: '2945-101-00-001' }, sectionCounts: [{ title: 'Zoning', count: 1 }] })
check('save returns list with entry', list.length === 1 && list[0].name === 'Fire station parcel')
check('round-trips through storage', S.loadSavedReports(KEY)[0].point.wkid === 4326)
list = S.saveReport(KEY, { name: 'Fire station parcel', address: '625 Ute Ave', point: { x: -108.56, y: 39.07, wkid: 4326 }, headerData: null, sectionCounts: [] })
check('same name + point replaces rather than duplicates', list.length === 1)
list = S.renameSavedReport(KEY, list[0].id, 'Station 1')
check('rename', list[0].name === 'Station 1')
list = S.deleteSavedReport(KEY, list[0].id)
check('delete', list.length === 0)
localStorage.setItem(KEY, JSON.stringify([{ bogus: true }, 'x', { id: 'ok', name: 'n', address: 'a', savedAt: new Date().toISOString(), point: null, sectionCounts: [] }]))
check('invalid entries dropped on read', S.loadSavedReports(KEY).length === 1)
localStorage.setItem(KEY, '{not json')
check('corrupt storage yields []', S.loadSavedReports(KEY).length === 0)
const RKEY = 'test-recent'
S.clearRecent(RKEY)
for (let i = 0; i < 20; i++) S.pushRecent(RKEY, { address: `${i} Main St`, point: null })
check('recent list capped', S.loadRecent(RKEY).length <= 12)
S.pushRecent(RKEY, { address: '5 Main St', point: null })
check('re-view moves to top without duplicate', S.loadRecent(RKEY)[0].address === '5 Main St' && S.loadRecent(RKEY).filter(r => r.address === '5 Main St').length === 1)
check('relativeTime', S.relativeTime(new Date(Date.now() - 5 * 60000).toISOString()) === '5 min ago')

console.log('\n--- exports ---')
const input = {
  address: '625 Ute Ave', coordinates: '39.07, -108.56', generatedAt: new Date('2026-09-03T12:00:00Z'),
  headerData: { PARCEL: '2945-101-00-001', __geometry: {} },
  sections: [
    { sectionConfig: { sectionId: 'z', sectionTitle: 'Zoning' }, totalFeatures: 1, layerResults: [{ layerConfig: { layerTitle: 'Zone Districts', layerId: 'zd', fields: [{ name: 'ZONE', alias: 'Zone' }] }, features: [{ ZONE: 'R-4', EXTRA: 'hidden' }] }] },
    { sectionConfig: { sectionId: 'f', sectionTitle: 'Flood' }, totalFeatures: 0, layerResults: [] }
  ],
  shareUrl: 'https://maps.gjcity.org/app/?propertysearch=625%20Ute', organization: 'City of Grand Junction'
}
const txt = E.buildReportText(input)
check('text has address, section, aliased field', /625 Ute Ave/.test(txt) && /ZONING/.test(txt) && /Zone: R-4/.test(txt))
check('text respects configured field list', !/EXTRA/.test(txt))
check('text notes empty section', /No features found/.test(txt))
check('text excludes geometry', !/__geometry/.test(txt))
const json = E.buildReportJson(input)
check('json schema and shape', json.schema === 'property-report/1' && json.sections[0].layers[0].records[0].ZONE === 'R-4')
check('json excludes geometry from attributes', !('__geometry' in json.property.attributes))
const mailto = E.buildMailto({ ...input, sections: Array.from({ length: 120 }, (_, i) => input.sections[0]) })
check('mailto scheme and subject', mailto.startsWith('mailto:?subject=') && decodeURIComponent(mailto).includes('Property Report: 625 Ute Ave'))
check('mailto body truncated with live link pointer', decodeURIComponent(mailto).includes('Report truncated') && decodeURIComponent(mailto).length < 2600)

console.log('\n--- shortcuts ---')
const el = (tag, role) => ({ tagName: tag, isContentEditable: false, getAttribute: (n) => n === 'role' ? role : null })
check('/ focuses search', K.matchShortcut({ key: '/', target: el('DIV') }) === 'focusSearch')
check('ignored while typing in input', K.matchShortcut({ key: 'p', target: el('INPUT') }) === null)
check('ignored in role=combobox', K.matchShortcut({ key: 'p', target: el('DIV', 'combobox') }) === null)
check('Escape works even while typing', K.matchShortcut({ key: 'Escape', target: el('INPUT') }) === 'escape')
check('modifier keys ignored (browser shortcuts untouched)', K.matchShortcut({ key: 'p', ctrlKey: true, target: el('DIV') }) === null)
check('uppercase matches', K.matchShortcut({ key: 'P', target: el('DIV') }) === 'print')
check('? opens help', K.matchShortcut({ key: '?', target: el('DIV') }) === 'help')
check('unknown key is null', K.matchShortcut({ key: 'z', target: el('DIV') }) === null)

console.log(`\n===== ${pass} passed, ${fail} failed =====`)
process.exit(fail ? 1 : 0)
