# Verification tests

These are the checks used to prove the fixes in versions 1.3.0 and 1.4.0. They are
development-only and are excluded from the shipped widget by `.npmignore`.

They run on plain Node with jsdom and do not need an Experience Builder install:

```
npm install --no-save jsdom react react-dom
node --experimental-strip-types test/security.test.mjs
node --import ./test/_ts-resolve.mjs --experimental-strip-types test/chartdata.test.mjs
node test/remount.test.mjs
```

| File | What it proves |
| --- | --- |
| `security.test.mjs` | 57 assertions. Ten XSS payloads substituted into rich text produce no dangerous element or attribute in a real DOM, and still display as literal text. Also covers the href scheme allow-list, CSV formula injection and SQL literal escaping. |
| `remount.test.mjs` | Reproduces the original bug with real React: a component declared inside render loses child table state on a keystroke and mounts twice. The render-function form keeps state and mounts once. |
| `features.test.mjs` | 36 assertions across find-in-report (case and accent insensitive AND matching, per-section counts, highlight segmentation), saved and recent reports (validation, caps, dedupe, corrupt storage), text/JSON/mailto export builders, and keyboard shortcut matching. |
| `chartdata.test.mjs` | Chart aggregation honours categoryField, valueField, count/sum/avg/min/max, sorting and maxCategories, and never emits raw attribute keys as chart series. |

The XSS assertions are deliberately DOM-based. Escaped entities legitimately
contain strings like `onerror=` as inert text, so a substring check on the
serialized HTML reports false failures. What matters is whether the browser
builds a dangerous node or attribute.
