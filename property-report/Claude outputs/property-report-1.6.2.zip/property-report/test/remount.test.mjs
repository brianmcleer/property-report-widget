// Demonstrates the bug class fixed in widget.tsx: a component DECLARED INSIDE
// render is a new component type every pass, so React unmounts and remounts its
// subtree, destroying child state. Calling a render FUNCTION instead inlines the
// elements and reconciliation preserves child identity and state.
import { JSDOM } from 'jsdom'
const dom = new JSDOM('<!doctype html><html><body><div id="a"></div><div id="b"></div></body></html>', { url: 'http://localhost/', pretendToBeVisual: true })
globalThis.window = dom.window; globalThis.document = dom.window.document
globalThis.HTMLElement = dom.window.HTMLElement
globalThis.IS_REACT_ACT_ENVIRONMENT = true

const React = (await import('react')).default
const { createRoot } = await import('react-dom/client')
const { act } = await import('react')
const h = React.createElement

let mounts = 0
// Stands in for LayerDataSection: owns sort/filter/page state.
function TableWithState () {
  const [sort, setSort] = React.useState('none')
  React.useEffect(() => { mounts++ }, [])
  return h('div', null,
    h('button', { id: 'sortbtn', onClick: () => setSort('OWNER asc') }, 'sort'),
    h('span', { id: 'sortval' }, sort))
}

// BEFORE: component declared inside render (the original widget.tsx pattern).
function ParentInline () {
  const [text, setText] = React.useState('')
  const DataContent = () => h(TableWithState)          // new type every render
  return h('div', null,
    h('input', { id: 'search', value: text, onChange: e => setText(e.target.value) }),
    h(DataContent))
}

// AFTER: render function called, not used as a component type.
function ParentFn () {
  const [text, setText] = React.useState('')
  const renderDataContent = () => h(TableWithState)    // plain call
  return h('div', null,
    h('input', { id: 'search', value: text, onChange: e => setText(e.target.value) }),
    renderDataContent())
}

const run = async (Comp, hostId) => {
  mounts = 0
  const root = createRoot(document.getElementById(hostId))
  await act(async () => { root.render(h(Comp)) })
  const host = document.getElementById(hostId)
  // user sorts a column
  await act(async () => { host.querySelector('#sortbtn').dispatchEvent(new dom.window.MouseEvent('click', { bubbles: true })) })
  const afterSort = host.querySelector('#sortval').textContent
  // user then types one character in the search box
  const input = host.querySelector('#search')
  await act(async () => {
    const setter = Object.getOwnPropertyDescriptor(dom.window.HTMLInputElement.prototype, 'value').set
    setter.call(input, 'a')
    input.dispatchEvent(new dom.window.Event('input', { bubbles: true }))
  })
  const afterType = host.querySelector('#sortval').textContent
  return { afterSort, afterType, mounts }
}

const before = await run(ParentInline, 'a')
const after = await run(ParentFn, 'b')

console.log('BEFORE (component declared inside render):')
console.log(`  sort state after sorting: ${before.afterSort}`)
console.log(`  sort state after typing : ${before.afterType}   <-- lost`)
console.log(`  child mount count       : ${before.mounts}`)
console.log('AFTER (render function):')
console.log(`  sort state after sorting: ${after.afterSort}`)
console.log(`  sort state after typing : ${after.afterType}   <-- preserved`)
console.log(`  child mount count       : ${after.mounts}`)

let fail = 0
const check = (n, c) => { console.log((c ? '  PASS  ' : '  FAIL  ') + n); if (!c) fail++ }
console.log('\nAssertions:')
check('old pattern LOSES table state on keystroke', before.afterType === 'none')
check('old pattern remounts the child (mounts > 1)', before.mounts > 1)
check('new pattern KEEPS table state on keystroke', after.afterType === 'OWNER asc')
check('new pattern mounts the child exactly once', after.mounts === 1)
console.log(fail ? `\n${fail} FAILED` : '\nAll assertions passed')
process.exit(fail ? 1 : 0)
