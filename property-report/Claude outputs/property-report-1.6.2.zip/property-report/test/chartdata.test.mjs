// Verifies aggregateChartData applies the configured category/value/aggregation
// rules, which the related-table chart previously ignored by passing raw records.
const { aggregateChartData } = await import('../src/runtime/utils/chartData.ts')
let fail = 0
const check = (n, c, d = '') => { console.log((c ? '  PASS  ' : '  FAIL  ') + n + (c ? '' : '  ' + d)); if (!c) fail++ }

const permits = [
  { TYPE: 'Residential', FEE: 100, YEAR: 2024 },
  { TYPE: 'Residential', FEE: 250, YEAR: 2024 },
  { TYPE: 'Commercial',  FEE: 900, YEAR: 2023 },
  { TYPE: 'Commercial',  FEE: 100, YEAR: 2023 },
  { TYPE: 'Sign',        FEE: 50,  YEAR: 2024 }
]

console.log('count by category:')
const byCount = aggregateChartData(permits, { chartMode: 'category', categoryField: 'TYPE', aggregation: 'count' })
check('three categories', byCount.length === 3, JSON.stringify(byCount))
check('Residential counted twice', byCount.find(r => r.name === 'Residential')?.value === 2, JSON.stringify(byCount))
check('rows shaped {name,value}', byCount.every(r => 'name' in r && typeof r.value === 'number'))

console.log('sum of a value field:')
const bySum = aggregateChartData(permits, { chartMode: 'category', categoryField: 'TYPE', valueField: 'FEE', aggregation: 'sum' })
check('Residential fees sum to 350', bySum.find(r => r.name === 'Residential')?.value === 350, JSON.stringify(bySum))
check('Commercial fees sum to 1000', bySum.find(r => r.name === 'Commercial')?.value === 1000, JSON.stringify(bySum))

console.log('avg / min / max:')
check('avg Residential = 175', aggregateChartData(permits, { chartMode: 'category', categoryField: 'TYPE', valueField: 'FEE', aggregation: 'avg' }).find(r => r.name === 'Residential')?.value === 175)
check('min Commercial = 100', aggregateChartData(permits, { chartMode: 'category', categoryField: 'TYPE', valueField: 'FEE', aggregation: 'min' }).find(r => r.name === 'Commercial')?.value === 100)
check('max Commercial = 900', aggregateChartData(permits, { chartMode: 'category', categoryField: 'TYPE', valueField: 'FEE', aggregation: 'max' }).find(r => r.name === 'Commercial')?.value === 900)

console.log('sorting and maxCategories:')
const top = aggregateChartData(permits, { chartMode: 'category', categoryField: 'TYPE', valueField: 'FEE', aggregation: 'sum', maxCategories: 2, sortBy: 'value', sortOrder: 'desc' })
check('largest category first', top[0].name === 'Commercial', JSON.stringify(top))
check('collapses the tail rather than dropping it', top.length <= 3 && top.reduce((a, r) => a + r.value, 0) === 1400, JSON.stringify(top))

console.log('edge cases:')
check('empty input yields []', aggregateChartData([], { categoryField: 'TYPE' }).length === 0)
check('null config does not throw', Array.isArray(aggregateChartData(permits, null)))
check('missing category becomes a label, not a crash', aggregateChartData([{ FEE: 1 }], { chartMode: 'category', categoryField: 'TYPE', aggregation: 'count' }).length >= 0)

console.log('\nregression: raw records would have produced attribute-keyed series')
const rawKeys = Object.keys(permits[0]).filter(k => k !== 'name' && k !== 'fill')
check('aggregated rows do NOT expose raw attribute keys as series', !byCount.some(r => rawKeys.some(k => k in r)), JSON.stringify(byCount[0]))

console.log(fail ? `\n${fail} FAILED` : '\nAll chart aggregation assertions passed')
process.exit(fail ? 1 : 0)
